'use strict';
setTimeout(()=>{menuWorld();buildSet();applyS();resize();ready=true;$('mt').textContent=MS.length+' MISSIONS';refreshMenu();{const bt=$('boot');setTimeout(()=>{bt.style.opacity=0;bt.style.pointerEvents='none';setTimeout(()=>bt.remove(),700)},Math.max(0,700-performance.now()))}},80);
tick();
