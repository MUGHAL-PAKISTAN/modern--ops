'use strict';
let _peerP=null;
function loadPeer(){if(window.Peer)return Promise.resolve(true);if(_peerP)return _peerP;
const ld=u=>new Promise(r=>{const s=document.createElement('script');s.src=u;s.onload=()=>r(true);s.onerror=()=>r(false);document.head.appendChild(s)});
_peerP=ld('https://unpkg.com/peerjs@1.5.4/dist/peerjs.min.js').then(ok=>(ok&&window.Peer)?true:ld('https://cdn.jsdelivr.net/npm/peerjs@1.5.4/dist/peerjs.min.js')).then(()=>{const ok=!!window.Peer;if(!ok)_peerP=null;return ok});return _peerP}
function peerReady(cb){loadPeer().then(cb,cb)}
const NET={on:0,h:0,g:0,ch:null,pc:null,n:0,t:0,rm:null,gm:null,hm:null,hx:0,hz:0,en:new Map(),tg:[],sg:''};let GWP=null;
const r2=v=>Math.round(v*100)/100;
function nSend(o){try{if(NET.ch&&NET.ch.readyState==='open')NET.ch.send(JSON.stringify(o))}catch(e){}}
function nStatus(t){$('cpst').textContent=t}
let nSid=0,nCsp=0;document.addEventListener('securitypolicyviolation',()=>{nCsp=1});const nBlk=()=>nCsp?'THIS VIEWER BLOCKS NETWORK ACCESS. Download the file and open it in Chrome - then co-op will work.':'CAN NOT REACH THE CODE SERVERS - try other Wi-Fi / mobile data, or use MANUAL MODE (same Wi-Fi).';const ICE=[{urls:['stun:stun.l.google.com:19302','stun:stun1.l.google.com:19302','stun:stun.cloudflare.com:3478','stun:global.stun.twilio.com:3478']},{urls:['turn:openrelay.metered.ca:80','turn:openrelay.metered.ca:443','turn:openrelay.metered.ca:443?transport=tcp'],username:'openrelayproject',credential:'openrelayproject'}];
function nReset(){nSid++;if(NET.ch){NET.ch.onclose=null;try{NET.ch.close()}catch(e){}}(NET.cl||[]).forEach(c=>{try{c.f()}catch(e){}});Object.assign(NET,{on:0,h:0,g:0,ch:null,pc:null,gm:null,cl:[],ok:0,dn:0,rtt:0,php:100,last:0,pdn:0,rvp:0});clearTimeout(NET.rtm);MK[0]=MK[1]=null}
function nWin(tag){NET.cl=(NET.cl||[]).filter(c=>{if(c.tag===tag)return true;try{c.f()}catch(e){}return false})}
function nWrap(dc){const w={readyState:dc.open?"open":"connecting",send:s=>dc.send(s),close:()=>{try{dc.close()}catch(e){}}};dc.on("open",()=>{w.readyState="open";w.onopen&&w.onopen()});dc.on("data",d=>{w.onmessage&&w.onmessage({data:d})});dc.on("close",()=>{w.readyState="closed";w.onclose&&w.onclose()});dc.on("error",()=>{});return w}
const NCH="ABCDEFGHJKLMNPQRSTUVWXYZ23456789",nCode=()=>{let s="";for(let i=0;i<6;i++)s+=NCH[Math.random()*NCH.length|0];return s},NPF="modernops-";
function nBind(ch,tag){NET.ch=ch;ch.onopen=()=>{NET.on=1;NET.t=0;NET.last=performance.now();NET.rtt=0;NET.pt=0;NET.gs=0;NET.pdn=0;if(NET.g)score=0;nWin(tag);nStatus(NET.h?'CONNECTED! Pick a PVP MODE below, or tap BACK then PLAY / MISSIONS for campaign co-op.':'CONNECTED! Waiting for the host to start a mode or mission...')};ch.onmessage=e=>{try{nMsg(JSON.parse(e.data))}catch(x){}};ch.onclose=nDown;if(ch.readyState==="open")ch.onopen()}
function nDown(){const g=NET.g||PV.on,wasDn=NET.dn;nReset();if(g){pop('CONNECTION LOST');toMenu()}else{pop('PARTNER LEFT');const a=NET.rm;if(a){sc.remove(a);const i=allies.indexOf(a);if(i>=0)allies.splice(i,1)}NET.rm=null;if(wasDn&&!cin&&!PV.on){P.hp=100;P.hurtT=99;refillAll();hitFlash=0;dindT=0;lhB=-1;rd.domElement.style.filter='';$('title').style.display='none';run=true;ctl(1)}}}
function nBye(){nSend({k:'bye'});nReset()}
function nAv(a,x,y,z,yaw,f,dt){const u=a.userData,k=Math.min(1,dt*14),ox=a.position.x,oz=a.position.z;a.position.x+=(x-ox)*k;a.position.y+=(y-a.position.y)*k;a.position.z+=(z-oz)*k;a.rotation.y+=angDiff(yaw,a.rotation.y)*k;const sp=Math.hypot(a.position.x-ox,a.position.z-oz)/dt;u.ph+=sp*dt*2.4;const sw=sp>.4?Math.sin(u.ph)*.75:0;u.legs[0].rotation.x=sw;u.legs[1].rotation.x=-sw;u.mf.visible=!!f&&Math.random()<.7;u.ap=lerp(u.ap||0,f?1:0,Math.min(1,dt*6));poseGun(u,0,dt)}
function nAddRm(){const a=soldier('rifle',1,P.x+2,P.z+3),u=a.userData;u.rm=1;u.name='PLAYER 2';u.hp=u.max=99999;allies.push(a);NET.rm=a}
function nRm(a,dt){const g=NET.gm;if(g&&dt>0)nAv(a,g[0],g[1]-1.7,g[2],g[3],g[4],dt)}
function nHostTick(dt){NET.t+=dt;if(NET.t<.083)return;NET.t=0;const en=[];for(const e of enemies){const u=e.userData;if(!u.nid)u.nid=++NET.n;en.push([u.nid,u.kind,r2(e.position.x),r2(e.position.y),r2(e.position.z),r2(e.rotation.y),u.mf&&u.mf.visible?1:0])}
nSend({k:'s',p:[r2(P.x),r2(P.y),r2(P.z),r2(P.yaw),firing?1:0,Math.round(P.hp)],en:en,tg:(stg.tgl||[]).map(o=>[o.kind,o.x,o.z,r2(o.g.rotation.y),o.dead?1:0]),ob:$('obj').textContent,wp:objPos(),sc:score,cin:cin?1:0})}
function nGuestTick(dt){if(!cur||dt<=0)return;for(const e of NET.en.values()){const u=e.userData,r=u.tp;if(r&&!u.dead)nAv(e,r[2],r[3],r[4],r[5],r[6],dt)}
const h=NET.hm,r=h&&h.userData.tp;if(r)nAv(h,r[0],r[1]-1.7,r[2],r[3],r[4],dt);NET.t+=dt;if(NET.t>.083){NET.t=0;nSend({k:'p',a:[r2(P.x),r2(P.y),r2(P.z),r2(P.yaw),firing?1:0,Math.round(P.hp)]})}}
function gStart(n){MO_ASSETS.load();mi=n;cur=MS[mi];run=false;clearTimeout(NET.rtm);NET.dn=0;NET.pdn=0;flyEnd();['menu','over','mis','how','set','pause','coop'].forEach(closeOv);$('title').style.display='none';buildWorld(cur);addTowers();
Object.assign(P,{x:cur.start[0]+2,z:cur.start[1]+3,hp:100,yaw:0,pitch:0,vy:0,y:1.7,rec:0,recY:0});enemies.forEach(e=>sc.remove(e));enemies.length=0;corpses.forEach(e=>sc.remove(e));corpses.length=0;allies.forEach(a=>sc.remove(a));allies.length=0;
NET.en.forEach(e=>sc.remove(e));NET.en.clear();if(NET.hm){sc.remove(NET.hm);NET.hm=null}NET.tg=[];NET.sg='';clearPks();keepLoad=0;startLoad();adsOn=false;ads=0;si=0;stg.s=null;$('obj').textContent=cur.n;ctl(1);run=true}
function gSnap(m){if(!cur||!NET.g)return;NET.hx=m.p[0];NET.hz=m.p[2];NET.hy=m.p[1];NET.php=m.p[5];if(!NET.hm){const a=soldier('rifle',1,m.p[0],m.p[2]);a.userData.name='HOST';NET.hm=a}NET.hm.userData.tp=m.p;
const seen=new Set();for(const r of m.en){seen.add(r[0]);let e=NET.en.get(r[0]);if(!e){e=soldier(r[1],0,r[2],r[4]);e.userData.nid=r[0];e.userData.alert=true;NET.en.set(r[0],e);enemies.push(e)}e.userData.tp=r}
for(const [id,e] of NET.en)if(!seen.has(id)){NET.en.delete(id);if(!e.userData.dead)killE(e,false,false)}
const T=m.tg||[],sg=T.map(r=>r[0]+r[1]+r[2]).join();if(sg!==NET.sg){NET.sg=sg;NET.tg=T.map(r=>mkTg(r[0],r[1],r[2],r[3]))}T.forEach((r,i)=>{const o=NET.tg[i];if(o&&r[4]&&!o.dead)dmgT(o,9999,false)});
$('obj').textContent=m.cin?'HOST IN CUTSCENE...':m.ob;GWP=m.wp;NET.hs=m.sc}
function gDie(){downMe()}
const NDL={};function nDmg(d,cap,budget,key){d=+d;if(!(d>0)||!isFinite(d))return 0;d=Math.min(d,cap);const n=performance.now(),b=NDL[key]||(NDL[key]={t:n,s:0});if(n-b.t>1000){b.t=n;b.s=0}if(b.s+d>budget)return 0;b.s+=d;return d}
const nPos=a=>Array.isArray(a)&&a.length>=6&&a.every(Number.isFinite)&&Math.abs(a[0])<400&&Math.abs(a[2])<400&&Math.abs(a[1])<200;
function nMsg(m){NET.last=performance.now();switch(m.k){case 'png':nSend({k:'pog',t:m.t});break;case 'pog':{const r=performance.now()-m.t;NET.rtt=NET.rtt?NET.rtt*.6+r*.4:r;break}
case 'p':if(nPos(m.a)){NET.gm=m.a;NET.php=m.a[5]}break;
case 'dmg':{const e=enemies.find(q=>q.userData.nid===m.id),dd=nDmg(m.d,450,4000,'e');if(e&&dd&&!cin){const yw=+m.yw||0;hitDir.x=-Math.sin(yw);hitDir.z=-Math.cos(yw);hitDir.p=dd;hitDir.ex=0;NET.gk=1;dmgE(e,dd,1,!!m.h);NET.gk=0}break}
case 'dt':{const o=stg.tgl&&stg.tgl[m.i],dd=nDmg(m.d,600,4000,'t');if(o&&dd){NET.gk=1;dmgT(o,dd,1);NET.gk=0}break}
case 'mis':score=m.gs||0;gStart(m.mi);break;
case 's':gSnap(m);break;
case 'hit':hurt(m.d,0,0);break;
case 'pop':pop(m.x);break;
case 'rad':radio(m.w,m.x);break;
case 'end':pop('MISSION COMPLETE');sWin();break;
case 'pp':if(Array.isArray(m.a)&&m.a.length>=6&&m.a.every(Number.isFinite))PV.rp=m.a;break;
case 'pb':if(PV.on&&NET.g)pvGBots(m.b);break;
case 'pvm':if(NET.g)pvInit(m.mode);break;
case 'pvr':if(NET.g&&PV.on){PV.ph='live';PV.rd=m.rd;PV.sh=m.sh;PV.sg=m.sg;PV.tl=m.tl;PV.ralive=1;pvSpawnMe(m.sp,m.cd);if(m.cd>0)pvBanner(PV.mode==='clash'?'ROUND '+m.rd:'GET READY',1500)}break;
case 'pvban':if(PV.on)pvBanner(m.t,m.ms);break;
case 'pvs':if(NET.g&&PV.on){PV.ph=m.ph;PV.sh=m.sh;PV.sg=m.sg;PV.rd=m.rd;PV.tl=m.tl;PV.a0=m.a0;PV.a1=m.a1}break;
case 'pve':if(NET.g&&PV.on){PV.sh=m.sh;PV.sg=m.sg;pvShowEnd(m.w)}break;
case 'pvd':if(PV.on){const dd=nDmg(m.d,90,1000,'pv');if(dd)hurt(dd,+m.x||0,+m.z||0)}break;
case 'pvb':if(PV.on&&NET.h){const b=PV.bots.find(q=>q.userData.id===m.id);const dd=nDmg(m.d,90,1000,'pb');if(b&&dd)pvBotDmg(b,dd,!!m.h,+m.x||0,+m.z||0)}break;
case 'pvx':if(PV.on&&NET.h){PV.ralive=0;pvKilled(1)}break;
case 'mk':mkSet(1,m.x,m.y,m.z,m.g);break;case 'cm':showComm(NET.h?'PLAYER 2':'HOST',typeof m.s==='string'?m.s.slice(0,80):(CM[m.i]||''));break;case 'dn':NET.pdn=m.v?1:0;NET.rvp=0;break;case 'rv':upMe(1);break;case 'gsc':score=m.s;if(m.l)pop(m.l);break;case 'rsp':if(NET.g&&run){resup();P.hp=100;pop('AMMO RESUPPLIED')}break;case 'bye':nReset();toMenu();break}}
const PV={on:0,mode:'',me:0,ph:'between',sh:0,sg:0,rd:0,tl:0,cd:0,cdn:-1,frz:1,inv:0,alive:0,ralive:1,rp:null,rv:null,bots:[],gb:new Map(),bid:0,nt:0,st:0,bt:0,bh:null,rt:[0,0],a0:0,a1:0,l1:'',l2:'',ob:'?',lim:5};
const PVS=[[-22,22],[22,22],[-22,-22],[22,-22],[0,25],[0,-25],[-25,0],[25,0]],PVN={duel:'1v1 DUEL',clash:'CLASH SQUAD',dm:'PVP DEATHMATCH'},
PVM={n:'PVP ARENA',loc:'PVP ARENA · 2 PLAYERS',b:'arena',sky:SKY.des,sd:[.2,.8,-.4],fog:[40,170],hemi:[0xf0e8d0,0x8a7048,1],sunC:0xfff4d8,sunI:2.6,exp:1.25,torch:0,start:[0,25],vis:60,spot:26,st:[],intro:[],out:[]};
function arena(){setGround('conc',30);const W=mt('conc');
box(0,-31,64,6,2,W,6);box(0,31,64,6,2,W,6);box(-31,0,2,6,64,W,6);box(31,0,2,6,64,W,6);box(0,0,6.1,2.6,2.5,mt('cont0'),3);
for(const sx of[-1,1]){for(const sz of[-1,1]){box(sx*10,sz*9,2,2,2,mt('crate'),2);box(sx*8,sz*19,4,1,.9,mt('bag'),1);box(sx*19,sz*11,2.5,2.6,6.1,mt('cont'+(sx>0?1:2)),3)}box(sx*17,0,.7,1.1,5,W,2);box(0,sx*13,5,1.1,.7,W,2)}}
function pvClear(){if(PV.rv){sc.remove(PV.rv);PV.rv=null}PV.bots.forEach(b=>sc.remove(b));PV.bots=[];PV.gb.forEach(b=>sc.remove(b));PV.gb.clear();clearTimeout(PV.bh);PV.on=0;PV.frz=0;PV.inv=0;GWP=null;$('again').style.display='';$('prs').style.display='';$('title').style.display='none'}
function pvLoad(){attApply(0);nGren=2;SL[0]=mkWS('kn');SL[1]=mkWS('pi');SL[2]=mkWS('m4');cs=2;ps=1;selectSlot(2);resetGun()}
function pvBanner(t,ms){sBanner(t);const T=$('title');T.innerHTML=t;T.style.display='block';clearTimeout(PV.bh);PV.bh=setTimeout(()=>{T.style.display='none'},ms||1500)}
function pvInit(mode){MO_ASSETS.load();pvClear();Object.assign(PV,{on:1,mode:mode,me:NET.h?0:1,lim:mode==='duel'?5:mode==='dm'?15:4,ph:'between',sh:0,sg:0,rd:0,tl:mode==='dm'?300:0,cd:0,cdn:-1,frz:1,inv:0,alive:0,ralive:1,rp:null,bid:0,nt:0,st:0,bt:0,rt:[0,0],a0:0,a1:0,ob:'?'});
run=false;paused=false;flyEnd();inLobby=false;cin=false;['menu','over','mis','how','set','pause','coop','lobby'].forEach(closeOv);$('sub').textContent='';cur=PVM;mi=0;stg.s=null;buildWorld(PVM);
enemies.forEach(e=>sc.remove(e));enemies.length=0;corpses.forEach(e=>sc.remove(e));corpses.length=0;allies.forEach(a=>sc.remove(a));allies.length=0;
NET.en.forEach(e=>sc.remove(e));NET.en.clear();if(NET.hm){sc.remove(NET.hm);NET.hm=null}NET.rm=null;NET.tg=[];NET.sg='';clearPks();
const a=soldier('rifle',0,0,-60),u=a.userData;u.e=0;u.a=0;u.pv=1;u.team=1-PV.me;u.hp=u.max=100;u.wid='m4';a.visible=false;PV.rv=a;
P.x=0;P.z=PV.me?-25:25;P.y=1.7;pvLoad();$('over').style.display='none';ctl(0);pvBanner(PVN[mode],2000)}
function pvBegin(mode){if(!NET.on||!NET.h)return;nSend({k:'pvm',mode:mode});pvInit(mode);pvRound()}
function pvPickSp(avoid){let L=PVS.slice();if(avoid)L=L.filter(s=>Math.hypot(s[0]-avoid[0],s[1]-avoid[1])>30);const s=L[R()*L.length|0]||PVS[0];return[s[0],s[1],Math.atan2(s[0],s[1])]}
function pvState(){nSend({k:'pvs',ph:PV.ph,sh:PV.sh,sg:PV.sg,rd:PV.rd,tl:Math.round(PV.tl),a0:PV.a0,a1:PV.a1})}
function pvRound(){PV.ph='live';PV.rd++;PV.ralive=1;PV.rt=[0,0];let hs,gs;
if(PV.mode==='clash'){hs=[0,25,0];gs=[0,-25,PI];pvMkBots();PV.tl=75}else{hs=pvPickSp(null);gs=pvPickSp(hs)}
nSend({k:'pvr',sp:gs,cd:3.2,rd:PV.rd,sh:PV.sh,sg:PV.sg,tl:PV.tl});pvSpawnMe(hs,3.2);pvBanner(PV.mode==='clash'?'ROUND '+PV.rd:'GET READY',1500);pvCount();pvState()}
function pvSpawnMe(sp,cd){Object.assign(P,{x:sp[0],z:sp[1],hp:100,yaw:sp[2],pitch:0,vy:0,y:1.7,rec:0,recY:0,hurtT:99});P.ground=true;hitFlash=0;dindT=0;lhB=-1;rd.domElement.style.filter='';PV.alive=1;PV.inv=PV.mode==='dm'?2:0;PV.cd=cd||0;PV.cdn=-1;PV.frz=PV.cd>0?1:0;pvLoad();adsOn=false;ads=0;firing=false;mant.on=0;run=true;ctl(1);$('over').style.display='none';$('dmg').style.opacity=0}
function pvMkBots(){PV.bots.forEach(b=>sc.remove(b));PV.bots=[];for(let t=0;t<2;t++)for(let i=0;i<2;i++){const b=soldier('rifle',t===0?1:0,i?7:-7,t?-24:24),u=b.userData;u.e=0;u.a=0;u.pv=1;u.bot=1;u.id=++PV.bid;u.team=t;u.hp=u.max=100;u.wid='m4';u.s=2.6+R()*.8;u.pref=14+R()*8;u.ct=R()*.3;u.aim=.5;b.rotation.y=t?PI:0;PV.bots.push(b)}}
function pvTargets(){const L=[];if(PV.rv&&PV.rv.visible&&!PV.rv.userData.dead)L.push(PV.rv);const B=NET.h?PV.bots:Array.from(PV.gb.values());for(const b of B)if(!b.userData.dead&&b.userData.team!==PV.me)L.push(b);return L}
function pvSend(o,dm,head){const u=o.userData;if(u.bot){if(NET.h)pvBotDmg(o,dm,head,P.x,P.z);else nSend({k:'pvb',id:u.id,d:dm,h:head?1:0,x:P.x,z:P.z})}else nSend({k:'pvd',d:dm,h:head?1:0,x:P.x,z:P.z})}
function pvHit(o,h,d,fo){const head=!!h.object.userData.head;let dm=(head?d.hd:d.dmg)*fo;dm=Math.min(dm,head?75:60);pvSend(o,dm,head);hitMk(head);const e=h.point;puff({x:e.x,y:e.y,z:e.z,vy:.5,sz:.35,life:.4,col:0x7a1a1a,grow:.6,op:.8})}
function pvSlash(){const fx=-Math.sin(P.yaw),fz=-Math.cos(P.yaw);for(const t of pvTargets()){const dx=t.position.x-P.x,dz=t.position.z-P.z,dd=Math.hypot(dx,dz);if(dd<2.3&&(dx*fx+dz*fz)/(dd||1)>.55){pvSend(t,70,false);hitMk(0)}}}
function pvBotDmg(b,dm,head,sx,sz){const u=b.userData;if(u.dead||PV.frz)return;u.hp-=dm;u.fl=.2;if(u.hp<=0){u.dead=1;u.dt=0;hitDir.x=b.position.x-sx;hitDir.z=b.position.z-sz;hitDir.p=dm;hitDir.ex=0;u.mf.visible=false;deathSetup(b,head);pvClashCheck()}}
function pvFoes(team){const L=[];if(team===0){if(PV.ralive&&PV.rp)L.push({x:PV.rp[0],y:PV.rp[1]-.3,z:PV.rp[2],pl:1})}else if(PV.alive)L.push({x:P.x,y:P.y-.3,z:P.z,pl:0});for(const b of PV.bots)if(b.userData.team!==team&&!b.userData.dead)L.push({x:b.position.x,y:1.3,z:b.position.z,b:b});return L}
function pvBotShot(b,f,d){const u=b.userData,mx=b.position.x-Math.sin(b.rotation.y)*.7,mz=b.position.z-Math.cos(b.rotation.y)*.7,hit=R()<clamp(.55-d*.011,.08,.46);let tx=f.x,ty=f.y,tz=f.z;if(!hit){tx+=(R()-.5)*3;ty+=(R()-.5)*1.4;tz+=(R()-.5)*3}
tracer(mx,1.45,mz,tx,ty,tz,.04);u.kk=1;u.mf.visible=true;u.mft=.05;sFar(Math.hypot(b.position.x-P.x,b.position.z-P.z),panOf(b.position.x,b.position.z));if(!hit)return;const dm=9;
if(f.b)pvBotDmg(f.b,dm*1.3,false,b.position.x,b.position.z);else if(f.pl===0)hurt(dm,b.position.x,b.position.z);else nSend({k:'pvd',d:dm,x:b.position.x,z:b.position.z})}
function pvBotAI(b,dt){const u=b.userData;if(u.dead){corpseAnim(b,dt);return}
if(u.mft>0){u.mft-=dt;if(u.mft<=0)u.mf.visible=false}if(u.fl>0)u.fl-=dt;b.rotation.x=u.fl>0?Math.sin(clamp(u.fl/.2,0,1)*PI)*.2:0;const bx=b.position.x,bz=b.position.z;
if(PV.frz){u.ap=lerp(u.ap||0,0,Math.min(1,dt*6));poseGun(u,0,dt);u.legs[0].rotation.x=u.legs[1].rotation.x=0;return}
u.ct-=dt;if(u.ct<=0){u.ct=.25+R()*.2;const had=!!u.tg;u.tg=null;u.nr=null;let nd=1e9,vd=1e9;for(const f of pvFoes(u.team)){const d=Math.hypot(f.x-bx,f.z-bz);if(d<nd){nd=d;u.nr=f}if(d<62&&d<vd&&los(bx,1.55,bz,f.x,f.y,f.z)){vd=d;u.tg=f;u.td=d}}if(u.tg&&!had)u.aim=.35+R()*.45}
const tg=u.tg,at=tg||u.nr;let mvx=0,mvz=0,spd=0,face=b.rotation.y;
if(at){const dx=at.x-bx,dz=at.z-bz,d=Math.hypot(dx,dz)||1,nx=dx/d,nz2=dz/d;face=Math.atan2(-dx,-dz);
if(tg){u.sdT-=dt;if(u.sdT<=0){u.sdT=1.4+R()*2;u.sd=-u.sd}if(d>u.pref+5){mvx=nx;mvz=nz2;spd=u.s}else if(d<u.pref-7){mvx=-nx;mvz=-nz2;spd=u.s*.7}else{mvx=-nz2*u.sd;mvz=nx*u.sd;spd=u.s*.6}}else{mvx=nx;mvz=nz2;spd=u.s}
if(u.slide>0){u.slide-=dt;mvx=-nz2*u.sd;mvz=nx*u.sd;spd=u.s}
if(tg){u.aim-=dt;u.fire-=dt;if(u.aim<=0&&u.fire<=0){if(u.left<=0)u.left=2+(R()*4|0);pvBotShot(b,tg,u.td||d);u.left--;u.fire=u.left>0?.12:.7+R()*.9}}}
b.rotation.y+=angDiff(face,b.rotation.y)*Math.min(1,dt*8);
if(spd){const nx2=bx+mvx*spd*dt,nz3=bz+mvz*spd*dt;let bl=0;if(!hitBox(nx2,bz,.5)&&Math.abs(nx2)<29)b.position.x=nx2;else bl=1;if(!hitBox(b.position.x,nz3,.5)&&Math.abs(nz3)<29)b.position.z=nz3;else bl=1;if(bl){u.bl+=dt;if(u.bl>.35){u.bl=0;u.sd=-u.sd;u.slide=.8}}u.ph+=spd*dt*2.4}
u.ap=lerp(u.ap||0,tg?1:0,Math.min(1,dt*6));let pt=0;if(tg)pt=Math.atan2(tg.y-1.45,Math.hypot(tg.x-bx,tg.z-bz)||1);poseGun(u,pt,dt);const sw=spd?Math.sin(u.ph)*.75:0;u.legs[0].rotation.x=lerp(u.legs[0].rotation.x,sw,.3);u.legs[1].rotation.x=lerp(u.legs[1].rotation.x,-sw,.3)}
function pvGBots(list){const seen=new Set();for(const r of list){seen.add(r[0]);let b=PV.gb.get(r[0]);if(!b){b=soldier('rifle',r[1]===PV.me?1:0,r[2],r[4]);const u=b.userData;u.e=0;u.a=0;u.pv=1;u.bot=1;u.id=r[0];u.team=r[1];u.hp=u.max=100;u.wid='m4';PV.gb.set(r[0],b)}
const u=b.userData;if(r[6]&&!u.wf){const d=Math.hypot(r[2]-P.x,r[4]-P.z);sFar(d,panOf(r[2],r[4]))}u.wf=r[6];u.tp=r;if(r[7]&&!u.dead){u.dead=1;u.dt=0;hitDir.x=0;hitDir.z=1;hitDir.p=40;hitDir.ex=0;u.mf.visible=false;deathSetup(b,false)}}
for(const [id,b] of PV.gb)if(!seen.has(id)){sc.remove(b);PV.gb.delete(id)}}
function pvRevive(a,r){const u=a.userData;a.visible=true;a.rotation.set(0,r[3],0);a.position.set(r[0],r[1]-1.7,r[2]);u.dead=0;u.fx=undefined;u.dt=0;u.vk=0;u.vy=0;u.legs.forEach(l=>l.rotation.set(0,0,0));u.arms[0].rotation.z=-.37;u.arms[1].rotation.z=.61;if(u.bm){u.bm.visible=false;u.bm=null}}
function pvAv(a,r,dt){if(!a||!r)return;const u=a.userData;if(r[5]){if(u.dead||!a.visible)pvRevive(a,r);nAv(a,r[0],r[1]-1.7,r[2],r[3],r[4],dt)}else if(!u.dead&&a.visible){hitDir.x=0;hitDir.z=1;hitDir.p=40;hitDir.ex=0;u.dead=1;u.dt=0;u.mf.visible=false;deathSetup(a,false)}if(u.dead)corpseAnim(a,dt)}
function pvCount(){let a0=PV.alive?1:0,a1=PV.ralive?1:0;for(const b of PV.bots)if(!b.userData.dead){if(b.userData.team)a1++;else a0++}PV.a0=a0;PV.a1=a1;return[a0,a1]}
function pvScore(w){if(w===0)PV.sh++;else PV.sg++}
function pvClashCheck(){if(!NET.h||PV.mode!=='clash'||PV.ph!=='live')return;const c=pvCount();if(c[0]&&c[1])return;pvRoundEnd(c[0]>0?0:c[1]>0?1:-1)}
function pvRoundEnd(w){if(w>=0){pvScore(w);if(w===0)score+=300}if(Math.max(PV.sh,PV.sg)>=PV.lim){pvEnd(PV.sh>PV.sg?0:1);return}PV.ph='between';PV.bt=4;const t=me=>w<0?'ROUND DRAW':w===me?'ROUND WON':'ROUND LOST';pvBanner(t(0),2800);nSend({k:'pvban',t:t(1),ms:2800});pvState()}
function pvKilled(who){if(!NET.h||!PV.on||PV.ph!=='live')return;if(PV.mode==='clash'){pvClashCheck();return}const k=1-who;pvScore(k);if(k===0){pop('ELIMINATED +100');score+=100}else nSend({k:'pop',x:'ELIMINATED +100'});
if(Math.max(PV.sh,PV.sg)>=PV.lim){pvEnd(PV.sh>PV.sg?0:1);return}if(PV.mode==='duel'){PV.ph='between';PV.bt=3.2}else PV.rt[who]=3;pvState()}
function pvEnd(w){PV.ph='end';nSend({k:'pve',w:w,sh:PV.sh,sg:PV.sg});pvShowEnd(w)}
function pvShowEnd(w){if(w===PV.me)sWin();else if(w<0)sUI();else sOver();PV.ph='end';run=false;firing=false;adsOn=false;ctl(0);const m=PV.me?PV.sg:PV.sh,o=PV.me?PV.sh:PV.sg;$('ot').textContent=w<0?'DRAW':w===PV.me?'VICTORY':'DEFEAT';$('fs').textContent=PVN[PV.mode]+' · YOU '+m+' - '+o+' FOE';$('again').textContent='REMATCH';$('again').style.display=NET.h?'':'none';$('over').style.display='flex'}
function pvDie(){if(!PV.alive)return;PV.alive=0;run=false;firing=false;adsOn=false;hitFlash=0;ctl(0);resetGun();rd.domElement.style.filter='';lhB=-1;$('dmg').style.opacity=0;pop('YOU WERE ELIMINATED');if(NET.h)pvKilled(0);else nSend({k:'pvx'})}
function pvIdleCam(dt){const t=PV.rv&&PV.rv.visible?PV.rv.position:null;cam.position.set(P.x,P.y+2.2,P.z);cam.lookAt(t?t.x:0,1.2,t?t.z:0);if(Math.abs(cam.fov-CFG.fov)>.05){cam.fov=CFG.fov;cam.updateProjectionMatrix()}}
function pvHost(dt){if(PV.mode==='clash')for(const b of PV.bots)pvBotAI(b,dt);
if(PV.ph==='between'){PV.bt-=dt;if(PV.bt<=0)pvRound();return}if(PV.ph!=='live')return;
if(PV.mode==='dm')for(let i=0;i<2;i++)if(PV.rt[i]>0){PV.rt[i]-=dt;if(PV.rt[i]<=0){const sp=pvPickSp(i===0?(PV.rp?[PV.rp[0],PV.rp[2]]:null):[P.x,P.z]);if(i===0)pvSpawnMe(sp,0);else{PV.ralive=1;nSend({k:'pvr',sp:sp,cd:0,rd:PV.rd,sh:PV.sh,sg:PV.sg,tl:PV.tl})}}}
if(PV.cd<=0&&PV.mode!=='duel'){PV.tl-=dt;if(PV.tl<=0){PV.tl=0;if(PV.mode==='dm')pvEnd(PV.sh>PV.sg?0:PV.sg>PV.sh?1:-1);else{const c=pvCount();pvRoundEnd(c[0]>c[1]?0:c[1]>c[0]?1:-1)}return}}
PV.st-=dt;if(PV.st<=0){PV.st=.5;pvClashCheck();if(PV.ph==='live'){pvCount();pvState()}}}
function pvTick(dt){PV.frz=(PV.ph!=='live'||PV.cd>0)?1:0;
if(PV.cd>0){PV.cd-=dt;const n=Math.max(0,Math.ceil(PV.cd));if(n!==PV.cdn){PV.cdn=n;pvBanner(n>0?n:'FIGHT!',900)}}
if(PV.inv>0)PV.inv-=dt;PV.nt-=dt;
if(PV.nt<=0){PV.nt=.083;nSend({k:'pp',a:[r2(P.x),r2(P.y),r2(P.z),r2(P.yaw),firing&&PV.alive?1:0,PV.alive?1:0]});if(NET.h&&PV.mode==='clash')nSend({k:'pb',b:PV.bots.map(b=>{const u=b.userData;return[u.id,u.team,r2(b.position.x),r2(b.position.y),r2(b.position.z),r2(b.rotation.y),u.mf.visible?1:0,u.dead?1:0]})})}
pvAv(PV.rv,PV.rp,dt);
if(NET.h)pvHost(dt);else{if(PV.ph==='live'&&PV.cd<=0&&PV.tl>0)PV.tl=Math.max(0,PV.tl-dt);for(const b of PV.gb.values()){const u=b.userData,r=u.tp;if(!r)continue;if(u.dead)corpseAnim(b,dt);else nAv(b,r[2],r[3],r[4],r[5],r[6],dt)}}
const mine=PV.me?PV.sg:PV.sh,their=PV.me?PV.sh:PV.sg,tm=Math.max(0,Math.ceil(PV.tl)),ts=Math.floor(tm/60)+':'+('0'+tm%60).slice(-2);
if(PV.mode==='duel'){PV.l1='1v1 DUEL · FIRST TO '+PV.lim;PV.l2='YOU '+mine+' - '+their+' FOE'}else if(PV.mode==='dm'){PV.l1='DEATHMATCH · '+ts;PV.l2='YOU '+mine+' - '+their+' FOE · TO '+PV.lim}else{PV.l1='CLASH SQUAD · RD '+PV.rd+' · '+ts;PV.l2='WINS '+mine+' - '+their+' · ALIVE '+(PV.me?PV.a1:PV.a0)+' v '+(PV.me?PV.a0:PV.a1)}
const ob=PV.alive?'':(PV.mode==='dm'?'RESPAWNING...':PV.mode==='duel'?'YOU DIED':'ELIMINATED - SPECTATING');if(ob!==PV.ob){PV.ob=ob;$('obj').textContent=ob}}
function pvBlast(x,z,rad,dmg){for(const t of pvTargets()){const d=Math.hypot(t.position.x-x,t.position.z-z);if(d<rad)pvSend(t,Math.min(90,dmg*(1-d/rad)*.8),false)}}
{const D={duel:'1v1 DUEL: you vs your friend. First to 5 kills, quick rematch rounds.',clash:'CLASH SQUAD: you + 2 AI vs friend + 2 AI. Team elimination rounds, no respawn, first to 4 round wins.',dm:'PVP DEATHMATCH: free-for-all, respawn after 3s, first to 15 kills or 5 minutes.'};
for(const m of['duel','clash','dm'])$('pv_'+m).onclick=()=>{AC();if(!NET.on)return nStatus('Connect first: one player taps HOST GAME, the friend enters the code and taps JOIN GAME.');if(!NET.h)return nStatus('Only the HOST can start a mode. '+D[m]);pvBegin(m)}}
$('coopb').onclick=()=>{AC();openOv('coop');nProbe();MO_ASSETS.load();loadPeer()};$('cpback').onclick=()=>closeOv('coop');
const NTF='https://ntfy.sh/';
async function ntPub(t,txt){const r=await fetch(NTF+t,{method:'POST',body:txt});if(!r.ok)throw new Error('relay '+r.status)}
async function ntGet(t,since){const r=await fetch(NTF+t+'/json?poll=1&since='+(since||'all'));if(!r.ok)throw new Error('relay '+r.status);const tx=await r.text(),o=[];tx.split('\n').forEach(l=>{if(!l.trim())return;try{const j=JSON.parse(l);if(j.event==='message')o.push(j)}catch(e){}});return o}
function nIce(pc){return new Promise(r=>{if(pc.iceGatheringState==='complete')return r();const f=()=>{if(pc.iceGatheringState==='complete'){pc.removeEventListener('icegatheringstatechange',f);r()}};pc.addEventListener('icegatheringstatechange',f);setTimeout(r,5000)})}
const nEnc=d=>{let sdp=d.sdp,e=btoa(JSON.stringify({type:d.type,sdp:sdp}));for(const re of[/^a=candidate.* typ relay/,/^a=candidate.* tcp /]){if(e.length<=3800)break;sdp=sdp.split('\r\n').filter(l=>!re.test(l)).join('\r\n');e=btoa(JSON.stringify({type:d.type,sdp:sdp}))}return e},nDec=t=>JSON.parse(atob(t.trim()));
function nPcNew(tag){const pc=new RTCPeerConnection({iceServers:ICE});NET.cl.push({tag:tag,f:()=>{try{pc.close()}catch(e){}}});return pc}
async function hostNtfy(code,sid,ready){const pc=nPcNew('nt'),dc=pc.createDataChannel('c');dc.onopen=()=>{if(sid!==nSid)return;if(NET.ch)return dc.close();nBind(dc,'nt')};
await pc.setLocalDescription(await pc.createOffer());await nIce(pc);if(sid!==nSid)return;await ntPub('mops-'+code+'-o',nEnc(pc.localDescription));ready();let since='all',used=0;
const tq=Date.now();while(sid===nSid&&!NET.ch){await sleep(Date.now()-tq<40000?2000:5000);try{const ms=await ntGet('mops-'+code+'-a',since);for(const m of ms){since=m.id;if(!used&&pc.signalingState==='have-local-offer'){used=1;await pc.setRemoteDescription(nDec(m.message))}}}catch(e){}}}
async function joinNtfy(code,sid,fail){let offs;try{offs=await ntGet('mops-'+code+'-o')}catch(e){return fail('code server blocked')}if(sid!==nSid)return;if(!offs.length)return fail('code not found');
const pc=nPcNew('nt');pc.ondatachannel=e=>{const dc=e.channel,go=()=>{if(sid!==nSid)return;if(NET.ch)return dc.close();nBind(dc,'nt')};dc.onopen=go;if(dc.readyState==='open')go()};
await pc.setRemoteDescription(nDec(offs[offs.length-1].message));await pc.setLocalDescription(await pc.createAnswer());await nIce(pc);if(sid!==nSid)return;await ntPub('mops-'+code+'-a',nEnc(pc.localDescription))}
function hostPeer(code,sid,ready){if(!window.Peer)return;let p;try{p=new Peer(NPF+code)}catch(e){return}NET.cl.push({tag:'pj',f:()=>{try{p.destroy()}catch(e){}}});
p.on('open',ready);p.on('connection',dc=>{dc.on('open',()=>{if(sid!==nSid)return;if(NET.ch)return dc.close();nBind(nWrap(dc),'pj')})});p.on('disconnected',()=>{try{if(!p.destroyed)p.reconnect()}catch(e){}});p.on('error',()=>{})}
function joinPeer(code,sid,fail){if(!window.Peer)return;let p;try{p=new Peer()}catch(e){return fail('PeerJS error')}NET.cl.push({tag:'pj',f:()=>{try{p.destroy()}catch(e){}}});
p.on('open',()=>{if(sid!==nSid)return;const dc=p.connect(NPF+code,{reliable:true});dc.on('open',()=>{if(sid!==nSid)return;if(NET.ch)return dc.close();nBind(nWrap(dc),'pj')})});p.on('error',e=>fail(e.type==='peer-unavailable'?'code not found':'PeerJS '+e.type))}
async function nProbe(){if(NET.on)return;nStatus('Checking connection...');const c=new AbortController(),t=setTimeout(()=>c.abort(),6000);try{const r=await fetch(NTF+'mops-ping/json?poll=1',{signal:c.signal,cache:'no-store'});clearTimeout(t);if(!NET.on)nStatus(r.ok?'Connection OK - HOST: tap HOST GAME. FRIEND: tap SEARCH ROOMS (or enter a code).':'Code server error '+r.status+' - try MANUAL MODE')}catch(e){clearTimeout(t);if(!NET.on)nStatus(nBlk())}}
let nLanC=null,nLanT=0,nSrT=0;const NGLOB='mops-lobby-global-v1';
const nV6=ip=>{const h=ip.includes('::'),p=ip.split('::'),A=p[0]?p[0].split(':'):[],B=h&&p[1]?p[1].split(':'):[];if(h)while(A.length+B.length<8)A.push('0');return A.concat(B).slice(0,4).map(x=>parseInt(x||'0',16).toString(16)).join(':')};
const nHash=ip=>{let h=5381,g=52711;for(let i=0;i<ip.length;i++){h=((h*33)^ip.charCodeAt(i))>>>0;g=(g*31+ip.charCodeAt(i))>>>0}return 'mops-lan-'+h.toString(36)+g.toString(36)};
async function nIpGet(u,kind){const c=new AbortController(),t=setTimeout(()=>c.abort(),4500);try{const r=await fetch(u,{signal:c.signal,cache:'no-store'}),x=await r.text();let ip='';if(kind===1){try{ip=JSON.parse(x).ip}catch(e){}}else{const m=x.match(/^ip=(.+)$/m);ip=m?m[1]:''}return String(ip||'').trim()}catch(e){return ''}finally{clearTimeout(t)}}
async function nTopics(){if(nLanC&&Date.now()-nLanT<15000)return nLanC;
const r=await Promise.all([nIpGet('https://api.ipify.org?format=json',1),nIpGet('https://api64.ipify.org?format=json',1),nIpGet('https://www.cloudflare.com/cdn-cgi/trace',2)]);
const st=new Set();for(const ip of r){if(ip.length<3)continue;st.add(nHash(ip.includes(':')?'v6:'+nV6(ip):ip))}
nLanC={lan:[...st],glob:NGLOB};nLanT=Date.now();return nLanC}
async function nBeacon(code,sid){let T;try{T=await nTopics()}catch(e){return}const msg=JSON.stringify({c:code,n:'ROOM '+code.slice(0,3)+'-'+code.slice(3)}),t0=Date.now();
while(sid===nSid&&!NET.ch&&!NET.on&&Date.now()-t0<300000){for(const tp of T.lan.concat([T.glob])){try{await ntPub(tp,msg)}catch(e){}}await sleep(15000)}
if(sid===nSid&&!NET.on)nStatus('Room announcement stopped after 5 min. Tap HOST GAME again.')}
$('cpsrch').onclick=async()=>{AC();const box=$('cprooms'),my=++nSrT;box.innerHTML='';nStatus('Searching for rooms...');let T;try{T=await nTopics()}catch(e){return nStatus(nBlk())}
const tps=T.lan.map(t=>[t,1]).concat([[T.glob,0]]),t0=Date.now();let key='';
while(my===nSrT&&!NET.on&&Date.now()-t0<45000){const rm=new Map();let ok=0;
await Promise.all(tps.map(async([tp,ln])=>{try{const ms=await ntGet(tp,'40s');ok=1;for(const m of ms){let o;try{o=JSON.parse(m.message)}catch(e){continue}if(o&&typeof o.c==='string'&&/^[A-Z0-9]{4,8}$/.test(o.c)&&o.c!==$('cpout').value){const p=rm.get(o.c);if(!p||ln)rm.set(o.c,{c:o.c,n:o.n,ln:ln})}}}catch(e){}}));
if(my!==nSrT||NET.on)return;if(!ok)return nStatus(nBlk());
const ar=[...rm.values()].sort((x,y)=>y.ln-x.ln||(x.c<y.c?-1:1)),k=ar.map(o=>o.c+o.ln).join(',');
if(k!==key){key=k;box.innerHTML='';for(const o of ar){const b=document.createElement('button');b.className='sm';b.style.cssText='display:block;width:100%;margin:3px 0;border-color:#7fff9a;color:#7fff9a';b.textContent=(o.ln?'NEARBY \u25B6 ':'ONLINE \u25B6 ')+String(o.n||o.c).slice(0,24);b.onclick=()=>{nSrT++;$('cpin').value=o.c;box.innerHTML='';$('cpjoin').click()};box.appendChild(b)}}
nStatus(ar.length?'Room found! Tap it to join.':'Searching... the host must have tapped HOST GAME (stay on the same hotspot).');await sleep(4000)}
if(my===nSrT&&!NET.on&&!key)nStatus('No room found. Host must tap HOST GAME and wait for ROOM READY, then tap SEARCH ROOMS again.')};
$('cphost').onclick=()=>{AC();nReset();NET.h=1;const sid=nSid,code=nCode();$('cpout').value='';nStatus('Creating code...');
const ready=()=>{if(NET.ok||sid!==nSid)return;NET.ok=1;$('cpout').value=code;nBeacon(code,sid);nStatus('ROOM READY - your friend: tap SEARCH ROOMS and tap your room. (Or send the code: '+code+')')};
hostNtfy(code,sid,ready).catch(()=>{});peerReady(()=>{if(sid===nSid)hostPeer(code,sid,ready)});
setTimeout(()=>{if(sid===nSid&&!NET.ok){nStatus(nBlk());nReset()}},20000)};
$('cpjoin').onclick=()=>{AC();const code=$('cpin').value.toUpperCase().replace(/[^A-Z0-9]/g,'');if(code.length<4)return nStatus('ENTER THE HOST CODE FIRST');
nReset();NET.g=1;const sid=nSid;let fl=0;const nb=2;nStatus('Connecting...');
const fail=why=>{if(sid!==nSid)return;if(++fl>=nb){nStatus((nCsp||why==='code server blocked'||why==='network blocked'?nBlk():'COULD NOT CONNECT ('+why+'). Check the code - the host must tap HOST GAME first.'));nReset()}};
joinNtfy(code,sid,fail).catch(()=>fail('network blocked'));peerReady(()=>{if(sid!==nSid)return;if(window.Peer)joinPeer(code,sid,fail);else fail('PeerJS unavailable')});
setTimeout(()=>{if(sid===nSid&&!NET.on){nStatus('STILL NOT CONNECTED - check the code, or use MANUAL MODE below');nReset()}},30000)};
$('cpmh').onclick=async()=>{try{AC();nReset();NET.h=1;const pc=nPcNew('mn'),dc=pc.createDataChannel('c');dc.onopen=()=>{if(!NET.ch)nBind(dc,'mn')};NET.pc=pc;nStatus('Creating manual code...');await pc.setLocalDescription(await pc.createOffer());await nIce(pc);$('cpmout').value=nEnc(pc.localDescription);nStatus('1) COPY the long code, send it to your brother. 2) Paste his reply code in the lower box, tap CONNECT.')}catch(e){nStatus('MANUAL MODE NOT SUPPORTED ON THIS BROWSER')}};
$('cpmj').onclick=async()=>{try{AC();const off=nDec($('cpmin').value);nReset();NET.g=1;const pc=nPcNew('mn');NET.pc=pc;pc.ondatachannel=e=>{const dc=e.channel,go=()=>{if(!NET.ch)nBind(dc,'mn')};dc.onopen=go;if(dc.readyState==='open')go()};await pc.setRemoteDescription(off);await pc.setLocalDescription(await pc.createAnswer());nStatus('Creating reply code...');await nIce(pc);$('cpmout').value=nEnc(pc.localDescription);nStatus('COPY the reply code and send it back to the host. Keep this screen open.')}catch(e){nReset();nStatus('INVALID CODE')}};
$('cpgo').onclick=async()=>{try{if(!NET.h||!NET.pc)return nStatus('Tap MANUAL HOST first');await NET.pc.setRemoteDescription(nDec($('cpmin').value));nStatus('Connecting...')}catch(e){nStatus('INVALID CODE')}};
$('cpmcopy').onclick=()=>{const t=$('cpmout');t.select();try{navigator.clipboard.writeText(t.value)}catch(e){try{document.execCommand('copy')}catch(x){}}nStatus('COPIED')};
$('cpcopy').onclick=()=>{const t=$('cpout');t.select();try{navigator.clipboard.writeText(t.value)}catch(e){try{document.execCommand('copy')}catch(x){}}nStatus('COPIED')};
let pnetOn=0;const MK=[null,null];
function netBeat(dt){NET.pt=(NET.pt||0)-dt;if(NET.pt<=0){NET.pt=1.5;nSend({k:'png',t:Math.round(performance.now())})}
const q=performance.now()-(NET.last||performance.now());if(q>45000){nDown();return}
const bad=q>5000,t=bad?'NO SIGNAL · '+Math.round(q/1000)+'s':'CO-OP · '+Math.round(NET.rtt||0)+' ms',e=$('pnet');
if(e._t!==t){e._t=t;e.textContent=t;e.style.color=bad||NET.rtt>300?'#ff6a5a':NET.rtt>150?'#ffd060':'#7fff9a'}if(!pnetOn){pnetOn=1;e.style.display='block'}}
function mkSet(i,x,y,z,g){MK[i]={x:x,y:y,z:z,g:g||'',t:10};if(i){tn(1100,1500,.12,.25);pop('PARTNER MARKED '+(g||'A POSITION'))}}
function mkPing(){if(!run||paused||cin||!NET.on||PV.on)return;ray.setFromCamera({x:0,y:0},cam);ray.far=140;const hs=ray.intersectObjects(solids.concat(enemies,tgObjs),true);let p,g='';
if(hs.length){p=hs[0].point.clone();let o=hs[0].object;while(o&&!o.userData.e&&!o.userData.tg)o=o.parent;if(o)g=o.userData.tg?'TARGET':'ENEMY'}else p=ray.ray.origin.clone().addScaledVector(ray.ray.direction,60);
mkSet(0,p.x,p.y,p.z,g);nSend({k:'mk',x:r2(p.x),y:r2(p.y),z:r2(p.z),g:g});tn(900,1400,.1,.22)}
function mkTick(dt){for(let i=0;i<2;i++){const el=$('mk'+i),m=MK[i];
if(!m||!run||cin||paused||!NET.on){if(el._v){el._v=0;el.style.display='none'}if(m&&!NET.on)MK[i]=null;continue}
m.t-=dt;if(m.t<=0){MK[i]=null;el._v=0;el.style.display='none';continue}
cam.updateMatrixWorld();v3.set(m.x,m.y+.7,m.z).project(cam);if(v3.z>1){if(el._v){el._v=0;el.style.display='none'}continue}
const w=VW(),h=VH(),x=clamp((v3.x*.5+.5)*w,30,w-30),y=clamp((-v3.y*.5+.5)*h,50,h-50),d=Math.round(Math.hypot(m.x-P.x,m.z-P.z)),t='◆ '+(i?'PARTNER':'YOU')+(m.g?' · '+m.g:'')+'<br>'+d+'m';
if(el._t!==t){el._t=t;el.innerHTML=t}if(!el._v){el._v=1;el.style.display='block'}el.style.transform='translate('+Math.round(x)+'px,'+Math.round(y)+'px) translate(-50%,-50%)'}}
function ptagTick(){const e=$('ptag'),a=(NET.on&&!PV.on&&run&&!paused&&!cin)?(NET.h?NET.rm:NET.hm):null;
if(!a||!a.parent||a.userData.dead){if(e._v){e._v=0;e.style.display='none'}return}
cam.updateMatrixWorld();v3.set(a.position.x,a.position.y+2.25,a.position.z).project(cam);if(v3.z>1){if(e._v){e._v=0;e.style.display='none'}return}
const w=VW(),h=VH(),x=(v3.x*.5+.5)*w,y=(-v3.y*.5+.5)*h,hp=clamp(NET.php==null?100:NET.php,0,100),d=Math.round(Math.hypot(a.position.x-P.x,a.position.z-P.z)),
t='<div>'+(NET.pdn?'\u2716 DOWNED \u00b7 '+(NET.rvp>0?'REVIVING '+Math.round(NET.rvp/3*100)+'%':'GET CLOSE TO REVIVE'):(NET.h?'PLAYER 2':'HOST')+' \u00b7 '+d+'m')+'</div><div class="ptb"><i style="width:'+hp+'%;background:'+(hp>60?'#7fb04a':hp>30?'#e0b030':'#d04030')+'"></i></div>';
if(e._t!==t){e._t=t;e.innerHTML=t}if(!e._v){e._v=1;e.style.display='block'}e.style.transform='translate('+Math.round(x)+'px,'+Math.round(y)+'px) translate(-50%,-100%)'}
function specCam(dt){NET.dnT=Math.max(0,(NET.dnT||0)-dt);const a=NET.h?NET.gm:(NET.hm&&NET.hm.userData.tp);let x=P.x,y=P.y,z=P.z;if(a){x=a[0];y=a[1];z=a[2]}
cam.position.set(x+Math.sin(time*.3)*3,y+3.2,z+4+Math.cos(time*.3));cam.lookAt(x,y-.4,z);if(Math.abs(cam.fov-CFG.fov)>.05){cam.fov=CFG.fov;cam.updateProjectionMatrix()}
const n=Math.ceil(NET.dnT);if(n!==NET.dnN){NET.dnN=n;pvBanner('DOWN - REVIVE OR RESPAWN IN '+n,1100)}}
function hDie(){downMe()}
function downMe(){run=false;firing=false;adsOn=false;mv.x=mv.y=0;ctl(0);resetGun();NET.dn=1;NET.dnT=10;NET.dnN=-1;$('dmg').style.opacity=0;pop('YOU ARE DOWN - YOUR PARTNER CAN REVIVE YOU');
nSend({k:'dn',v:1});nSend({k:'pop',x:(NET.h?'PLAYER 1':'PLAYER 2')+' DOWN - GO REVIVE!'});clearTimeout(NET.rtm);NET.rtm=setTimeout(()=>upMe(0),10000)}
function upMe(rv){if(!NET.dn)return;clearTimeout(NET.rtm);NET.dn=0;$('title').style.display='none';nSend({k:'dn',v:0});
if(rv){P.hp=50;P.hurtT=0;pop('REVIVED!')}else{const g=NET.h?NET.gm:(NET.hm&&NET.hm.userData.tp);P.hp=100;P.hurtT=99;if(g){P.x=g[0]+1.5;P.z=g[2]+1.5;P.y=Math.max(1.7,g[1])}else if(NET.h){P.x=cp.x;P.z=cp.z;P.y=1.7}refillAll()}
P.vy=0;P.ground=true;hitFlash=0;dindT=0;lhB=-1;rd.domElement.style.filter='';if(!cin){run=true;ctl(1)}}
function revTick(dt){if(!NET.on||PV.on||!run||cin||paused||!NET.pdn){NET.rvp=0;return}const g=NET.h?NET.gm:(NET.hm&&NET.hm.userData.tp);if(!g){NET.rvp=0;return}
if(Math.hypot(g[0]-P.x,g[2]-P.z)<2.8&&Math.abs(g[1]-P.y)<2.5){NET.rvp+=dt;if(NET.rvp>=3){NET.rvp=0;NET.pdn=0;nSend({k:'rv'});score+=100;pop('PARTNER REVIVED +100');tn(520,880,.18,.3);setTimeout(()=>tn(880,1100,.14,.25),120)}}else NET.rvp=Math.max(0,NET.rvp-dt*1.5)}
const CM=['ENEMY SPOTTED!','COVER ME!','NEED AMMO!','NEED HELP!','MOVE UP!','HOLD HERE!','THANKS!','ON MY WAY!'];let cmOpen=0;
const esc=q=>String(q).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function cmToggle(v){const p=$('cmp');if(v===undefined)v=cmOpen?0:1;if(v&&(!NET.on||PV.on||!run||cin||paused))v=0;cmOpen=v;p.style.display=v?'grid':'none'}
function showComm(w,t){sub(esc(w),esc(t));clearTimeout(rt);rt=setTimeout(()=>sub('',''),3800);tn(1000,1300,.08,.18)}
function cmSend(i){if(i===8){cmToggle(0);const t=(window.prompt('Message to partner:','')||'').trim().slice(0,80);if(t){nSend({k:'cm',s:t});showComm('YOU',t)}return}if(!CM[i])return;nSend({k:'cm',i:i});showComm('YOU',CM[i]);cmToggle(0)}
function cmKey(e){const q=/^Digit([1-9])$/.exec(e.code);if(q){cmSend(+q[1]-1);return true}if(e.code==='KeyC'||e.code==='Escape'){cmToggle(0);return true}return false}
{const p=$('cmp');CM.concat(['TYPE MESSAGE...']).forEach((t,i)=>{const b=document.createElement('button');b.className='sm';b.textContent=(i+1)+'. '+t;const f=()=>cmSend(i);b.addEventListener('touchstart',e=>{e.preventDefault();e.stopPropagation();f()},{passive:false});b.addEventListener('click',f);p.appendChild(b)});
btn('cmb',()=>cmToggle(),null);$('cmb').addEventListener('click',()=>cmToggle())}
