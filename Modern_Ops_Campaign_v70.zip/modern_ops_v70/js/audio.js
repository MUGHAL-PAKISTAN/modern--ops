'use strict';
/* v70 audio engine: 100% procedural Web Audio (oscillators + noise buffers). No audio files.
   Shares the global scope with game.js (loaded before it); everything touching game state runs at call time. */
let ac=null,mg=null,nbuf=null;
let SND_ON=true;try{SND_ON=localStorage.getItem('mo_snd')!=='0'}catch(e){}
let rvb=null,PJV=1;
const pj=r=>1+(Math.random()-.5)*2*r;
function withPJ(v,fn){PJV=v;try{fn()}finally{PJV=1}}

// ---------- context + iOS/Android autoplay unlock (starts on the first tap, never before)
function AC(){if(ac)return ac;try{ac=new(window.AudioContext||window.webkitAudioContext)();mg=ac.createGain();mg.gain.value=.9*CFG.vol;const cp2=ac.createDynamicsCompressor();mg.connect(cp2);cp2.connect(ac.destination);
if(!LITE){try{rvb=ac.createConvolver();const L=(ac.sampleRate*1.1)|0,ir=ac.createBuffer(2,L,ac.sampleRate);for(let c=0;c<2;c++){const d=ir.getChannelData(c);let y=0;for(let i=0;i<L;i++){y+=((Math.random()*2-1)-y)*.22;d[i]=y*Math.pow(1-i/L,3.2)}}rvb.buffer=ir;const rg=ac.createGain();rg.gain.value=.34;rvb.connect(rg);rg.connect(mg)}catch(e){rvb=null}}
nbuf=ac.createBuffer(1,ac.sampleRate*2,ac.sampleRate);const d=nbuf.getChannelData(0);for(let i=0;i<d.length;i++)d[i]=Math.random()*2-1}catch(e){ac=null}return ac}
function audioUnlock(){const a=AC();if(!a)return;if(a.state!=='running'){try{const p=a.resume();p&&p.catch&&p.catch(()=>{})}catch(e){}}
try{const b=a.createBuffer(1,1,22050),s=a.createBufferSource();s.buffer=b;s.connect(a.destination);s.start(0)}catch(e){}}
{const evs=['touchstart','touchend','pointerdown','mousedown','click','keydown'],un=()=>{audioUnlock();if(ac&&ac.state==='running')evs.forEach(e=>removeEventListener(e,un,true))};evs.forEach(e=>addEventListener(e,un,true));
document.addEventListener('visibilitychange',()=>{try{if(!document.hidden&&ac&&ac.state!=='running'&&!paused)ac.resume()}catch(e){}})}

function route(n,pan,rv){if(rv&&rvb)n.connect(rvb);if(pan&&ac.createStereoPanner){const p=ac.createStereoPanner();p.pan.value=clamp(pan,-1,1);n.connect(p);p.connect(mg)}else n.connect(mg)}
// noise burst through a sweeping filter
function nz(dur,f0,f1,vol,type,pan){if(!SND_ON)return;const a=AC();if(!a)return;f0*=PJV;f1*=PJV;const s=a.createBufferSource();s.buffer=nbuf;s.loop=true;const f=a.createBiquadFilter();f.type=type||'lowpass';f.frequency.setValueAtTime(f0,a.currentTime);f.frequency.exponentialRampToValueAtTime(Math.max(20,f1),a.currentTime+dur);const g=a.createGain();g.gain.setValueAtTime(vol,a.currentTime);g.gain.exponentialRampToValueAtTime(.0008,a.currentTime+dur);s.connect(f);f.connect(g);route(g,pan,vol>=.3&&dur>=.15);s.start(a.currentTime,Math.random());s.stop(a.currentTime+dur+.02)}
// oscillator with pitch sweep
function tn(f0,f1,dur,vol,type,pan){if(!SND_ON)return;const a=AC();if(!a)return;f0*=PJV;f1*=PJV;const o=a.createOscillator();o.type=type||'sine';o.frequency.setValueAtTime(f0,a.currentTime);o.frequency.exponentialRampToValueAtTime(Math.max(20,f1),a.currentTime+dur);const g=a.createGain();g.gain.setValueAtTime(vol,a.currentTime);g.gain.exponentialRampToValueAtTime(.0008,a.currentTime+dur);o.connect(g);route(g,pan,vol>=.3&&dur>=.15);o.start();o.stop(a.currentTime+dur+.02)}
// scheduled note (jingles / horn)
function note(f,t0,dur,vol,type,lp){const a=ac;if(!a||!SND_ON)return;const o=a.createOscillator(),g=a.createGain();o.type=type||'triangle';o.frequency.value=f;g.gain.setValueAtTime(0,t0);g.gain.linearRampToValueAtTime(vol,t0+.012);g.gain.exponentialRampToValueAtTime(.001,t0+dur);o.connect(g);if(lp){const q=a.createBiquadFilter();q.type='lowpass';q.frequency.value=lp;g.connect(q);route(q,0,true)}else route(g,0,true);o.start(t0);o.stop(t0+dur+.03)}

// ---------- weapons: rifle = deep thump, pistol = sharp crack, sniper = boom + echo (+/-7% random pitch every shot)
const sShot=()=>{nz(.22,5000,300,.9);nz(.08,9000,2000,.3,'highpass');tn(150,45,.16,.8);nz(.5,600,120,.2)};
function sShotW(s,id){const vj=.92+Math.random()*.16,pv=pj(.07),eco=()=>!LITE;
withPJ(pv,()=>{
if(id==='snp'){nz(.5,3200,120,1.35*vj);tn(84,24,.55,1.3*vj);tn(165,45,.22,.7*vj,'triangle');nz(.07,9000,2500,.4*vj,'highpass');nz(1,420,70,.5*vj);
setTimeout(()=>withPJ(pv,()=>{nz(.7,900,120,.34*vj,'lowpass');tn(70,30,.5,.3*vj)}),190);setTimeout(()=>withPJ(pv,()=>nz(1.1,520,80,.2*vj,'lowpass')),470);if(eco())setTimeout(()=>withPJ(pv,()=>nz(1.4,320,60,.1*vj,'lowpass')),820)}
else if(id==='pi'){nz(.09,8000,1500,.85*vj,'highpass');nz(.07,7000,900,.6*vj,'bandpass');tn(430,130,.06,.55*vj,'triangle');tn(185,70,.08,.4*vj);nz(.22,1600,300,.18*vj)}
else switch(s){
case 1:nz(.25,4300,260,vj);nz(.08,9000,2000,.35*vj,'highpass');tn(128,40,.18,.9*vj);nz(.55,520,110,.25*vj);break;
case 2:nz(.3,3800,200,1.05*vj);tn(105,35,.2,vj);tn(62,28,.16,.55*vj);nz(.6,450,90,.3*vj);break;
case 3:nz(.1,6500,700,.35*vj);nz(.04,9000,3000,.15*vj,'highpass');tn(210,90,.06,.35*vj);break;
case 4:nz(.4,3000,150,1.3*vj);tn(80,28,.32,1.2*vj);nz(.8,420,80,.45*vj);nz(.06,9000,2500,.35*vj,'highpass');break;
case 5:nz(.3,6000,250,1.05*vj);nz(.05,10000,3500,.55*vj,'highpass');tn(95,30,.4,1.1*vj);nz(.9,500,90,.35*vj);break;
case 6:nz(.12,6500,500,.7*vj);nz(.05,9000,3000,.3*vj,'highpass');tn(270,90,.09,.55*vj);nz(.3,700,200,.15*vj);break;
default:nz(.22,5000,300,.9*vj);nz(.06,9000,2200,.3*vj,'highpass');tn(142,42,.17,.95*vj);tn(68,32,.14,.6*vj);nz(.5,600,110,.22*vj)}})}
// reload: mag out (click) -> mag in (clack) -> cock (metallic snap)
function sMagOut(){withPJ(pj(.05),()=>{nz(.025,6500,3000,.5,'highpass');tn(1100,500,.035,.3,'square');nz(.08,1800,500,.3,'bandpass');tn(160,90,.06,.25)})}
function sMagIn(){withPJ(pj(.05),()=>{nz(.05,3000,700,.6,'bandpass');tn(230,120,.07,.6,'triangle');tn(90,50,.08,.5);nz(.03,6000,2500,.3,'highpass')})}
function sCock(){withPJ(pj(.04),()=>{nz(.03,9000,4000,.6,'highpass');tn(2400,1400,.05,.18,'square');tn(1250,900,.09,.2,'triangle');tn(3700,3600,.08,.07,'sine');nz(.07,3800,1200,.45,'bandpass')});setTimeout(()=>withPJ(1,()=>{tn(1800,1100,.04,.2,'square');nz(.04,6000,2500,.3,'highpass')}),70)}
function sRack(){withPJ(pj(.05),()=>{nz(.09,2200,500,.4,'bandpass');tn(300,160,.08,.35,'triangle')})}

// ---------- footsteps: soft thud; sprint = louder (the game also steps faster); crouch = quieter; stops when the player stops
function stepSnd(v,pan,sf){switch(sf){case'metal':tn(430+R()*60,300,.09,v*.45,'triangle',pan);nz(.05,5200,2200,v*.4,'bandpass',pan);tn(110,55,.06,v*.5,'sine',pan);break;case'wood':tn(190,110,.09,v*.9,'sine',pan);nz(.05,1300,300,v*.6,'lowpass',pan);break;case'gravel':nz(.1,4200,1500,v*.65,'highpass',pan);nz(.07,2200,700,v*.5,'bandpass',pan);tn(90,50,.05,v*.4,'sine',pan);break;case'sand':nz(.11,1900,500,v*.55,'lowpass',pan);tn(85,48,.06,v*.35,'sine',pan);break;case'soft':nz(.09,750,220,v*.6,'lowpass',pan);tn(80,45,.07,v*.4,'sine',pan);break;default:nz(.06,3200,800,v*.6,'bandpass',pan);nz(.05,520,160,v*.7,'lowpass',pan);tn(100,52,.06,v*.6,'sine',pan)}}
function sStep(sprint,sf){const v=(sprint?.17:.085)*(CR.on?.55:1)*(.88+Math.random()*.24);withPJ(pj(.1),()=>stepSnd(v,0,sf))}

// ---------- hit confirm: tick on body hit, higher ding on headshot
function sHitMk(head){if(!SND_ON)return;withPJ(1,()=>{if(head){tn(2600,2600,.05,.26,'sine');tn(3900,3800,.15,.2,'sine');tn(1300,1300,.1,.08,'triangle')}else{tn(1900,1500,.035,.2,'square');nz(.02,6000,3500,.1,'highpass')}})}

// ---------- damage: low heartbeat + grunt (HP < 30)
let hbSnd=0,gruntT=0;
function sHeart(k){const n=performance.now();if(!SND_ON||n-hbSnd<420)return;hbSnd=n;const v=.28+.3*(k==null?1:k);tn(60,38,.15,v);setTimeout(()=>tn(52,34,.13,v*.7),165)}
function sGrunt(){const t=performance.now();if(!SND_ON||t-gruntT<1400)return;gruntT=t;const a=AC();if(!a)return;const T=a.currentTime,o=a.createOscillator(),f0=100+Math.random()*28;o.type='sawtooth';o.frequency.setValueAtTime(f0*1.12,T);o.frequency.exponentialRampToValueAtTime(f0*.7,T+.22);
const q1=a.createBiquadFilter(),q2=a.createBiquadFilter(),g=a.createGain();q1.type=q2.type='bandpass';q1.frequency.value=650;q1.Q.value=3;q2.frequency.value=1150;q2.Q.value=4;g.gain.setValueAtTime(0,T);g.gain.linearRampToValueAtTime(.5,T+.03);g.gain.exponentialRampToValueAtTime(.001,T+.27);
o.connect(q1);o.connect(q2);q1.connect(g);q2.connect(g);route(g,0,false);o.start(T);o.stop(T+.3);nz(.12,1400,300,.2,'bandpass')}

// ---------- UI + round sounds
let uiAt=0;
function sUI(){const n=performance.now();if(!SND_ON||n-uiAt<40)return;uiAt=n;withPJ(1,()=>{tn(1400,900,.03,.16,'square');nz(.02,7000,3500,.08,'highpass')})}
function hornTone(f,t0,dur,vol){const a=ac,o=a.createOscillator(),o2=a.createOscillator(),lp=a.createBiquadFilter(),g=a.createGain();o.type=o2.type='sawtooth';o.frequency.value=f;o2.frequency.value=f*1.006;lp.type='lowpass';lp.frequency.value=1100;g.gain.setValueAtTime(0,t0);g.gain.linearRampToValueAtTime(vol,t0+.06);g.gain.setValueAtTime(vol,t0+dur-.12);g.gain.exponentialRampToValueAtTime(.001,t0+dur);o.connect(lp);o2.connect(lp);lp.connect(g);route(g,0,true);o.start(t0);o2.start(t0);o.stop(t0+dur+.05);o2.stop(t0+dur+.05)}
function sHorn(){if(!SND_ON||!AC())return;const t=ac.currentTime+.02;hornTone(233,t,.5,.2);hornTone(233,t+.65,.95,.24);hornTone(349,t+.65,.95,.12)}
function sWin(){if(!SND_ON||!AC())return;const t=ac.currentTime+.02;[523,659,784,1047].forEach((f,i)=>note(f,t+i*.13,i===3?1:.3,.2,'triangle',4200));note(1568,t+.52,.9,.07,'sine');note(262,t+.52,1,.12,'sine')}
function sOver(){if(!SND_ON||!AC())return;const t=ac.currentTime+.02;[392,370,311,262].forEach((f,i)=>note(f,t+i*.34,i===3?1.6:.5,.16,'sawtooth',900));tn(70,28,1.4,.5);nz(1.2,500,60,.25,'lowpass')}
function sBanner(t){const s=String(t).toUpperCase();if(/ROUND WON|VICTORY/.test(s))sWin();else if(/ROUND LOST|DEFEAT/.test(s))sOver();else if(/ROUND DRAW/.test(s))sUI();else if(/ROUND \d|GET READY/.test(s))sHorn()}

// ---------- revive: healing beep loop while the partner is being revived (driven by NET.rvp)
const REV={t:0};
function sRevBeep(p){withPJ(1,()=>{tn(660+p*400,880+p*500,.09,.15,'sine');setTimeout(()=>tn(990+p*400,1320+p*300,.1,.13,'sine'),110)})}

// ---------- far gunfire / explosions / enemy hit + death (unchanged from v67-v69)
const sFar=(d,pan,f)=>{const v=.5/(1+d*.06);nz(.2,(f||2600)/(1+d*.02),200,v,'lowpass',pan);tn(110,50,.12,v*.7,'sine',pan)};
const sClick=(v,f)=>{nz(.03,6000,3000,v,'highpass');tn(f,f*.5,.04,v*.5,'square')};
const sBoom=(d,pan)=>{if(!AC())return;const v=clamp(1.25/(1+d*.05),0,1.25),mf=Math.max(500,5200/(1+d*.04)),dl=Math.min(1.2,d/160)*1000;
const go=()=>{nz(.07,10000,2500,v*.8,'highpass',pan);nz(.35,mf,160,v*1.15,'lowpass',pan);nz(.9,mf*.5,70,v*.9,'lowpass',pan);tn(95,24,1.2,v*1.25,'sine',pan);tn(52,16,1.9,v*1.1,'sine',pan);tn(180,50,.3,v*.5,'triangle',pan);
setTimeout(()=>{nz(2.4,420,38,v*.55,'lowpass',pan);tn(38,14,2.2,v*.5,'sine',pan)},180+d*6);
setTimeout(()=>nz(1.2,900,150,v*.28,'bandpass',pan),380+d*14);
for(let i=0;i<8;i++)setTimeout(()=>{nz(.04+R()*.05,3500+R()*3000,900,.1*v,'bandpass',pan);if(i%3===0)tn(900+R()*600,300,.05,.04*v,'triangle',pan)},700+i*(90+R()*140)+d*10);
if(d<16&&mg&&run){const t=ac.currentTime;mg.gain.cancelScheduledValues(t);mg.gain.setValueAtTime(mg.gain.value,t);mg.gain.linearRampToValueAtTime(.25*CFG.vol,t+.05);mg.gain.linearRampToValueAtTime(.9*CFG.vol,t+3.2);tn(4800,4600,2.4,.05*(1-d/16),'sine')}};
if(dl>30)setTimeout(go,dl);else go()};
function panOf(x,z){return((x-P.x)*Math.cos(P.yaw)-(z-P.z)*Math.sin(P.yaw))/(Math.hypot(x-P.x,z-P.z)+1)}
let hitSfxT=-1e9;
function sHitE(e,byP,head){const t=performance.now();if(t-hitSfxT<45)return;hitSfxT=t;const d=Math.hypot(e.position.x-P.x,e.position.z-P.z),v=byP?.55:clamp(.5/(1+d*.08),.05,.4),pan=panOf(e.position.x,e.position.z);nz(.07,1900,420,v*.55,'lowpass',pan);tn(190,70,.08,v*.5,'sine',pan);if(head)tn(1100,520,.05,v*.3,'triangle',pan)}
function sDieE(e,byP,head){const d=Math.hypot(e.position.x-P.x,e.position.z-P.z),v=clamp(1.1/(1+d*.07),.1,.9),pan=panOf(e.position.x,e.position.z);nz(.42,1000,140,v*.6,'lowpass',pan);tn(170,58,.4,v*.45,'triangle',pan);setTimeout(()=>{if(SND_ON){nz(.14,520,150,v*.4,'lowpass',pan);tn(75,40,.12,v*.45,'sine',pan)}},280)}

// ---------- low war music (in mission) + very low wind (menu / lobby)
const MUS={on:false,bus:null,o:null,nodes:[],timer:0,next:0,step:0};
function musicStart(){if(MUS.on||!SND_ON)return;const a=AC();if(!a||!mg)return;MUS.on=true;
const bus=a.createGain();bus.gain.setValueAtTime(0,a.currentTime);bus.gain.linearRampToValueAtTime(1,a.currentTime+2.5);bus.connect(mg);
const lp=a.createBiquadFilter();lp.type='lowpass';lp.frequency.value=260;lp.Q.value=.7;const dg=a.createGain();dg.gain.value=.1;lp.connect(dg);dg.connect(bus);
const mk=(type,f,det,g)=>{const o=a.createOscillator();o.type=type;o.frequency.value=f;o.detune.value=det;const gg=a.createGain();gg.gain.value=g;o.connect(gg);gg.connect(lp);o.start();MUS.nodes.push(o);return o};
MUS.o=[mk('sawtooth',55,-6,.5),mk('sawtooth',55,7,.5),mk('sine',27.5,0,.9),mk('triangle',82.4,0,.25)];
const lf=a.createOscillator();lf.frequency.value=.06;const lg=a.createGain();lg.gain.value=70;lf.connect(lg);lg.connect(lp.frequency);lf.start();MUS.nodes.push(lf);
MUS.bus=bus;MUS.next=a.currentTime+.1;MUS.step=0;MUS.timer=setInterval(musicTick,90)}
function musicTick(){const a=ac;if(!a||!MUS.on)return;if(MUS.next<a.currentTime-.2)MUS.next=a.currentTime+.05;
while(MUS.next<a.currentTime+.28){try{musicStep(MUS.next,MUS.step)}catch(e){}MUS.next+=.125;MUS.step=(MUS.step+1)%64}}
function musicStep(t,s){const a=ac,bus=MUS.bus;if(!bus)return;const st=s%16;
if(st===0){const r=[55,49,43.65,49][(s/16|0)%4];MUS.o[0].frequency.setTargetAtTime(r,t,.9);MUS.o[1].frequency.setTargetAtTime(r,t,.9);MUS.o[2].frequency.setTargetAtTime(r/2,t,.9);MUS.o[3].frequency.setTargetAtTime(r*1.5,t,.9)}
const hit=(f0,f1,d,v)=>{const o=a.createOscillator(),g=a.createGain();o.type='sine';o.frequency.setValueAtTime(f0,t);o.frequency.exponentialRampToValueAtTime(f1,t+d);g.gain.setValueAtTime(v,t);g.gain.exponentialRampToValueAtTime(.0008,t+d);o.connect(g);g.connect(bus);o.start(t);o.stop(t+d+.02)};
const sn=(v,d)=>{const q=a.createBufferSource();q.buffer=nbuf;q.loop=true;const f=a.createBiquadFilter();f.type='bandpass';f.frequency.value=1600;f.Q.value=.8;const g=a.createGain();g.gain.setValueAtTime(v,t);g.gain.exponentialRampToValueAtTime(.0008,t+d);q.connect(f);f.connect(g);g.connect(bus);q.start(t,Math.random());q.stop(t+d+.02)};
if(st===0||st===10)hit(95,42,.45,.16);else if(st===6||st===14)hit(80,38,.3,.08);
if(st===8)sn(.04,.14);else if(st===7||st===15)sn(.015,.07);
if(s%32===24&&Math.random()<.5){const q=a.createBufferSource();q.buffer=nbuf;q.loop=true;const f=a.createBiquadFilter();f.type='lowpass';f.frequency.setValueAtTime(420,t);f.frequency.exponentialRampToValueAtTime(60,t+1.3);const g=a.createGain();g.gain.setValueAtTime(.09,t);g.gain.exponentialRampToValueAtTime(.0008,t+1.4);q.connect(f);f.connect(g);g.connect(bus);q.start(t,Math.random());q.stop(t+1.45);hit(62,28,1.1,.1)}}
function musicStop(){if(!MUS.on)return;MUS.on=false;clearInterval(MUS.timer);const a=ac,bus=MUS.bus,nodes=MUS.nodes;MUS.nodes=[];MUS.bus=null;
try{const t=a.currentTime;bus.gain.cancelScheduledValues(t);bus.gain.setValueAtTime(bus.gain.value,t);bus.gain.linearRampToValueAtTime(0,t+.8)}catch(e){}
setTimeout(()=>{for(const o of nodes){try{o.stop()}catch(e){}}try{bus.disconnect()}catch(e){}},900)}
const WIND={on:0,nodes:[],g:null,buf:null};
function windStart(){const a=AC();if(!a||WIND.on||!SND_ON)return;WIND.on=1;
if(!WIND.buf){const n=a.sampleRate*6,b=a.createBuffer(1,n,a.sampleRate),d=b.getChannelData(0);let y=0;for(let i=0;i<n;i++){y+=((Math.random()*2-1)-y)*.05;d[i]=y*4}WIND.buf=b}
const s=a.createBufferSource();s.buffer=WIND.buf;s.loop=true;const bp=a.createBiquadFilter();bp.type='bandpass';bp.frequency.value=380;bp.Q.value=.6;const g=a.createGain();g.gain.setValueAtTime(0,a.currentTime);g.gain.linearRampToValueAtTime(.05,a.currentTime+3);
const l1=a.createOscillator();l1.frequency.value=.07;const k1=a.createGain();k1.gain.value=150;l1.connect(k1);k1.connect(bp.frequency);const l2=a.createOscillator();l2.frequency.value=.13;const k2=a.createGain();k2.gain.value=.018;l2.connect(k2);k2.connect(g.gain);
s.connect(bp);bp.connect(g);g.connect(mg);s.start();l1.start();l2.start();WIND.nodes=[s,l1,l2];WIND.g=g}
function windStop(){if(!WIND.on)return;WIND.on=0;const n=WIND.nodes,g=WIND.g;WIND.nodes=[];WIND.g=null;try{const t=ac.currentTime;g.gain.cancelScheduledValues(t);g.gain.setValueAtTime(g.gain.value,t);g.gain.linearRampToValueAtTime(0,t+.6)}catch(e){}setTimeout(()=>{for(const o of n){try{o.stop()}catch(e){}}try{g.disconnect()}catch(e){}},800)}
function musicWatch(){let want=false,wind=false;try{want=SND_ON&&run&&!(PV&&PV.on);wind=SND_ON&&!run&&!cin&&(inLobby||getComputedStyle($('menu')).display!=='none')}catch(e){}
if(want&&!MUS.on)musicStart();else if(!want&&MUS.on)musicStop();if(wind&&!WIND.on&&ac&&ac.state==='running')windStart();else if(!wind&&WIND.on)windStop()}
setInterval(musicWatch,300);
// run edge -> round-start horn (not repeated within 20 s); revive beeps while NET.rvp is climbing
{let rp=false,hAt=0;setInterval(()=>{try{const r=!!run;if(r&&!rp&&!PV.on&&performance.now()-hAt>20000){hAt=performance.now();sHorn()}rp=r;
if(typeof NET!=='undefined'&&NET.rvp>0&&SND_ON){REV.t-=.12;if(REV.t<=0){REV.t=.36;sRevBeep(Math.min(1,NET.rvp/3))}}else REV.t=0}catch(e){}},120)}

// ---------- settings: sound on/off + master volume slider (the VOLUME slider is the game's existing CFG.vol)
function sndUI(){const t=SND_ON?'ON':'OFF',a=$('sndb'),b=$('psnd');if(a)a.textContent='Sound: '+t;if(b)b.textContent='SOUND: '+t;document.querySelectorAll('#sbody button[data-snd]').forEach(x=>x.classList.toggle('on',(x.dataset.snd==='1')===SND_ON))}
function sndToggle(){SND_ON=!SND_ON;try{localStorage.setItem('mo_snd',SND_ON?'1':'0')}catch(e){}if(!SND_ON){try{speechSynthesis.cancel()}catch(e){}}sndUI();try{musicWatch()}catch(e){}if(SND_ON)sClick(.3,900)}
function sndRow(){const r=mkRow('SOUND'),g=document.createElement('div');g.className='seg';[['ON',1],['MUTE',0]].forEach(o=>{const b=document.createElement('button');b.className='sm';b.textContent=o[0];b.dataset.snd=o[1];b.onclick=()=>{if((o[1]===1)!==SND_ON)sndToggle()};g.appendChild(b)});r.appendChild(g);return r}
document.addEventListener('click',e=>{const t=e.target;if(t&&t.closest&&t.closest('button,.mc')&&!t.closest('.tb'))sUI()},true);
function say(w,t){if(!SND_ON)return;try{const u=new SpeechSynthesisUtterance(t);u.lang='en-IN';u.volume=CFG.vol;u.rate=.95;u.pitch=w.includes('RAWAT')?.6:1.1;speechSynthesis.speak(u)}catch(e){}}
