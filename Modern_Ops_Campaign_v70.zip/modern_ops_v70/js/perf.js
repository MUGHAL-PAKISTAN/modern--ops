'use strict';
/* v70 FPS auto-scaler. Measures frames the game really rendered (PQ.fr) while a mission is running.
   < 30 FPS for 3 s  -> pixelRatio 1, shadows OFF, particles -50%, fewer full-detail soldiers.
   > 55 FPS for 3 s  -> everything restored. (Limits are relative if the game is capped below 60 FPS, e.g. auto 30 FPS cap on weak phones.)
   Flip-flop guard: restore needs 20 s of good FPS (60 s if it had to drop again within 30 s of a restore). */
(()=>{
const base=MDMAX;let fr0=PQ.fr,t0=performance.now(),lowMs=0,hiMs=0,lowAt=0,restAt=-1e9,sticky=0,runAt=0,wasRun=false;
PQ.low=0;
function setLow(on){if(on===!!PQ.low)return;PQ.low=on?1:0;
if(on){PQ.pr=1;PQ.noSh=1;PQ.fx=.5;MDMAX=Math.min(base,6);PQ.tag=' · AUTO-LOW';try{sun.castShadow=false}catch(e){}}
else{PQ.pr=99;PQ.noSh=0;PQ.fx=1;MDMAX=base;PQ.tag='';try{applyS()}catch(e){}}
try{setDyn(dynK)}catch(e){}
try{pop(on?'AUTO QUALITY: LOW':'AUTO QUALITY: RESTORED')}catch(e){}}
setInterval(()=>{const n=performance.now(),dt=(n-t0)/1000;t0=n;const fps=dt>0?(PQ.fr-fr0)/dt:60;fr0=PQ.fr;
const go=run&&!paused&&!cin&&!document.hidden;if(go&&!wasRun)runAt=n;wasRun=go;
if(!CFG.aq){if(PQ.low)setLow(0);lowMs=hiMs=0;return}
if(!go||n-runAt<4000){lowMs=hiMs=0;return}          // ignore load hitches
const cap=hz/skN,lo=Math.min(30,cap*.9),hi=Math.min(55,cap*.92);
if(!PQ.low){hiMs=0;if(fps<lo){lowMs+=dt*1e3;if(lowMs>=3000){lowMs=0;if(n-restAt<30000)sticky=1;lowAt=n;setLow(1)}}else lowMs=0}
else{lowMs=0;if(fps>hi){hiMs+=dt*1e3;if(hiMs>=3000&&n-lowAt>(sticky?60000:20000)){hiMs=0;restAt=n;sticky=0;setLow(0)}}else hiMs=0}},500);
})();
