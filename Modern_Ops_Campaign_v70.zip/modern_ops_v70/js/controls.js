'use strict';
/* v70 mobile controls (rebuilt). Multi-touch via touch identifiers:
   left half  = floating joystick (appears under the thumb), right half = look, buttons = their own touch id,
   so Move + Look + Fire work at the same time. Secondary buttons (grenade, medkit, zoom...) keep the v69 btn() handlers. */
const CTL=(()=>{
const R_=60,ACC=.15,DEC=.1,HOLD=new Set(['fire','ads','jump','rel','crb','swb']);
const J={id:null,ox:0,oy:0,tx:0,ty:0,sx:0,sy:0,used:0},L={id:null,x:0,y:0},BT=new Map();
let stickEl=null,knobEl=null,lastEnd=0;
const live=()=>run&&!paused&&!cin;
const dz=()=>clamp(CFG.jdz==null?10:CFG.jdz,0,R_-8);

function setStick(on){if(!stickEl){stickEl=$('stick');knobEl=$('knob');if(!stickEl)return}stickEl.classList.toggle('on',on);stickEl.classList.toggle('idle',!on);
if(!on){stickEl.style.left=stickEl.style.top=stickEl.style.bottom='';knobEl.style.transform=''}}
function look(dx,dy){const f=zf(),ac=1+Math.min(.3,Math.hypot(dx,dy)/60),k=.0058*clamp(CFG.sens,.5,2)*f*ac;addLook(-dx*k,-dy*k);lookDX+=dx;lookDY+=dy}

function press(id,t,el){el.classList.add('pr');
switch(id){
case'fire':firing=true;L.fx=tcx(t);L.fy=tcy(t);break;
case'ads':adsOn=CFG.adsHold?true:!adsOn;break;
case'jump':jump();break;
case'rel':doReload();break;
case'crb':if(!UA.on){CR.on=CR.on?0:1;el.textContent=CR.on?'STAND':'CROUCH'}break;
case'swb':for(let n=1;n<=3;n++){const i=(cs+n)%3;if(SL[i]){switchTo(i);break}}break}}
function release(id,el){el.classList.remove('pr');
if(id==='fire')firing=false;else if(id==='ads'){if(CFG.adsHold)adsOn=false}}

function onStart(e){if(!live())return;
for(const t of e.changedTouches){const el=t.target,b=el.closest&&el.closest('.tb');
if(b){if(HOLD.has(b.id)){e.preventDefault();e.stopPropagation();BT.set(t.identifier,{id:b.id,el:b,x:tcx(t),y:tcy(t)});press(b.id,t,b)}continue}
if(el.closest&&el.closest('button,input,select,textarea,#pk'))continue;
e.preventDefault();const x=tcx(t),y=tcy(t);
if(x<VW()*.5){if(J.id!==null)continue;J.id=t.identifier;J.used=1;
J.ox=clamp(x,R_+16,VW()*.5-R_*.4);J.oy=clamp(y,R_+16,VH()-R_-10);J.tx=J.ty=0;
if(stickEl||(stickEl=$('stick'))){knobEl=$('knob');stickEl.style.bottom='auto';stickEl.style.left=(J.ox-R_)+'px';stickEl.style.top=(J.oy-R_)+'px';stickEl.classList.add('on');stickEl.classList.remove('idle');knobEl.style.transform=''}}
else if(L.id===null){L.id=t.identifier;L.x=x;L.y=y}}}

function onMove(e){if(!live()){return}
let own=false;
for(const t of e.changedTouches){const id=t.identifier,x=tcx(t),y=tcy(t);
if(id===J.id){own=true;let dx=x-J.ox,dy=y-J.oy;const d=Math.hypot(dx,dy);
if(d>R_){const k=(d-R_)/d;J.ox+=dx*k;J.oy+=dy*k;dx=x-J.ox;dy=y-J.oy;stickEl.style.left=(J.ox-R_)+'px';stickEl.style.top=(J.oy-R_)+'px'}
const dd=Math.hypot(dx,dy),z=dz(),m=dd<z?0:Math.min(1,(dd-z)/(R_-z));
J.tx=dd>0?dx/dd*m:0;J.ty=dd>0?dy/dd*m:0;knobEl.style.transform='translate('+dx+'px,'+dy+'px)'}
else if(id===L.id){own=true;look(x-L.x,y-L.y);L.x=x;L.y=y}
else{const b=BT.get(id);if(b){own=true;if(b.id==='fire'){look(x-b.x,y-b.y)}b.x=x;b.y=y}}}
if(own)e.preventDefault()}

function onEnd(e){for(const t of e.changedTouches){const id=t.identifier;
if(id===J.id){J.id=null;J.tx=J.ty=0;setStick(false)}
else if(id===L.id)L.id=null;
else{const b=BT.get(id);if(b){BT.delete(id);release(b.id,b.el)}}}
if(live()&&e.cancelable&&!(e.target.closest&&e.target.closest('input,textarea,select'))){const n=performance.now();if(n-lastEnd<320&&e.type==='touchend')e.preventDefault();lastEnd=n}}

// called every frame from updPlayer: smooth acceleration (0 -> max in .15 s, stop in .1 s)
function tick(dt){if(!J.used)return;
const ex=J.tx-J.sx,ey=J.ty-J.sy,len=Math.hypot(ex,ey);
if(len>0){const accel=Math.hypot(J.tx,J.ty)>=Math.hypot(J.sx,J.sy)-1e-4,step=dt/(accel?ACC:DEC);if(len<=step){J.sx=J.tx;J.sy=J.ty}else{J.sx+=ex/len*step;J.sy+=ey/len*step}}
mv.x=J.sx;mv.y=J.sy;
if(J.id===null&&!J.sx&&!J.sy)J.used=0}

function reset(){J.id=null;L.id=null;J.tx=J.ty=J.sx=J.sy=0;J.used=0;mv.x=mv.y=0;
for(const b of BT.values())b.el.classList.remove('pr');BT.clear();firing=false;
const c=$('crb');if(c){c.textContent='CROUCH'}setStick(false)}

// ---- settings migration (once): hold-to-aim default, sensitivity range 0.5x-2.0x, FPS counter on for testing
try{if(!localStorage.getItem('mo_v70c')){CFG.adsHold=1;CFG.fps=1;localStorage.setItem('mo_v70c','1')}}catch(e){}
CFG.sens=clamp(CFG.sens==null?1:CFG.sens,.5,2);if(CFG.jdz==null)CFG.jdz=10;saveS();

// ---- listeners (touch-action:none in CSS + preventDefault here: no scroll, no pinch, no double-tap zoom, no touch delay)
const O={passive:false};
addEventListener('touchstart',onStart,O);addEventListener('touchmove',onMove,O);addEventListener('touchend',onEnd,O);addEventListener('touchcancel',onEnd,O);
addEventListener('touchmove',e=>{if(e.cancelable&&live())return;let n=e.target;while(n&&n!==document.body){if(n.scrollHeight>n.clientHeight+1&&/(auto|scroll)/.test(getComputedStyle(n).overflowY))return;n=n.parentNode}if(e.cancelable)e.preventDefault()},O);
for(const g of['gesturestart','gesturechange','gestureend'])document.addEventListener(g,e=>e.preventDefault());
addEventListener('contextmenu',e=>{if(TOUCHD)e.preventDefault()});
{const s=$('swb');if(s)s.addEventListener('click',()=>{if(live())for(let n=1;n<=3;n++){const i=(cs+n)%3;if(SL[i]){switchTo(i);break}}})}
setStick(false);
return{tick,reset,J}})();
