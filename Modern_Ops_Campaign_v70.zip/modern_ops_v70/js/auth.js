'use strict';
(function(){
'use strict';
var AK='mo_acc',SK='mo_sess',GK='mo_guest',LS=window.localStorage;
function rd(k){try{return LS.getItem(k)}catch(e){return null}}
function wr(k,v){try{LS.setItem(k,v)}catch(e){}}
var sess=rd(SK),guest=rd(GK)==='1'&&!sess,user=sess&&sess.length?sess:null;
window.MO_USER=user;
if(user){
 var P='mo_u_'+user+'_',SP=Storage.prototype,g=SP.getItem,s=SP.setItem,r=SP.removeItem;
 var own=function(k){return typeof k==='string'&&k.indexOf('mo_')===0&&k!==AK&&k!==SK&&k!==GK&&k!=='mo_lite'&&k.indexOf('mo_u_')!==0};
 SP.getItem=function(k){return g.call(this,this===LS&&own(k)?P+k:k)};
 SP.setItem=function(k,v){return s.call(this,this===LS&&own(k)?P+k:k,v)};
 SP.removeItem=function(k){return r.call(this,this===LS&&own(k)?P+k:k)};
}
function accs(){try{return JSON.parse(rd(AK)||'{}')||{}}catch(e){return{}}}
var OWNER_ID='MO-5YSMVF';
window.MO_IS_OWNER=function(){try{var a=user?accs()[user]:null;return!!(a&&a.id===OWNER_ID)}catch(e){return false}};
window.MO_BADGE=function(lg){if(!window.MO_IS_OWNER())return'';return'<span class="ob'+(lg?' lg':'')+'"><svg class="obc" viewBox="0 0 12 10"><path d="M1 9L.5 3 4 6 6 1 8 6 11.5 3 11 9Z"/><circle cx="6" cy="1.1" r=".75"/><circle cx="1" cy="2.7" r=".55"/><circle cx="11" cy="2.7" r=".55"/></svg>OWNER<i class="obs s1"></i><i class="obs s2"></i><i class="obs s3"></i></span>'};
function hex(b){return Array.prototype.map.call(new Uint8Array(b),function(x){return('0'+x.toString(16)).slice(-2)}).join('')}
function fb(str){var h1=0xdeadbeef,h2=0x41c6ce57;for(var i=0;i<str.length;i++){var c=str.charCodeAt(i);h1=Math.imul(h1^c,2654435761);h2=Math.imul(h2^c,1597334677)}h1=Math.imul(h1^h1>>>16,2246822507)^Math.imul(h2^h2>>>13,3266489909);h2=Math.imul(h2^h2>>>16,2246822507)^Math.imul(h1^h1>>>13,3266489909);return(h2>>>0).toString(16)+(h1>>>0).toString(16)}
function hash(salt,pw){var t=salt+':'+pw;
 try{if(window.crypto&&crypto.subtle)return crypto.subtle.digest('SHA-256',new TextEncoder().encode(t)).then(hex)}catch(e){}
 return Promise.resolve('f'+fb(t)+fb(t+salt))}
function rnd(){var a=new Uint8Array(8);try{crypto.getRandomValues(a)}catch(e){for(var i=0;i<8;i++)a[i]=Math.random()*256}return hex(a)}
function sig(id,t,a,n){var q=id+'|'+t+'|'+a+'|'+n+'|ShinesStar-MO-2026',h=0x811c9dc5;for(var i=0;i<q.length;i++){h^=q.charCodeAt(i);h=Math.imul(h,16777619)}return((h>>>0)%2176782336).toString(36).toUpperCase().padStart(6,'0')}
function mkId(){var al='23456789ABCDEFGHJKMNPQRSTUVWXYZ',a=new Uint8Array(6),o='';try{crypto.getRandomValues(a)}catch(e){for(var i=0;i<6;i++)a[i]=Math.random()*256}for(var j=0;j<6;j++)o+=al[a[j]%al.length];return'MO-'+o}
function setupGift(key,$){
 var A=accs(),a=A[key];if(!a)return;if(!a.id){a.id=mkId();wr(AK,JSON.stringify(A))}
 var u=$('usr');if(u){var d=document.createElement('div');d.innerHTML='PLAYER ID: <b id="pid">'+a.id+'</b>'+window.MO_BADGE();u.appendChild(d);
  $('pid').onclick=function(){try{navigator.clipboard.writeText(a.id);this.textContent='COPIED!';var t=this;setTimeout(function(){t.textContent=a.id},1200)}catch(e){}}}
 var g=document.createElement('div');g.id='gft';g.className='pnl';
 g.innerHTML='<div class="bx"><h2>GIFT CODE</h2><p>Enter a gift code made for your Player ID.<br>Your ID: <b>'+a.id+'</b></p><input id="gfC" type="text" maxlength="32" placeholder="X5000-01-ABC123" autocomplete="off" spellcheck="false"><div class="er" id="gfE"></div><button id="gfOk">REDEEM</button><button id="gfX" style="border-color:#555;color:#aaa;background:transparent">CLOSE</button></div>';
 document.body.appendChild(g);
 var C=$('gfC'),E=$('gfE');['keydown','keyup','keypress'].forEach(function(ev){C.addEventListener(ev,function(e){e.stopPropagation();if(ev==='keydown'&&e.key==='Enter')$('gfOk').click()})});
 $('gfX').onclick=function(){g.style.display='none'};
 var mb=$('mbox'),sb=$('setb');if(mb&&sb){var b=document.createElement('button');b.id='giftb';b.textContent='Gifts';b.onclick=function(){E.textContent='';C.value='';g.style.display='flex'};mb.insertBefore(b,sb)}
 $('gfOk').onclick=function(){
  var code=C.value.trim().toUpperCase(),m=/^([XM])(\d{1,7})-(\d{1,3})-([0-9A-Z]{6})$/.exec(code);E.style.color='#ff6a5a';
  if(!m){E.textContent='Invalid code format';return}
  if(sig(a.id,m[1],m[2],m[3])!==m[4]){E.textContent='This code is not valid for your ID';return}
  var used=[];try{used=JSON.parse(LS.getItem('mo_gifts')||'[]')}catch(e){}
  if(used.indexOf(code)>=0){E.textContent='Code already used';return}
  used.push(code);LS.setItem('mo_gifts',JSON.stringify(used));
  var n=+m[2];
  if(m[1]==='X'){LS.setItem('mo_xp',String((+LS.getItem('mo_xp')||0)+n));E.style.color='#7fff9a';E.textContent='+'+n+' XP added!'}
  else{LS.setItem('mo_p',String(Math.max(+LS.getItem('mo_p')||0,n-1)));E.style.color='#7fff9a';E.textContent='Missions unlocked up to #'+n+'!'}
  setTimeout(function(){location.reload()},1300)};
}
function setupInfo(key,$){
 var A=accs(),a=key?A[key]:null,g=document.createElement('div');g.id='ainf';g.className='pnl';
 var esc=function(t){return String(t).replace(/[<>&"]/g,'')};
 function num(k){return+(LS.getItem(k)||0)}
 function build(){
  var gifts=0;try{gifts=JSON.parse(LS.getItem('mo_gifts')||'[]').length}catch(e){}
  var h='<div class="bx"><h2>ACCOUNT INFO</h2>';
  if(!a){h+='<div class="r"><span>Account</span><b>GUEST</b></div><div class="r"><span>Username</span><b>-</b></div><div class="r"><span>Password</span><b>-</b></div><div class="r"><span>Game ID</span><b>-</b></div><p style="font-size:12px;opacity:.8">Guest progress is saved on this device only. Logout and REGISTER to get a username, password and Game ID.</p>'}
  else{h+='<div class="r"><span>Username</span><b>'+esc(a.n)+'</b></div>'+(window.MO_IS_OWNER()?'<div class="r"><span>Badge</span><b>'+window.MO_BADGE(1)+'</b></div>':'')+'<div class="r"><span>Password</span><b>&bull;&bull;&bull;&bull;&bull;&bull;</b></div><div class="r"><span>Game ID</span><b id="aiId" style="cursor:pointer">'+esc(a.id||'-')+'</b></div>'
   +(a.c?'<div class="r"><span>Created</span><b>'+new Date(a.c).toLocaleDateString()+'</b></div>':'')
   +'<div class="r"><span>Total XP</span><b>'+num('mo_xp')+'</b></div><div class="r"><span>Best score</span><b>'+num('mo_best')+'</b></div><div class="r"><span>Mission reached</span><b>'+(num('mo_p')+1)+'</b></div><div class="r"><span>Gift codes used</span><b>'+gifts+'</b></div>'
   +'<p style="font-size:11px;opacity:.7;margin:6px 0 0">For safety your password is stored scrambled, so it cannot be shown. You can change it below.</p>'
   +'<div class="sec">CHANGE PASSWORD</div><input id="aiO" type="password" placeholder="CURRENT PASSWORD" autocomplete="current-password"><input id="aiN" type="password" placeholder="NEW PASSWORD" autocomplete="new-password"><button class="sh" id="aiSh" type="button">&#128065; Show password</button><div class="er" id="aiE"></div><button id="aiC">CHANGE PASSWORD</button>'}
  h+='<button id="aiX" style="border-color:#555;color:#aaa;background:transparent">CLOSE</button></div>';
  g.innerHTML=h;
  ['aiO','aiN'].forEach(function(i){var el=$(i);if(el)['keydown','keyup','keypress'].forEach(function(ev){el.addEventListener(ev,function(e){e.stopPropagation()})})});
  g.insertAdjacentHTML('beforeend','<div class="nv"><button id="aiU">&#9650;</button><button id="aiD">&#9660;</button></div>');
  var bx=g.querySelector('.bx'),sc=function(d){bx.scrollBy({top:d*Math.max(80,bx.clientHeight*.6),behavior:'smooth'})};
  $('aiU').onclick=function(){sc(-1)};$('aiD').onclick=function(){sc(1)};
  var sh=$('aiSh');if(sh){var on=0;sh.onclick=function(){on=!on;$('aiO').type=$('aiN').type=on?'text':'password';sh.innerHTML=(on?'&#128584; Hide':'&#128065; Show')+' password'}}
  $('aiX').onclick=function(){g.style.display='none'};
  var id=$('aiId');if(id)id.onclick=function(){try{navigator.clipboard.writeText(a.id);id.textContent='COPIED!';setTimeout(function(){id.textContent=a.id},1200)}catch(e){}};
  var c=$('aiC');if(c)c.onclick=function(){var E=$('aiE'),o=$('aiO').value,n=$('aiN').value;E.style.color='#ff6a5a';E.textContent='';
   if(n.length<4){E.textContent='New password: at least 4 characters';return}
   hash(a.s,o).then(function(h0){if(h0!==a.h){E.textContent='Current password is wrong';return}
    var ns=rnd();hash(ns,n).then(function(h1){var B=accs();if(!B[key])return;B[key].s=ns;B[key].h=h1;wr(AK,JSON.stringify(B));a=B[key];E.style.color='#7fff9a';E.textContent='Password changed!';$('aiO').value='';$('aiN').value=''})})}}
 document.body.appendChild(g);
 window.addEventListener('keydown',function(e){if(g.style.display!=='flex'||/^(INPUT|TEXTAREA)$/.test((e.target||{}).tagName))return;var d={ArrowDown:1,ArrowUp:-1,PageDown:2,PageUp:-2}[e.code];if(!d)return;e.preventDefault();e.stopImmediatePropagation();var b=g.querySelector('.bx');b.scrollBy({top:d*Math.max(80,b.clientHeight*.6)/(Math.abs(d)===2?1:2),behavior:'smooth'})},true);
 var pf=document.querySelector('#set .pf'),sd=$('sdef');
 if(pf&&sd){var b=document.createElement('button');b.className='sm';b.id='acib';b.textContent='ACCOUNT INFO';b.onclick=function(){a=key?accs()[key]:null;build();g.style.display='flex'};pf.insertBefore(b,sd)}
}
function init(){
 var $=function(i){return document.getElementById(i)},ov=$('lgn'),mode=1;
 if(user||guest){
  var mt=$('mt');if(mt){var u=document.createElement('div');u.id='usr';u.innerHTML=(user?'OPERATOR: '+user.replace(/[<>&"]/g,''):'GUEST')+' <a id="lgOut">'+(user?'LOGOUT':'LOGIN')+'</a>';mt.parentNode.insertBefore(u,mt)}
  var lo=$('lgOut');if(lo)lo.onclick=function(){try{LS.removeItem(SK);LS.removeItem(GK)}catch(e){}location.reload()};
  if(user)setupGift(user,$);setupInfo(user,$);
  return}
 ov.style.display='flex';
 var E=$('lgE'),U=$('lgU'),Pw=$('lgP'),P2=$('lgP2');
 ['lgU','lgP','lgP2'].forEach(function(i){var el=$(i);['keydown','keyup','keypress'].forEach(function(ev){el.addEventListener(ev,function(e){e.stopPropagation();if(ev==='keydown'&&e.key==='Enter')$('lgGo').click()})})});
 function setMode(m){mode=m;$('lgT1').className=m===1?'on':'';$('lgT2').className=m===2?'on':'';P2.style.display=m===2?'block':'none';$('lgGo').textContent=m===1?'LOGIN':'CREATE ACCOUNT';Pw.autocomplete=m===1?'current-password':'new-password';E.textContent=''}
 var shown=0;$('lgSh').onclick=function(){shown=!shown;Pw.type=P2.type=shown?'text':'password';this.innerHTML=(shown?'&#128584; Hide':'&#128065; Show')+' password'};
 $('lgT1').onclick=function(){setMode(1)};$('lgT2').onclick=function(){setMode(2)};
 function enter(name){wr(SK,name);try{LS.removeItem(GK)}catch(e){}location.reload()}
 $('lgG').onclick=function(){try{LS.removeItem(SK)}catch(e){}wr(GK,'1');location.reload()};
 $('lgGo').onclick=function(){
  var n=U.value.trim(),p=Pw.value,A=accs(),key=n.toLowerCase();E.textContent='';
  if(!/^[A-Za-z0-9_]{3,16}$/.test(n)){E.textContent='Username: 3-16 letters, numbers or _';return}
  if(p.length<4){E.textContent='Password must be at least 4 characters';return}
  if(mode===2){
   if(A[key]){E.textContent='This username is already taken';return}
   if(p!==P2.value){E.textContent='Passwords do not match';return}
   var salt=rnd();hash(salt,p).then(function(h){A[key]={n:n,s:salt,h:h,c:Date.now()};wr(AK,JSON.stringify(A));enter(key)})
  }else{
   var a=A[key];if(!a){E.textContent='Account not found. Tap REGISTER first.';return}
   hash(a.s,p).then(function(h){if(h!==a.h){E.textContent='Wrong password';Pw.value='';return}enter(key)})
  }};
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();
