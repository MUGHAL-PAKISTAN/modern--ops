'use strict';
/* v70 loader: error box, device class, and LAZY asset loading.
   Menu needs no 3D models. Soldier models (+ their textures) are fetched the first time the player
   leaves the main menu (PLAY / CONTINUE / MISSIONS / CO-OP / PVP) and are decoded here. */
window.moBox=function(t,b){if(document.getElementById('mo-err'))return;var d=document.createElement('div');d.id='mo-err';d.style.cssText='position:fixed;inset:0;z-index:99;display:flex;flex-direction:column;align-items:center;justify-content:center;background:#0b0d0a;color:#e8e6d9;font:15px Arial,sans-serif;text-align:center;padding:20px';d.innerHTML='<h2 style="color:#c8a64a;letter-spacing:.12em;margin:0 0 8px;font-family:Impact,Arial">'+t+'</h2><p style="max-width:420px;margin:0 0 16px">'+b+'</p><button style="padding:10px 30px;font-size:18px;border:2px solid #c8a64a;background:#14160f;color:#e8e6d9" onclick="location.reload()">RELOAD</button>';document.body.appendChild(d)};

(function(){
var W=window;
// device class: textures are capped at 512px on phones/tablets and 1024px on PC
W.MO_MOBILE=/Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent)||(navigator.maxTouchPoints>1&&/Mac/.test(navigator.platform));
W.TEXMAX=/[?&]tex=(\d+)/.test(location.search)?Math.min(1024,+RegExp.$1||512):(W.MO_MOBILE?512:1024);

function loadScript(src){return new Promise(function(res,rej){var s=document.createElement('script');s.src=src;s.async=true;s.onload=function(){res()};s.onerror=function(){rej(new Error('load '+src))};document.head.appendChild(s)})}

// ---- tiny zlib inflate (only used on browsers without DecompressionStream, i.e. iOS < 16.4)
function inflateJS(src,outLen){
 var out=new Uint8Array(outLen),op=0,ip=2,bb=0,bc=0;
 function bits(n){while(bc<n){bb|=src[ip++]<<bc;bc+=8}var v=bb&((1<<n)-1);bb>>>=n;bc-=n;return v}
 function build(lens,n){var c=new Uint16Array(16),s=new Uint16Array(n),o=new Uint16Array(16),i;for(i=0;i<n;i++)c[lens[i]]++;c[0]=0;for(i=1;i<15;i++)o[i+1]=o[i]+c[i];for(i=0;i<n;i++)if(lens[i])s[o[lens[i]]++]=i;return{c:c,s:s}}
 function dec(h){var code=0,first=0,index=0;for(var len=1;len<16;len++){code|=bits(1);var cnt=h.c[len];if(code-cnt<first)return h.s[index+(code-first)];index+=cnt;first+=cnt;first<<=1;code<<=1}throw new Error('inflate')}
 var LB=[3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258],
 LE=[0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0],
 DB=[1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577],
 DE=[0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13],
 OR=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15],fixL=null,fixD=null,last,i;
 do{last=bits(1);var type=bits(2);
  if(type===0){bb=0;bc=0;var len=src[ip]|(src[ip+1]<<8);ip+=4;while(len--)out[op++]=src[ip++]}
  else{var lc,dc;
   if(type===1){if(!fixL){var l=new Uint8Array(288);for(i=0;i<144;i++)l[i]=8;for(;i<256;i++)l[i]=9;for(;i<280;i++)l[i]=7;for(;i<288;i++)l[i]=8;fixL=build(l,288);var d=new Uint8Array(30);for(i=0;i<30;i++)d[i]=5;fixD=build(d,30)}lc=fixL;dc=fixD}
   else{var nl=bits(5)+257,nd=bits(5)+1,nc=bits(4)+4,lens=new Uint8Array(320);for(i=0;i<nc;i++)lens[OR[i]]=bits(3);var cc=build(lens,19);lens=new Uint8Array(320);i=0;
    while(i<nl+nd){var sym=dec(cc);if(sym<16)lens[i++]=sym;else{var prev=0,rep;if(sym===16){prev=lens[i-1];rep=3+bits(2)}else if(sym===17)rep=3+bits(3);else rep=11+bits(7);while(rep--)lens[i++]=prev}}
    lc=build(lens.subarray(0,nl),nl);dc=build(lens.subarray(nl,nl+nd),nd)}
   for(;;){var s=dec(lc);if(s<256)out[op++]=s;else if(s===256)break;else{s-=257;var ln=LB[s]+bits(LE[s]),ds=dec(dc),dist=DB[ds]+bits(DE[ds]);while(ln--){out[op]=out[op-dist];op++}}}}
 }while(!last);
 return out}
function inflate(u8,outLen){
 if(typeof DecompressionStream==='function'&&typeof Response==='function'){
  try{return new Response(new Blob([u8]).stream().pipeThrough(new DecompressionStream('deflate'))).arrayBuffer().then(function(b){return new Uint8Array(b)})}catch(e){}}
 return new Promise(function(r){setTimeout(function(){r(inflateJS(u8,outLen))},0)})}

function unshuf(b,w){var n=b.length/w,o=new Uint8Array(b.length),p,i;for(p=0;p<w;p++)for(i=0;i<n;i++)o[i*w+p]=b[p*n+i];return o}
function b64(s){var b=atob(s),n=b.length,u=new Uint8Array(n);for(var i=0;i<n;i++)u[i]=b.charCodeAt(i);return u}

// rebuilds the exact MD_DATA structure the game used in v69, but as typed arrays (no base64 at runtime)
function decodePack(P,raw){
 var out={};
 for(var key in P.h){
  var h=P.h[key],s=h.s,n=h.n;
  var seg=function(a){return raw.subarray(a[0],a[0]+a[1])},d={name:h.name,n:n,t:h.t,muzzle:h.muzzle,bones:h.bones,idx32:!!h.idx32};
  var pz=seg(s.pos),pos=new Float32Array(n*3),a,i;
  for(a=0;a<3;a++){var mn=h.q[0][a],rg=(h.q[1][a]-mn)||1,base=a*2*n;for(i=0;i<n;i++)pos[i*3+a]=mn+(pz[base+i]|(pz[base+n+i]<<8))/65535*rg}
  d.pos=pos;
  d.nrm=new Int8Array(unshuf(seg(s.nrm),3).buffer);
  d.col=seg(s.col).slice();
  if(s.tuv){d.tuv=new Uint16Array(unshuf(seg(s.tuv),4).buffer);d.tid=seg(s.tid).slice()}
  d.si=seg(s.si).slice();d.sw=seg(s.sw).slice();
  var w=h.iw,ib=unshuf(seg(s.idx),w),ix=w===4?new Uint32Array(ib.buffer):new Uint16Array(ib.buffer);
  for(i=1;i<ix.length;i++)ix[i]=(ix[i-1]+ix[i])>>>0;      // delta -> absolute (typed array wraps to 16 bit)
  d.idx=ix;out[key]=d}
 return out}
W.MO_DECODE=decodePack;W.MO_INFLATE=inflate;W.MO_B64=b64;     // exposed for tools/tests

var A={done:false,p:null,fail:0};
A.load=function(){
 if(A.done)return Promise.resolve(true);
 if(A.p)return A.p;
 if(A.fail>=2)return Promise.resolve(false);
 var t0=Date.now();
 A.p=Promise.all([loadScript('assets/models.js'),loadScript(W.TEXMAX>=1024?'assets/tex1024.js':'assets/tex512.js')]).then(function(){
  var P=W.MD_PACK,total=0,k;for(k in P.h){var sg=P.h[k].s;for(var f in sg)total=Math.max(total,sg[f][0]+sg[f][1])}
  return inflate(b64(P.z),total).then(function(raw){W.MD_DATA=decodePack(P,raw);W.MD_TEX=W.MD_TEXZ;W.MD_PACK=null;A.done=true;if(typeof W.mdAssetsReady==='function')W.mdAssetsReady();return true})
 }).catch(function(){A.fail++;A.p=null;return false});
 return A.p};
W.MO_ASSETS=A;
})();
