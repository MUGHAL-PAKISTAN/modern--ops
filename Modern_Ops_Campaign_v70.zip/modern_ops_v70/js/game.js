'use strict';
const DOMC={},PO=()=>innerHeight>innerWidth,VW=()=>PO()?innerHeight:innerWidth,VH=()=>PO()?innerWidth:innerHeight,tcx=t=>PO()?t.clientY:t.clientX,tcy=t=>PO()?innerWidth-t.clientX:t.clientY,$=id=>{const e=DOMC[id];return e&&e.isConnected?e:(DOMC[id]=document.getElementById(id))},R=Math.random,PI=Math.PI;
const clamp=(v,a,b)=>v<a?a:v>b?b:v,lerp=(a,b,t)=>a+(b-a)*t,ss=(a,b,x)=>{const t=clamp((x-a)/(b-a),0,1);return t*t*(3-2*t)};
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
let ULTX=false,ENVT=null,ENVR=null,SKYT=null;
const PQ={pr:99,noSh:0,fx:1,n:0,fr:0,tag:''},CR={on:0,k:0};
const LITE=(()=>{try{const v=localStorage.getItem('mo_lite');return v===null?!!(navigator.deviceMemory&&navigator.deviceMemory<=2):v==='1'}catch(e){return false}})();
function rng(s){return function(){s|=0;s=s+0x6D2B79F5|0;let t=Math.imul(s^s>>>15,1|s);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296}}
const G=(()=>{const r=rng(7),g=new Float32Array(4096);for(let i=0;i<4096;i++)g[i]=r();return g})();
function vn(x,y,m){const xi=Math.floor(x),yi=Math.floor(y),xf=x-xi,yf=y-yi,u=xf*xf*(3-2*xf),v=yf*yf*(3-2*yf),x0=xi%m,y0=yi%m,x1=(xi+1)%m,y1=(yi+1)%m,a=G[y0*64+x0],b=G[y0*64+x1],c=G[y1*64+x0],d=G[y1*64+x1];return a+(b-a)*u+(c-a)*v+(a-b-c+d)*u*v}
function fbm(u,v,base,oct){let s=0,a=.5,t=0;for(let o=0;o<oct;o++){const m=base<<o;s+=a*vn(u*m,v*m,m);t+=a;a*=.5}return s/t}
const mix=(a,b,t)=>[a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t,a[2]+(b[2]-a[2])*t];
function mkT(s,fn,after){{const mx=Math.min(TEXMAX,LITE?512:4096);if(s>mx)s=mx}const bs=LITE?1:s,c=document.createElement('canvas'),b=document.createElement('canvas');c.width=c.height=s;b.width=b.height=bs;const g=c.getContext('2d'),gb=b.getContext('2d'),im=g.createImageData(s,s),ib=gb.createImageData(bs,bs);
for(let y=0;y<s;y++)for(let x=0;x<s;x++){const o=(y*s+x)*4,r=fn(x/s,y/s,x,y);im.data[o]=r[0];im.data[o+1]=r[1];im.data[o+2]=r[2];im.data[o+3]=255;const h=r[3]*255;ib.data[o]=ib.data[o+1]=ib.data[o+2]=h;ib.data[o+3]=255}
g.putImageData(im,0,0);gb.putImageData(ib,0,0);if(after)after(g,gb,s);
if(LITE){const id=g.getImageData(0,0,s,s),d=id.data,L=new Float32Array(s*s);for(let i=0;i<s*s;i++)L[i]=d[i*4]*.3+d[i*4+1]*.59+d[i*4+2]*.11;
for(let y=0;y<s;y++)for(let x=0;x<s;x++){const p=L[((y+s-1)%s)*s+(x+s-1)%s],q=L[((y+1)%s)*s+(x+1)%s],k=1+Math.max(-.38,Math.min(.38,(p-q)/95)),o=(y*s+x)*4;d[o]*=k;d[o+1]*=k;d[o+2]*=k}g.putImageData(id,0,0)}
const m=new THREE.CanvasTexture(c),bm=new THREE.CanvasTexture(b);[m,bm].forEach(t=>{t.wrapS=t.wrapT=THREE.RepeatWrapping;t.anisotropy=LITE?4:(ULTX?Math.min(16,rd.capabilities.getMaxAnisotropy()):4)});m.encoding=THREE.sRGBEncoding;return{m:m,b:bm}}
function rr(g,x,y,w,h,r){g.beginPath();g.moveTo(x+r,y);g.arcTo(x+w,y,x+w,y+h,r);g.arcTo(x+w,y+h,x,y+h,r);g.arcTo(x,y+h,x,y,r);g.arcTo(x,y,x+w,y,r);g.closePath()}
const TF={};
TF.gravel=()=>mkT(512,(u,v)=>{const n=fbm(u,v,4,5),f=fbm(u+.3,v+.7,16,3),k=.78+.4*f+.12*R(),c=mix([70,60,46],[128,112,86],n);return[c[0]*k,c[1]*k,c[2]*k,.35*n+.4*f+.25*R()]},(g,gb,s)=>{for(let i=0;i<500;i++){const x=R()*s,y=R()*s,r=1+R()*3;g.fillStyle='rgba('+(R()<.5?40:150)+','+(R()<.5?35:135)+',100,.35)';g.beginPath();g.arc(x,y,r,0,7);g.fill();gb.fillStyle='rgba(255,255,255,.4)';gb.beginPath();gb.arc(x,y,r,0,7);gb.fill()}});
TF.sand=()=>mkT(512,(u,v)=>{const n=fbm(u,v,4,5),r=Math.sin((v*40+n*6)*PI*2)*.5+.5,c=mix([176,146,98],[222,194,140],n*.7+r*.3),g=.92+R()*.14;return[c[0]*g,c[1]*g,c[2]*g,.5*n+.4*r+.1*R()]});
TF.asph=()=>mkT(512,(u,v)=>{const n=fbm(u,v,8,4),k=.55+.4*n+.25*R();return[58*k,60*k,64*k,.3*n+.7*R()]},(g,gb,s)=>{for(let i=0;i<8;i++){let x=R()*s,y=R()*s;g.strokeStyle='rgba(10,10,10,.6)';gb.strokeStyle='#000';g.lineWidth=gb.lineWidth=1+R()*1.5;g.beginPath();gb.beginPath();g.moveTo(x,y);gb.moveTo(x,y);for(let j=0;j<14;j++){x+=(R()-.5)*40;y+=(R()-.3)*30;g.lineTo(x,y);gb.lineTo(x,y)}g.stroke();gb.stroke()}});
TF.conc=()=>mkT(512,(u,v)=>{const n=fbm(u,v,4,5),st=fbm(u+.5,v,8,3),k=.62+.3*n-.2*Math.max(0,st-.55)*3+R()*.1;return[150*k,150*k,144*k,.5*n+.3*R()+.2]},(g,gb,s)=>{g.strokeStyle='rgba(0,0,0,.45)';gb.strokeStyle='#000';g.lineWidth=gb.lineWidth=3;g.strokeRect(0,0,s,s);gb.strokeRect(0,0,s,s);for(let i=0;i<10;i++){g.fillStyle='rgba(40,28,18,'+(.05+R()*.1)+')';g.fillRect(R()*s,R()*s*.4,2+R()*6,s*(.3+R()*.5))}});
TF.brick=()=>mkT(512,()=>[150,145,138,.1],(g,gb,s)=>{gb.fillStyle='#000';gb.fillRect(0,0,s,s);const bh=32,bw=64;for(let y=0;y<s/bh;y++)for(let x=-1;x<s/bw+1;x++){const o=y%2?bw/2:0,v=R();g.fillStyle='rgb('+(110+v*55|0)+','+(52+v*25|0)+','+(40+v*20|0)+')';g.fillRect(x*bw+o+2,y*bh+2,bw-4,bh-4);gb.fillStyle='rgb('+(170+v*70|0)+','+(170+v*70|0)+','+(170+v*70|0)+')';gb.fillRect(x*bw+o+2,y*bh+2,bw-4,bh-4)}for(let i=0;i<4000;i++){g.fillStyle='rgba(0,0,0,'+R()*.1+')';g.fillRect(R()*s,R()*s,1+R()*4,1+R()*4)}});
TF.crate=()=>mkT(256,(u,v,x,y)=>{const pl=Math.floor(y/32),off=(pl*37%11)*.6,n=fbm(u,v,8,3),gr=Math.sin(x*.09+off+n*9)*.5+.5,k=.55+.35*gr+.1*R();return[142*k,104*k,62*k,.3+.5*gr]},(g,gb,s)=>{for(let y=0;y<s;y+=32){g.fillStyle='rgba(20,12,6,.7)';g.fillRect(0,y,s,2);gb.fillStyle='#000';gb.fillRect(0,y,s,3)}g.strokeStyle='#2b2a26';g.lineWidth=14;g.strokeRect(7,7,s-14,s-14);gb.strokeStyle='#eee';gb.lineWidth=14;gb.strokeRect(7,7,s-14,s-14);g.lineWidth=10;g.beginPath();g.moveTo(10,10);g.lineTo(s-10,s-10);g.stroke()});
TF.bag=()=>mkT(256,()=>[90,80,60,.2],(g,gb,s)=>{gb.fillStyle='#000';gb.fillRect(0,0,s,s);const bh=32,bw=64;for(let y=0;y<s/bh;y++)for(let x=-1;x<s/bw+1;x++){const o=y%2?bw/2:0,v=R();g.fillStyle='rgb('+(150+v*40|0)+','+(130+v*35|0)+','+(95+v*25|0)+')';rr(g,x*bw+o+2,y*bh+2,bw-4,bh-4,12);g.fill();gb.fillStyle='#bbb';rr(gb,x*bw+o+2,y*bh+2,bw-4,bh-4,12);gb.fill()}});
function mkCont(c){return mkT(256,(u,v,x)=>{const rib=Math.sin(x/256*PI*2*14)*.5+.5,n=fbm(u,v,4,4),k=(.72+.28*rib)*(.75+.35*n)+R()*.05;return[c[0]*k,c[1]*k,c[2]*k,rib*.7+.2*n]},(g,gb,s)=>{for(let i=0;i<30;i++){g.fillStyle='rgba(95,45,20,'+(.06+R()*.12)+')';g.fillRect(R()*s,R()*s*.5,1+R()*4,20+R()*120)}})}
TF.cont0=()=>mkCont([62,88,58]);TF.cont1=()=>mkCont([128,52,40]);TF.cont2=()=>mkCont([50,78,112]);
function mkFac(night){const ec=document.createElement('canvas');ec.width=ec.height=512;const eg=ec.getContext('2d');eg.fillStyle='#000';eg.fillRect(0,0,512,512);
const T=mkT(512,(u,v)=>{const n=fbm(u,v,4,4),k=.62+.32*n+R()*.07;return[158*k,148*k,130*k,.5*n+.3*R()]},(g,gb)=>{g.fillStyle='rgba(0,0,0,.25)';g.fillRect(0,0,512,4);g.fillRect(0,256,512,4);
for(let r=0;r<2;r++)for(let c=0;c<4;c++){const x=c*128+30,y=r*256+56,w=68,h=132;gb.fillStyle='#000';gb.fillRect(x-4,y-4,w+8,h+8);g.fillStyle='#2b2b2b';g.fillRect(x-5,y-5,w+10,h+10);const gr=g.createLinearGradient(x,y,x+w,y+h);gr.addColorStop(0,'#5d7585');gr.addColorStop(.5,'#1b2630');gr.addColorStop(1,'#34444f');g.fillStyle=gr;g.fillRect(x,y,w,h);
if(night&&R()<.38){g.fillStyle='#e6c47a';g.fillRect(x,y,w,h);eg.fillStyle='rgb('+(180+R()*60|0)+','+(130+R()*50|0)+',60)';eg.fillRect(x,y,w,h)}else if(!night&&R()<.22){g.fillStyle='#0a0a0a';g.fillRect(x+4,y+6,w-8,h-12)}
g.fillStyle='#222';g.fillRect(x+w/2-2,y,4,h);g.fillRect(x,y+h*.45,w,4)}});
T.e=new THREE.CanvasTexture(ec);T.e.wrapS=T.e.wrapT=THREE.RepeatWrapping;T.e.encoding=THREE.sRGBEncoding;return T}
TF.fac=()=>mkWall();
function mkCamo(c){return mkT(256,(u,v,x,y)=>{const q=fbm(u,v,4,3)*.6+fbm(u+.4,v+.2,8,3)*.4,col=q<.38?c[0]:q<.5?c[1]:q<.62?c[2]:c[3],wv=Math.sin(x*2.2)*Math.sin(y*2.2),w=.85+.15*wv+R()*.08;return[col[0]*w,col[1]*w,col[2]*w,.5+.3*wv]})}
TF.camoE=()=>mkCamo([[75,78,64],[110,104,80],[55,58,50],[90,88,72]]);
TF.camoH=()=>mkCamo([[48,50,52],[70,70,66],[36,38,40],[58,56,52]]);
TF.camoA=()=>mkCamo([[58,72,45],[88,98,62],[36,48,32],[70,60,42]]);
TF.fence=()=>{const c=document.createElement('canvas');c.width=c.height=64;const g=c.getContext('2d');g.strokeStyle='rgba(185,188,192,.95)';g.lineWidth=2.2;g.beginPath();for(let i=-64;i<128;i+=32){g.moveTo(i,0);g.lineTo(i+64,64);g.moveTo(i+64,0);g.lineTo(i,64)}g.stroke();const t=new THREE.CanvasTexture(c);t.wrapS=t.wrapT=THREE.RepeatWrapping;t.encoding=THREE.sRGBEncoding;return{m:t}};
TF.dash=()=>{const c=document.createElement('canvas');c.width=16;c.height=64;const g=c.getContext('2d');g.fillStyle='#ddd';g.fillRect(3,0,10,28);const t=new THREE.CanvasTexture(c);t.wrapS=t.wrapT=THREE.RepeatWrapping;t.encoding=THREE.sRGBEncoding;return{m:t}};
const TX={},tx=n=>TX[n]||(TX[n]=TF[n]());
function radTex(stops){const c=document.createElement('canvas');c.width=c.height=64;const g=c.getContext('2d'),gr=g.createRadialGradient(32,32,0,32,32,32);stops.forEach(s=>gr.addColorStop(s[0],s[1]));g.fillStyle=gr;g.fillRect(0,0,64,64);const t=new THREE.CanvasTexture(c);return t}
const tSpr=radTex([[0,'rgba(255,255,255,1)'],[.35,'rgba(255,255,255,.55)'],[1,'rgba(255,255,255,0)']]),tHole=radTex([[0,'rgba(0,0,0,.9)'],[.5,'rgba(0,0,0,.6)'],[1,'rgba(0,0,0,0)']]);
function S(c,r,m,o){return new THREE.MeshStandardMaterial(Object.assign({color:new THREE.Color(c).convertSRGBToLinear(),roughness:r,metalness:m||0,envMapIntensity:.6},o||{}))}
function M(t,o){return new THREE.MeshStandardMaterial(Object.assign({map:t.m,bumpMap:LITE?null:t.b,bumpScale:ULTX?3:2.2,roughness:.92,metalness:.02,envMapIntensity:.45},o||{}))}
const MF={gunW:()=>S(0x8a5326,.5,.05),gravel:()=>M(tx('gravel')),sand:()=>M(tx('sand')),asph:()=>M(tx('asph'),{roughness:.85}),conc:()=>M(tx('conc')),brick:()=>M(tx('brick')),crate:()=>M(tx('crate'),{roughness:.8}),bag:()=>M(tx('bag')),
cont0:()=>M(tx('cont0'),{roughness:.5,metalness:.5,bumpScale:5}),cont1:()=>M(tx('cont1'),{roughness:.5,metalness:.5,bumpScale:5}),cont2:()=>M(tx('cont2'),{roughness:.5,metalness:.5,bumpScale:5}),
fac:()=>M(tx('fac'),{roughness:.9,bumpScale:2.6}),facB:()=>M(tx('fac'),{roughness:.9,bumpScale:2.6,color:new THREE.Color(0xbfc8cd).convertSRGBToLinear()}),facC:()=>M(tx('fac'),{roughness:.9,bumpScale:2.6,color:new THREE.Color(0xe6cf9f).convertSRGBToLinear()}),facN:()=>mt('fac'),
rock:()=>M(tx('gravel'),{color:new THREE.Color(0x998877).convertSRGBToLinear()}),
fence:()=>new THREE.MeshStandardMaterial({map:tx('fence').m,transparent:true,alphaTest:.4,side:THREE.DoubleSide,roughness:.6,metalness:.6}),dash:()=>new THREE.MeshStandardMaterial({map:tx('dash').m,transparent:true,roughness:.8}),
dark:()=>S(0x1d1e20,.45,.7),olive:()=>S(0x4f5a38,.7,.2),tarp:()=>S(0x56603f,1,0),rub:()=>S(0x101010,.95,0),white:()=>S(0xd8d8d2,.5,.1),red:()=>S(0x8c2a22,.7,.1),tankc:()=>S(0x56593a,.75,.3),
bar0:()=>S(0x8a2a22,.5,.6),bar1:()=>S(0x2a4a8a,.5,.6),bar2:()=>S(0x4a5a30,.5,.6),lamp:()=>new THREE.MeshStandardMaterial({color:0x222222,emissive:0xfff2c0,emissiveIntensity:2}),
uniE:()=>M(tx('camoE'),{roughness:1,bumpScale:1}),uniH:()=>M(tx('camoH'),{roughness:1,bumpScale:1}),uniA:()=>M(tx('camoA'),{roughness:1,bumpScale:1}),
vest:()=>S(0x2b2f27,.9),skin:()=>S(0xc59a78,.8),bal:()=>S(0x151515,.9),helA:()=>S(0x7a6f4f,.6,.1),helE:()=>S(0x1b1d1a,.5,.2),boot:()=>S(0x0d0d0d,.8),gunM:()=>S(0x44484d,.42,.45),gunB:()=>S(0x24262a,.6,.1),
bandA:()=>S(0x1e6fff,.8),bandE:()=>S(0xaa1111,.8),glove:()=>S(0x1a1a1a,.8)};
const mats={},mt=n=>mats[n]||(mats[n]=(()=>{const m=MF[n]();if(m&&m.userData)m.userData.sn=n;return m})());
const CZK='mo_cz';
const CZL={
uni:[['wood','WOODLAND',[[58,72,45],[88,98,62],[36,48,32],[70,60,42]]],['desert','DESERT',[[168,146,104],[194,172,128],[140,120,84],[120,104,74]]],['arctic','ARCTIC',[[205,210,214],[232,236,238],[168,176,186],[188,196,202]]],['urban','URBAN GREY',[[86,90,96],[118,122,128],[60,64,70],[100,104,110]]],['black','BLACKOUT',[[28,28,30],[44,44,48],[16,16,18],[36,36,38]]],['tiger','TIGER STRIPE',[[84,96,52],[40,36,22],[118,110,62],[22,26,16]]],['multi','MULTI-TERRAIN',[[126,114,84],[92,100,70],[150,128,96],[74,66,50]]],['navy','NAVY',[[30,44,70],[48,64,96],[20,28,46],[38,52,80]]],['crim','CRIMSON',[[110,28,26],[140,44,36],[70,18,18],[90,30,28]]]],
hat:[['none','NONE'],['helm','COMBAT HELMET'],['nvg','HELMET + NVG'],['hset','HEADSET HELMET'],['boon','BOONIE HAT'],['beanie','BEANIE'],['cap','CAP'],['band','HEADBAND']],
hc:[['olive','Olive',0x4a5236],['tan','Tan',0x8c7a55],['black','Black',0x1b1b1b],['grey','Grey',0x70757a],['white','White',0xdcdfe0],['red','Red',0x9c2222],['blue','Blue',0x24406e]],
mask:[['none','NONE (BARE FACE)',{k:'skin'}],['bal','BALACLAVA BLACK',{k:'bal',fab:[24,25,23]}],['balo','BALACLAVA OLIVE',{k:'bal',fab:[58,66,44]}],['balw','BALACLAVA WHITE',{k:'bal',fab:[214,218,220]}],['skull','SKULL BALACLAVA',{k:'skull',fab:[18,18,18]}],['skullw','SKULL BALACLAVA GREY',{k:'skull',fab:[78,82,86]}],['scarf','SHEMAGH',{k:'scarf'}],['resp','RESPIRATOR',{k:'mask'}],['gog','TAC GOGGLES',{k:'gog'}],['shade','AVIATOR SHADES',{k:'skin',sh:1}]],
paint:[['none','NONE'],['stripe','CAMO STRIPES'],['eyes','EYE GREASE'],['skull','SKULL PAINT'],['war','WAR PAINT'],['tiger','TIGER STRIPES'],['full','FULL CAMO'],['claw','CLAW MARKS'],['half','SPLIT BLACK']],
skin:[['sk0','Fair',[244,208,180]],['sk1','Light',[226,184,152]],['sk2','Tan',[196,152,118]],['sk3','Brown',[168,120,88]],['sk4','Dark',[128,90,64]],['sk5','Deep',[92,62,44]]],
hair:[['h0','Black',[20,16,14]],['h1','Brown',[70,46,28]],['h2','Blond',[196,162,92]],['h3','Ginger',[150,70,36]],['h4','Grey',[150,150,150]]],
beard:[['none','CLEAN SHAVEN'],['stub','STUBBLE'],['full','FULL BEARD']],
vest:[['none','NONE'],['light','PLATE CARRIER'],['heavy','HEAVY ARMOR'],['rig','CHEST RIG']],
vc:[['blk','Black',0x1f2022],['olive','Olive',0x3b4230],['coy','Coyote',0x8a7550],['grey','Grey',0x5a5f64],['wht','White',0xc9cdd0]],
pack:[['none','NONE'],['asl','ASSAULT PACK'],['radio','RADIO PACK']],
glove:[['skin','BARE HANDS'],['blk','BLACK',[30,30,32]],['tan','COYOTE',[140,118,82]],['oli','OLIVE',[62,70,48]],['gry','GREY',[96,100,104]],['red','RED',[130,26,24]]]};
const CZG=[['uni','OUTFIT · CAMO'],['hat','HEADGEAR'],['hc','HEADGEAR COLOR','c'],['mask','MASK / FACE COVER'],['paint','FACE PAINT'],['skin','SKIN TONE','c'],['hair','HAIR COLOR','c'],['beard','FACIAL HAIR'],['vest','ARMOR / VEST'],['vc','VEST COLOR','c'],['pack','BACKPACK'],['glove','GLOVES']];
const CZ0={uni:'wood',hat:'helm',hc:'olive',mask:'none',paint:'none',skin:'sk2',hair:'h0',beard:'none',vest:'light',vc:'olive',pack:'none',glove:'skin'};
const CZP=[['SPECTER',{uni:'black',hat:'hset',hc:'black',mask:'skull',vest:'light',vc:'blk',glove:'blk'}],['OVERWATCH',{uni:'wood',hat:'boon',hc:'olive',paint:'stripe',beard:'stub',vest:'light',vc:'olive',glove:'oli'}],['DESERT FOX',{uni:'desert',hat:'helm',hc:'tan',mask:'scarf',vest:'heavy',vc:'coy',pack:'asl',glove:'tan'}],['ARCTIC WOLF',{uni:'arctic',hat:'beanie',hc:'white',mask:'balw',vest:'rig',vc:'wht',glove:'gry'}],['URBAN SHADOW',{uni:'urban',hat:'nvg',hc:'grey',mask:'bal',vest:'heavy',vc:'blk',pack:'radio',glove:'blk'}],['WARLORD',{uni:'crim',hat:'band',hc:'red',paint:'war',beard:'full',vest:'none',glove:'blk'}],['JUNGLE HUNTER',{uni:'tiger',hat:'cap',hc:'olive',paint:'tiger',vest:'rig',vc:'olive',glove:'oli'}],['TECH OPS',{uni:'navy',hat:'helm',hc:'black',mask:'gog',vest:'light',vc:'blk',pack:'radio',glove:'blk'}]];
const czL=(g,id)=>CZL[g].find(x=>x[0]===id)||CZL[g][0];
let CZ=Object.assign({},CZ0);try{const o=JSON.parse(localStorage.getItem(CZK)||'null');if(o)for(const k in CZ0)if(typeof o[k]==='string')CZ[k]=o[k]}catch(e){}
function saveCZ(){try{localStorage.setItem(CZK,JSON.stringify(CZ))}catch(e){}}
const CZT={},czUni=id=>{const d=czL('uni',id);return CZT[d[0]]||(CZT[d[0]]=mkCamo(d[2]))};
const czSkin=()=>czL('skin',CZ.skin)[2],czHandCol=()=>CZ.glove==='skin'?czSkin():czL('glove',CZ.glove)[2];
MF.uniP=()=>M(czUni(CZ.uni));
MF.vestP=()=>S(czL('vc',CZ.vc)[2],.9);
MF.helP=()=>S(czL('hc',CZ.hc)[2],.65,.08);
MF.nvgP=()=>S(0x141c16,.4,.5,{emissive:new THREE.Color(0x0b4a1a),emissiveIntensity:.9});
let LOBP=null,HPM=null;
function czApply(){const u=mt('uniP'),t=czUni(CZ.uni);u.map=t.m;u.bumpMap=LITE?null:t.b;u.needsUpdate=true;
mt('vestP').color.setHex(czL('vc',CZ.vc)[2]).convertSRGBToLinear();mt('helP').color.setHex(czL('hc',CZ.hc)[2]).convertSRGBToLinear();
if(HPM){const h=handTex(czHandCol());HPM.map=h;if(!LITE)HPM.bumpMap=h;HPM.needsUpdate=true}}
const CZFC={},CZFK=[];
function czFace(c){const V=Object.assign({sk:czL('skin',c.skin)[2],hr:czL('hair',c.hair)[2],eye:[62,44,28],ears:1,st:c.beard==='stub'?1:0,bd:c.beard==='full'?1:0,pt:c.paint==='none'?0:c.paint},czL('mask',c.mask)[2]),key=JSON.stringify(V);
let m=CZFC[key];if(!m){const t=new THREE.CanvasTexture(paintFace(V));t.encoding=THREE.sRGBEncoding;t.anisotropy=LITE?1:4;m=CZFC[key]=new THREE.MeshStandardMaterial({map:t,roughness:.86,metalness:0});CZFK.push(key);if(CZFK.length>8){const o=CZFK.shift();CZFC[o].map.dispose();CZFC[o].dispose();delete CZFC[o]}}return m}
const CYC={},Cy=(a,b,h,s)=>{const k=a+','+b+','+h+','+s;return CYC[k]||(CYC[k]=new THREE.CylinderGeometry(a,b,h,s))};
function czHat(Pt,c){const h=mt('helP'),dk=mt('dark'),hs=(w,hh,d,x,y,z,m)=>{const e=Pt(Bx(w,hh,d),m||h,x,y,z);e.userData.head=1;return e},ht=c.hat;
if(ht==='helm'||ht==='nvg'||ht==='hset'){hs(.25,.11,.27,0,1.8,0);hs(.26,.03,.28,0,1.755,0)}
if(ht==='nvg'){hs(.06,.05,.08,0,1.8,-.15,dk);for(const s of[-1,1])hs(.05,.05,.09,s*.045,1.77,-.19,mt('nvgP'))}
if(ht==='hset'){for(const s of[-1,1])hs(.04,.1,.1,s*.125,1.67,.01,dk);hs(.015,.015,.11,-.1,1.62,-.08,dk)}
if(ht==='boon'){const a=Pt(Cy(.115,.125,.09,10),h,0,1.805,0),b=Pt(Cy(.2,.2,.018,12),h,0,1.76,0);a.userData.head=b.userData.head=1}
if(ht==='beanie'){hs(.215,.1,.235,0,1.785,0);hs(.225,.04,.245,0,1.735,0)}
if(ht==='cap'){hs(.21,.07,.225,0,1.79,0);hs(.15,.014,.12,0,1.762,-.17)}
if(ht==='band'){hs(.205,.045,.215,0,1.762,0);hs(.05,.07,.02,.07,1.745,.115)}}
function czVest(Pt,c){const v=mt('vestP'),dk=mt('dark'),t=c.vest;
if(t==='light'){Pt(Bx(.48,.36,.3),v,0,1.34,0);Pt(Bx(.38,.1,.06),v,0,1.2,-.17);for(const x of[-.12,0,.12])Pt(Bx(.08,.11,.05),dk,x,1.22,-.2)}
else if(t==='heavy'){Pt(Bx(.5,.44,.34),v,0,1.33,0);Pt(Bx(.36,.3,.07),dk,0,1.32,-.19);Pt(Bx(.22,.14,.05),v,0,1.04,-.15);for(const s of[-1,1]){Pt(Bx(.13,.07,.18),v,s*.3,1.56,0);Pt(Bx(.06,.14,.1),dk,s*.28,1.2,-.1)}}
else if(t==='rig'){Pt(Bx(.42,.22,.12),v,0,1.38,-.12);for(const x of[-.13,0,.13])Pt(Bx(.08,.1,.05),dk,x,1.36,-.2);for(const s of[-1,1])Pt(Bx(.04,.03,.28),v,s*.1,1.53,0)}}
function czPack(Pt,c){const v=mt('vestP'),dk=mt('dark');
if(c.pack==='asl'){Pt(Bx(.3,.34,.15),v,0,1.34,.21);Pt(Bx(.24,.06,.14),dk,0,1.54,.21)}
else if(c.pack==='radio'){Pt(Bx(.26,.3,.14),dk,0,1.33,.2);Pt(Bx(.015,.015,.5),dk,.09,1.7,.22)}}
function czAvatar(Pt,c){Pt(headGeo(1),czFace(c),0,1.67,0).userData.head=1;czHat(Pt,c);return czHandCol()}
function czSpawn(){if(LOBP){sc.remove(LOBP);LOBP=null}LOBP=soldier('rifle',1,6.3,-1.8,CZ);LOBP.userData.name='ALPHA-1';LOBP.userData.alert=false;LOBP.rotation.y=PI;rd.shadowMap.needsUpdate=true;rdDirty=true}
function czKill(){if(LOBP){sc.remove(LOBP);LOBP=null}}
function czCommit(){saveCZ();czApply();czSpawn();rdDirty=true;lobUI()}
const PNT={
stripe(g){g.lineCap='round';for(const s of[0,1]){const X=x=>s?64-x:x;for(const q of[[4,34,17,42,'rgba(16,18,12,.86)',3.6],[5,41,15,50,'rgba(16,18,12,.86)',3.2],[7,37,19,45,'rgba(78,100,54,.88)',3]]){g.strokeStyle=q[4];g.lineWidth=q[5];g.beginPath();g.moveTo(X(q[0]),q[1]);g.lineTo(X(q[2]),q[3]);g.stroke()}}g.strokeStyle='rgba(16,18,12,.8)';g.lineWidth=3;g.beginPath();g.moveTo(14,15);g.lineTo(50,15);g.stroke();g.strokeStyle='rgba(78,100,54,.85)';g.beginPath();g.moveTo(18,19);g.lineTo(46,19);g.stroke();g.strokeStyle='rgba(16,18,12,.7)';g.lineWidth=2;g.beginPath();g.moveTo(32,22);g.lineTo(32,38);g.stroke()},
eyes(g,el){el(20,35.8,8.2,2.2,'rgba(8,8,8,.88)');el(44,35.8,8.2,2.2,'rgba(8,8,8,.88)');g.fillStyle='rgba(8,8,8,.7)';g.fillRect(14,14,36,2.4)},
skull(g,el){g.fillStyle='rgba(236,233,223,.93)';g.beginPath();g.moveTo(8,42);g.lineTo(56,42);g.lineTo(54,56);g.lineTo(44,63);g.lineTo(20,63);g.lineTo(10,56);g.closePath();g.fill();g.fillStyle='#14100e';for(let x=22;x<=42;x+=4)g.fillRect(x,50,1.2,12);g.fillRect(18,53,28,1.3);g.beginPath();g.moveTo(32,38);g.lineTo(29,44);g.lineTo(35,44);g.closePath();g.fill();g.strokeStyle='rgba(8,8,8,.88)';g.lineWidth=3;for(const x of[20,44]){g.beginPath();g.ellipse(x,30,8.6,6,0,0,6.283);g.stroke()}},
war(g){g.fillStyle='rgba(170,20,18,.9)';g.fillRect(3,33,58,5);g.fillStyle='rgba(236,236,226,.88)';for(const x of[18,32,46])g.fillRect(x-1.5,10,3,10);g.fillRect(27,52,3,10);g.fillRect(36,52,3,10)},
tiger(g){g.fillStyle='rgba(70,84,48,.34)';g.fillRect(0,10,64,54);g.strokeStyle='rgba(16,14,9,.82)';g.lineWidth=2.4;g.lineCap='round';for(const x of[5,10,15]){g.beginPath();g.moveTo(x,34);g.lineTo(x+4,54);g.stroke();g.beginPath();g.moveTo(64-x,34);g.lineTo(60-x,54);g.stroke()}for(let x=14;x<=50;x+=6){g.beginPath();g.moveTo(x,11);g.lineTo(x+(x<32?2:-2),20);g.stroke()}},
full(g,el,spk,rnd){g.fillStyle='rgba(64,80,46,.94)';g.fillRect(0,10,64,54);const C=['rgba(14,14,10,.78)','rgba(104,86,52,.7)','rgba(30,40,22,.75)'];for(let i=0;i<20;i++)el(4+rnd()*56,12+rnd()*50,3+rnd()*7,2+rnd()*4,C[i%3]);spk(0,10,64,54,300,'rgba(0,0,0,.2)')},
claw(g){g.strokeStyle='rgba(172,20,18,.9)';g.lineWidth=2.2;g.lineCap='round';for(let i=0;i<3;i++){g.beginPath();g.moveTo(6+i*5,29);g.lineTo(14+i*5,53);g.stroke()}},
half(g){g.fillStyle='rgba(12,12,12,.76)';g.fillRect(32,10,32,54);g.fillStyle='rgba(235,235,225,.8)';g.fillRect(31,10,1.4,54)},
shades(g){g.fillStyle='#0b0b0d';g.fillRect(6,23,23,13);g.fillRect(35,23,23,13);g.fillRect(29,26,6,3);g.fillRect(0,26,6,2);g.fillRect(58,26,6,2);g.fillStyle='rgba(170,205,230,.28)';g.beginPath();g.moveTo(9,35);g.lineTo(14,24);g.lineTo(17,24);g.lineTo(12,35);g.closePath();g.fill();g.beginPath();g.moveTo(38,35);g.lineTo(43,24);g.lineTo(46,24);g.lineTo(41,35);g.closePath();g.fill()}};
const GC={},Bx=(w,h,d)=>{const k=w+','+h+','+d;return GC[k]||(GC[k]=new THREE.BoxGeometry(w,h,d))};
const rd=new THREE.WebGLRenderer({antialias:true,powerPreference:'high-performance'});rd.domElement.id='gl';rd.domElement.addEventListener('webglcontextlost',e=>{e.preventDefault();try{pauseG()}catch(_){}window.moBox('GRAPHICS INTERRUPTED','The browser reclaimed the graphics memory (low memory or app switch). Reload to continue; mission progress is saved.')});
rd.info.autoReset=false;rd.outputEncoding=THREE.sRGBEncoding;rd.toneMapping=THREE.ACESFilmicToneMapping;rd.shadowMap.enabled=true;rd.shadowMap.autoUpdate=false;rd.shadowMap.needsUpdate=true;rd.shadowMap.type=THREE.PCFShadowMap;rd.autoClear=false;
document.body.prepend(rd.domElement);
const sc=new THREE.Scene();sc.fog=new THREE.Fog(0xbbbbbb,25,130);
const cam=new THREE.PerspectiveCamera(72,1,.1,420);sc.add(cam);
const hemi=new THREE.HemisphereLight(0xcfe0ee,0x4a4030,1);sc.add(hemi);
const sun=new THREE.DirectionalLight(0xfff0d0,2);sun.castShadow=true;const sh=sun.shadow.camera;sh.left=-50;sh.right=50;sh.top=50;sh.bottom=-50;sh.near=1;sh.far=260;sun.shadow.bias=-.0004;sun.shadow.normalBias=.03;sc.add(sun);sc.add(sun.target);
const torch=new THREE.SpotLight(0xfff2d0,0,55,.5,.55,1.2);cam.add(torch);torch.position.set(.1,-.1,0);torch.target.position.set(0,0,-6);cam.add(torch.target);
const expL=new THREE.PointLight(0xff9a44,0,28,2),flashW=new THREE.PointLight(0xffa850,0,18,2);sc.add(expL);sc.add(flashW);
const gs=new THREE.Scene(),cam2=new THREE.PerspectiveCamera(58,1,.01,10);gs.add(cam2);
const gH=new THREE.HemisphereLight(0xdfe8f2,0x403830,1.1),gD=new THREE.DirectionalLight(0xfff0d8,1.6);gD.position.set(.4,1,.6);gs.add(gH);gs.add(gD);
const gR1=new THREE.DirectionalLight(0xbfd8ff,0),gR2=new THREE.DirectionalLight(0xffffff,0);gR1.position.set(-1,.6,-1);gR2.position.set(1,-.4,.8);gs.add(gR1);gs.add(gR2);
function gunLit(c){gH.intensity=c?2.2:1.1;gD.intensity=c?2.4:1.6;gR1.intensity=c?2:0;gR2.intensity=c?1.2:0}
const skyM=new THREE.MeshBasicMaterial({side:THREE.BackSide,fog:false,depthWrite:false}),sky=new THREE.Mesh(new THREE.SphereGeometry(200,32,16),skyM);sky.renderOrder=-10;sky.frustumCulled=false;sc.add(sky);
let SD=[.5,.6,.3];
function drawSky(S_){const W=512,H=256,c=document.createElement('canvas');c.width=W;c.height=H;const g=c.getContext('2d'),im=g.createImageData(W,H),d=im.data;
for(let y=0;y<H;y++){const t=y/H,e=1-t*2;for(let x=0;x<W;x++){const u=x/W,k=Math.pow(clamp(e,0,1),.55);let r=lerp(S_.hor[0],S_.top[0],k),gg=lerp(S_.hor[1],S_.top[1],k),b=lerp(S_.hor[2],S_.top[2],k);
if(e>.02){const cl=clamp((fbm(u,t*2,4,4)-S_.cl)*3.2,0,1)*clamp(e*3,0,1);if(cl>0){const sh2=.75+.25*fbm(u+.2,t*2+.1,8,3);r=lerp(r,S_.cc[0]*sh2,cl);gg=lerp(gg,S_.cc[1]*sh2,cl);b=lerp(b,S_.cc[2]*sh2,cl)}}
if(S_.stars&&e>.05&&R()<.004){const v=120+R()*135;r=gg=b=v}
const o=(y*W+x)*4;d[o]=r;d[o+1]=gg;d[o+2]=b;d[o+3]=255}}
g.putImageData(im,0,0);const dl=Math.hypot(SD[0],SD[1],SD[2]),dx=SD[0]/dl,dy=SD[1]/dl,dz=SD[2]/dl,th=Math.acos(dy),ph=(Math.atan2(dz,-dx)+2*PI)%(2*PI),sx=ph/(2*PI)*W,sy=th/PI*H;
g.globalCompositeOperation='lighter';const rad=g.createRadialGradient(sx,sy,0,sx,sy,S_.sr||40);rad.addColorStop(0,S_.sunc);rad.addColorStop(.12,S_.sunc2);rad.addColorStop(1,'rgba(0,0,0,0)');g.fillStyle=rad;g.fillRect(0,0,W,H);
const t=new THREE.CanvasTexture(c);t.encoding=THREE.sRGBEncoding;skyM.map=t;skyM.needsUpdate=true;SKYT=t;if(ULTX)buildEnv()}
function buildEnv(){try{if(!SKYT||!ULTX)return;const pg=new THREE.PMREMGenerator(rd);pg.compileEquirectangularShader();const rt=pg.fromEquirectangular(SKYT);pg.dispose();if(ENVR)ENVR.dispose();ENVR=rt;ENVT=rt.texture;if(!NV.on){sc.environment=ENVT;gs.environment=ENVT}}catch(e){ENVT=null;sc.environment=null;gs.environment=null}}
function ultApply(){const u=!LITE&&CFG.preset==='ULTRA';const ch=u!==ULTX;ULTX=u;document.body.classList.toggle('ult',u);if(!u){sc.environment=null;gs.environment=null}else if(ch||!ENVT)buildEnv();else if(!NV.on){sc.environment=ENVT;gs.environment=ENVT}if(ch)hemi.intensity*=u?.62:1/.62}
const PRE={SMOOTH:{res:1,shadow:1,dist:.68,lights:0,dyn:1,cap:30},MEDIUM:{res:1.25,shadow:2,dist:.8,lights:1},HIGH:{res:1.5,shadow:2,dist:1,lights:1},ULTRA:{res:2,shadow:3,dist:1.4,lights:1}};
const DEF=Object.assign({preset:'HIGH',fov:72,bright:1,sens:1,vol:1,fps:1,aq:1,jdz:10,assist:2,smooth:.3,adsS:1,sway:2,hap:1,cine:1,adsHold:1,bsz:1,bop:1,rcv:2,dyn:1,cap:0,radar:1},PRE.HIGH),SHS=[0,512,1024,2048],GK=['res','shadow','dist','lights'];
let CFG=Object.assign({},DEF),fogB=null,expB=1,fpsN=0,fpsT=0,paused=false;
let lgLock=0,lobK=1,lgT=0,lgN=0,lgW=2,lgUp=0,dynK=1,pgT=0,pgN=0,pgMax=0,pgUp=0,pgBan=0,shEvery=1,shN=0,rdDirty=true,frN=0,hz=60,skN=1,skC=0,hzS=[],hzP=0,hzDone=false,pgLow=0,autoCap=999;
{const co=navigator.hardwareConcurrency||4,me=navigator.deviceMemory||4,mob=/Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent)||(navigator.maxTouchPoints>1&&/Mac/.test(navigator.platform));if(mob)autoCap=(me<=3||co<=4)?30:60}
function capN(){return Math.max(1,Math.round(hz/Math.max(1,CFG.cap||autoCap)))}
try{const o=JSON.parse(localStorage.getItem('mo_set')||'null');if(o)Object.assign(CFG,o);else{const q=localStorage.getItem('mo_q');if(q!==null){CFG.preset=['ULTRA','HIGH','MEDIUM'][+q]||'HIGH';Object.assign(CFG,PRE[CFG.preset])}}}catch(e){}
if(CFG.preset==='LOW'){CFG.preset='MEDIUM';Object.assign(CFG,PRE.MEDIUM)}
if(LITE&&!/^(SMOOTH|CUSTOM)$/.test(CFG.preset)){CFG.preset='SMOOTH';Object.assign(CFG,PRE.SMOOTH)}else if(!LITE&&CFG.preset==='SMOOTH'){CFG.preset='MEDIUM';Object.assign(CFG,PRE.MEDIUM)}
ULTX=!LITE&&CFG.preset==='ULTRA';
function saveS(){try{localStorage.setItem('mo_set',JSON.stringify(CFG))}catch(e){}}
function applyFog(){if(fogB){sc.fog.near=fogB[0]*CFG.dist;sc.fog.far=fogB[1]*CFG.dist}}
function applyUI(){const q=document.documentElement.style;q.setProperty('--bs',CFG.bsz||1);q.setProperty('--bo',CFG.bop||1);document.body.classList.toggle('cn',!!CFG.cine&&!LITE)}
function applyS(){applyUI();ultApply();const n=(ULTX&&CFG.shadow>=3)?4096:SHS[CFG.shadow];sun.castShadow=n>0&&!PQ.noSh;if(n>0){sun.shadow.mapSize.set(n,n);if(sun.shadow.map){sun.shadow.map.dispose();sun.shadow.map=null}}
if(!CFG.dyn)dynK=1;rd.setPixelRatio(inLobby?Math.min(window.devicePixelRatio||1,LITE?1:1.4)*lobK:Math.min(window.devicePixelRatio||1,CFG.res,PQ.pr)*dynK);rd.shadowMap.needsUpdate=true;rd.toneMappingExposure=expB*CFG.bright;applyFog();
if(!run){cam.fov=CFG.fov;cam.updateProjectionMatrix()}
fireL.forEach(l=>l.visible=!!CFG.lights);if(mg)mg.gain.value=.9*CFG.vol;$('fps').style.display=CFG.fps?'block':'none';resize()}
function mkRow(l){const r=document.createElement('div');r.className='row';const s=document.createElement('span');s.textContent=l;r.appendChild(s);return r}
function chg(){dynK=1;skN=capN();skC=0;saveS();applyS();syncUI()}
function seg(l,key,opts,id){const r=mkRow(l);if(id)r.firstChild.id=id;const g=document.createElement('div');g.className='seg';opts.forEach(o=>{const b=document.createElement('button');b.className='sm';b.textContent=o[0];b.dataset.k=key;b.dataset.v=String(o[1]);
b.onclick=()=>{if(key==='preset'){const L=o[1]==='SMOOTH';if(L!==LITE){CFG.preset=o[1];Object.assign(CFG,PRE[o[1]]);saveS();try{localStorage.setItem('mo_lite',L?'1':'0')}catch(e){}location.reload();return}}CFG[key]=o[1];if(key==='preset')Object.assign(CFG,PRE[o[1]]);else if(GK.includes(key))CFG.preset='CUSTOM';chg()};g.appendChild(b)});r.appendChild(g);return r}
function slid(l,key,mn,mx,st,fmt){const r=mkRow(l),w=document.createElement('div'),i=document.createElement('input'),v=document.createElement('b');i.type='range';i.min=mn;i.max=mx;i.step=st;i.dataset.k=key;
i.oninput=()=>{CFG[key]=+i.value;if(GK.includes(key))CFG.preset='CUSTOM';chg()};i._f=fmt;i._v=v;w.appendChild(i);w.appendChild(v);r.appendChild(w);return r}
function head(t){const d=document.createElement('div');d.className='sec';d.textContent=t;return d}
function syncUI(){document.querySelectorAll('#sbody .seg button').forEach(b=>b.classList.toggle('on',String(CFG[b.dataset.k])===b.dataset.v));
document.querySelectorAll('#sbody input[type=range]').forEach(i=>{i.value=CFG[i.dataset.k];i._v.textContent=i._f(CFG[i.dataset.k])});
const p=$('plab');if(p)p.textContent=CFG.preset==='CUSTOM'?'PRESET (CUSTOM)':'PRESET';sndUI()}
function buildSet(){const el=$('sbody');el.innerHTML='';
el.appendChild(head('GRAPHICS'));
el.appendChild(seg('PRESET','preset',[['SMOOTH','SMOOTH'],['MEDIUM','MEDIUM'],['HIGH','HIGH'],['ULTRA','ULTRA']],'plab'));{const sh=document.createElement('div');sh.className='ob';sh.style.cssText='padding:2px 2px 6px;opacity:.6;font-size:12px';sh.textContent='SMOOTH MODE: for 2GB RAM phones (light textures, soft low-res shadows, no windows, fewer enemies at once, 30 FPS). Switching restarts the game page.';el.appendChild(sh)}
el.appendChild(slid('RESOLUTION','res',.5,2,.25,v=>v.toFixed(2)+'x'));
el.appendChild(seg('SHADOWS','shadow',[['OFF',0],['LOW',1],['MED',2],['HIGH',3]]));
el.appendChild(seg('VIEW DISTANCE','dist',[['NEAR',.6],['MID',.8],['FAR',1],['MAX',1.4]]));
el.appendChild(seg('FIRE LIGHTS','lights',[['OFF',0],['ON',1]]));
el.appendChild(seg('DYNAMIC RESOLUTION','dyn',[['OFF',0],['ON',1]]));el.appendChild(seg('FPS LIMIT','cap',[['AUTO',0],['30',30],['60',60],['90',90],['120',120]]));
const hi=document.createElement('div');hi.className='ob';hi.style.cssText='padding:4px 2px;opacity:.6';hi.textContent='Display '+hz+' Hz \u00b7 running at '+Math.round(hz/skN)+' FPS max'+(CFG.cap?'':' (auto)');el.appendChild(hi);
el.appendChild(slid('FIELD OF VIEW','fov',60,100,1,v=>v+'°'));
el.appendChild(slid('BRIGHTNESS','bright',.6,1.5,.05,v=>Math.round(v*100)+'%'));
el.appendChild(seg('FPS COUNTER','fps',[['OFF',0],['ON',1]]));el.appendChild(seg('AUTO QUALITY','aq',[['OFF',0],['ON',1]]));
el.appendChild(head('CONTROLS & AUDIO'));
el.appendChild(slid('LOOK SENSITIVITY','sens',.5,2,.05,v=>v.toFixed(2)+'x'));
el.appendChild(sndRow());el.appendChild(slid('VOLUME','vol',0,1,.05,v=>Math.round(v*100)+'%'));
el.appendChild(head('AIMING'));
el.appendChild(seg('AIM ASSIST','assist',[['OFF',0],['LOW',1],['MED',2],['HIGH',3]]));
el.appendChild(slid('LOOK SMOOTHING','smooth',0,1,.05,v=>v<=0?'OFF':Math.round(v*100)+'%'));
el.appendChild(slid('ADS SENSITIVITY','adsS',.4,1.5,.05,v=>v.toFixed(2)+'x'));
el.appendChild(seg('SCOPE SWAY','sway',[['OFF',0],['LOW',1],['REAL',2]]));
el.appendChild(seg('RECOIL CONTROL','rcv',[['OFF',0],['LOW',1],['MED',2],['HIGH',3]]));
el.appendChild(seg('AIM MODE','adsHold',[['TOGGLE',0],['HOLD',1]]));
el.appendChild(head('TOUCH + FEEL'));
el.appendChild(slid('BUTTON SIZE','bsz',.8,1.4,.05,v=>Math.round(v*100)+'%'));
el.appendChild(slid('BUTTON OPACITY','bop',.3,1,.05,v=>Math.round(v*100)+'%'));
el.appendChild(seg('MINIMAP RADAR','radar',[['OFF',0],['ON',1]]));el.appendChild(seg('VIBRATION','hap',[['OFF',0],['ON',1]]));el.appendChild(slid('JOYSTICK DEADZONE','jdz',0,60,2,v=>v+'px'));
el.appendChild(seg('CINEMATIC LOOK','cine',[['OFF',0],['ON',1]]));
syncUI()}
function openOv(id){$(id).style.display='flex'}function closeOv(id){$(id).style.display='none'}
$('setb').onclick=$('pst').onclick=()=>{buildSet();openOv('set')};
$('sback').onclick=()=>closeOv('set');
$('sdef').onclick=()=>{Object.assign(CFG,DEF);chg()};
{const b=$('srs');let tm=0,arm=0;b.onclick=()=>{if(!arm){arm=1;b.textContent='TAP AGAIN TO CONFIRM';clearTimeout(tm);tm=setTimeout(()=>{arm=0;b.textContent='RESET SAVE'},3000);return}arm=0;clearTimeout(tm);try{['mo_p','mo_xp','mo_best','mo_save'].forEach(k=>localStorage.removeItem(k))}catch(e){}xpBank=0;b.textContent='SAVE RESET \u2713';tm=setTimeout(()=>{b.textContent='RESET SAVE'},1800);try{refreshMenu()}catch(e){}}}
$('howb').onclick=()=>openOv('how');$('hback').onclick=()=>closeOv('how');
const P={x:0,z:72,y:1.7,vy:0,yaw:0,pitch:0,rec:0,recY:0,hp:100,ground:true,hurtT:99};
let fireT=0,kick=0,ads=0,adsV=0,rcAcc=0,rcAccY=0,rcN=0,rcT=9,rcDir=1,adsOn=false,sprintK=0,sprint=false,moving=false,firing=false,stepT=0,swX=0,swY=0,lookDX=0,lookDY=0,flashT=0,shotN=0,bloom=0,aimFr=1,arT=0,afT=0;
const rl={on:0,t:0,empty:0,ev:{},sh:0,n:0,done:0,tot:1,nmag:null},swp={on:0,t:0,to:0},pmp={on:0,t:0,e1:0,e2:0},act={on:0,t:0,dur:1,type:'',fn:null,d:0,lw:0,dip:0,s:0},chq={on:0,t:0,fed:0};let bolt=0,semiOK=true,scopeOn=false,keepLoad=0;
let lowHbT=0,mi=0,cur=null,si=0,score=0,run=false,cin=false,skipF=false,ready=false,time=0,cp={x:0,z:72,yaw:0},hitFlash=0,hmT=0,shake=0,lastR=0,popT=null,rt=null,cutT=0;
const stg={},enemies=[],allies=[],corpses=[];
const v3=new THREE.Vector3(),v4=new THREE.Vector3(),ray=new THREE.Raycaster();
function mkSpr(tex,col,add,sz){const m=new THREE.SpriteMaterial({map:tex,color:col,transparent:true,depthWrite:false,blending:add?THREE.AdditiveBlending:THREE.NormalBlending}),s=new THREE.Sprite(m);s.raycast=function(){};s.scale.set(sz,sz,1);return s}
const fxP=[];for(let i=0;i<(LITE?130:380);i++){const s=mkSpr(tSpr,0xffffff,0,1);s.visible=false;s.userData={};sc.add(s);fxP.push(s)}let fxI=0;
function puff(o){if(PQ.fx<1&&((PQ.n=(PQ.n+1)|0)&1))return;const s=fxP[fxI=(fxI+1)%fxP.length],u=s.userData;s.position.set(o.x,o.y,o.z);u.vx=o.vx||0;u.vy=o.vy||0;u.vz=o.vz||0;u.life=u.max=o.life;u.sz=o.sz;u.grow=o.grow||0;u.drag=o.drag||0;u.grav=o.grav||0;u.op=o.op||.8;s.material.color.set(o.col);s.material.blending=o.add?THREE.AdditiveBlending:THREE.NormalBlending;s.visible=true}
const trM=new THREE.MeshBasicMaterial({color:0xffd9a0,transparent:true,opacity:.85,blending:THREE.AdditiveBlending,depthWrite:false,fog:false}),trP=[];for(let i=0;i<28;i++){const m=new THREE.Mesh(Bx(1,1,1),trM);m.visible=false;m.userData.l=0;sc.add(m);trP.push(m)}let trI=0;
function tracer(ax,ay,az,bx,by,bz,w){const m=trP[trI=(trI+1)%trP.length],L=Math.hypot(bx-ax,by-ay,bz-az);m.position.set((ax+bx)/2,(ay+by)/2,(az+bz)/2);m.scale.set(w||.03,w||.03,Math.max(.1,L));m.lookAt(bx,by,bz);m.visible=true;m.userData.l=.07}
const dcM=new THREE.MeshBasicMaterial({map:tHole,transparent:true,depthWrite:false,polygonOffset:true,polygonOffsetFactor:-4}),dcP=[];for(let i=0;i<40;i++){const m=new THREE.Mesh(new THREE.PlaneGeometry(.14,.14),dcM);m.visible=false;sc.add(m);dcP.push(m)}let dcI=0;
const hitDir={x:0,z:1,p:30,ex:0},bdM=new THREE.MeshBasicMaterial({map:radTex([[0,'rgba(120,10,10,.95)'],[.55,'rgba(95,8,8,.85)'],[1,'rgba(80,6,6,0)']]),transparent:true,depthWrite:false,polygonOffset:true,polygonOffsetFactor:-3}),bldP=[];let bI=0;
for(let i=0;i<14;i++){const m=new THREE.Mesh(new THREE.PlaneGeometry(1.3,1.3),bdM);m.rotation.x=-PI/2;m.visible=false;sc.add(m);bldP.push(m)}
function decal(p,n){const m=dcP[dcI=(dcI+1)%dcP.length];m.position.copy(p).addScaledVector(n,.015);m.lookAt(v3.copy(p).add(n));m.rotateZ(R()*6);m.visible=true}
const csM=new THREE.MeshStandardMaterial({color:0xc9a24a,metalness:.9,roughness:.3}),csG=new THREE.CylinderGeometry(.007,.007,.04,6),csP=[];for(let i=0;i<20;i++){const m=new THREE.Mesh(csG,csM);m.visible=false;m.userData={l:0};sc.add(m);csP.push(m)}let csI=0;
const mgP=[];for(let i=0;i<4;i++){const m=new THREE.Mesh(Bx(.042,.2,.066),new THREE.MeshStandardMaterial({color:0x23262a,metalness:.8,roughness:.4}));m.visible=false;m.userData={l:0};sc.add(m);mgP.push(m)}let mgI=0;
function dropMag(){gun.updateMatrixWorld(true);const m=mgP[mgI=(mgI+1)%4],u=m.userData;cw.mag.getWorldPosition(m.position);m.scale.set(wd.mm[0]/.042,wd.mm[1]/.2,wd.mm[2]/.066);m.position.y-=.05;u.v=new THREE.Vector3(R()-.5,-1,R()-.5);u.l=8;u.s=new THREE.Vector3(R()*6,R()*6,R()*6);m.visible=true}
const EJP={m4:[.034,.062,-.02],ak:[.034,.04,-.06],lmg:[.034,.04,-.06],smg:[.028,.062,-.02],sg:[.034,.02,-.03],dmr:[.033,.03,-.04],snp:[.033,.03,-.04],pi:[.021,.048,-.04]};
function ejectCase(sh){const id=WS&&WS.id,p=EJP[id];if(!p)return;gun.updateMatrixWorld(true);const m=csP[csI=(csI+1)%20],u=m.userData;v3.set(p[0],p[1],p[2]);gun.localToWorld(v3);m.position.copy(v3);const rx=Math.cos(P.yaw),rz=-Math.sin(P.yaw),fx=-Math.sin(P.yaw),fz=-Math.cos(P.yaw),sp=2.2+R()*1.3,bk=.3+R()*.6;u.v=new THREE.Vector3(rx*sp-fx*bk,1.6+R()*1.1,rz*sp-fz*bk);u.l=.5;u.s=new THREE.Vector3(R()*20,R()*20,R()*20);u.s0=sh?2.4:id==='pi'?.7:id==='smg'?.75:1;m.scale.setScalar(u.s0);m.visible=true}
function sub(w,t){$('sub').innerHTML=w?'<b>'+w+'</b>'+t:''}
function radio(w,t){if(NET.h&&NET.on)nSend({k:'rad',w:w,x:t});sub(w,t);say(w,t);clearTimeout(rt);rt=setTimeout(()=>sub('',''),Math.max(2800,t.length*65))}
function pop(t){const e=$('pop');e.textContent=t;e.style.opacity=1;clearTimeout(popT);popT=setTimeout(()=>e.style.opacity=0,1500)}
let world=null,wpts=[];const CRT=[];const boxes=[],solids=[],tgObjs=[],tgs=[],anim=[],emit=[],fireL=[];
function boxGeo(w,h,d,ts){const g=new THREE.BoxGeometry(w,h,d),uv=g.attributes.uv,tu=Array.isArray(ts)?ts[0]:ts,tv=Array.isArray(ts)?ts[1]:ts,dm=[[d,h],[d,h],[w,d],[w,d],[w,h],[w,h]];for(let f=0;f<6;f++)for(let i=0;i<4;i++){const k=f*4+i;uv.setXY(k,uv.getX(k)*dm[f][0]/tu,uv.getY(k)*dm[f][1]/tv)}return g}
function mesh(geo,m,x,y,z,o){o=o||{};const e=new THREE.Mesh(geo,m);e.position.set(x,y,z);if(o.ry)e.rotation.y=o.ry;e.castShadow=o.cs!==false;e.receiveShadow=true;(o.p||world).add(e);return e}
function box(x,z,w,h,d,m,ts,o){o=o||{};const y0=o.y0||0,e=mesh(boxGeo(w,h,d,ts||4),m,x,y0+h/2,z,o);if(!o.nc){boxes.push({x0:x-w/2,x1:x+w/2,z0:z-d/2,z1:z+d/2,h:y0+h,see:o.see,mat:m});if(!o.ns)solids.push(e)}return e}
function cyl(x,z,r,h,m,o){o=o||{};const e=mesh(new THREE.CylinderGeometry(r,r,h,o.seg||14),m,x,(o.y0||0)+h/2,z,o);if(!o.nc){boxes.push({x0:x-r,x1:x+r,z0:z-r,z1:z+r,h:(o.y0||0)+h});solids.push(e)}return e}
const GRD={n:-1,c:null,N:40,S:4,O:80};
function gridBuild(){const N=GRD.N,c=new Array(N*N).fill(null),ix=v=>Math.min(N-1,Math.max(0,Math.floor((v+GRD.O)/GRD.S)));
for(let j=0;j<boxes.length;j++){const b=boxes[j],a0=ix(b.x0),a1=ix(b.x1),d0=ix(b.z0),d1=ix(b.z1);for(let a=a0;a<=a1;a++)for(let d=d0;d<=d1;d++){const k=d*N+a;(c[k]||(c[k]=[])).push(b)}}GRD.c=c;GRD.n=boxes.length}
function gIx(v){const N=GRD.N;return Math.min(N-1,Math.max(0,Math.floor((v+GRD.O)/GRD.S)))}
function hitBox(x,z,r,foot){if(GRD.n!==boxes.length)gridBuild();const N=GRD.N,c=GRD.c,ix=gIx,a0=ix(x-r),a1=ix(x+r),d0=ix(z-r),d1=ix(z+r);
for(let d=d0;d<=d1;d++)for(let a=a0;a<=a1;a++){const L=c[d*N+a];if(!L)continue;for(let j=0;j<L.length;j++){const b=L[j];if(!b.pl&&x>b.x0-r&&x<b.x1+r&&z>b.z0-r&&z<b.z1+r&&(foot===undefined||foot<b.h-.45))return b}}return null}
function groundAt(x,z,foot){if(GRD.n!==boxes.length)gridBuild();const N=GRD.N,c=GRD.c,ix=gIx,a0=ix(x-.2),a1=ix(x+.2),d0=ix(z-.2),d1=ix(z+.2);let g=0;
for(let d=d0;d<=d1;d++)for(let a=a0;a<=a1;a++){const L=c[d*N+a];if(!L)continue;for(let j=0;j<L.length;j++){const b=L[j];if(x>b.x0-.2&&x<b.x1+.2&&z>b.z0-.2&&z<b.z1+.2&&b.h<=foot+.5&&b.h>g)g=b.h}}return g}
const LC=[];
let LST=0;
function los(ax,ay,az,bx,by,bz){if(GRD.n!==boxes.length)gridBuild();const dx=bx-ax,dy=by-ay,dz=bz-az,n=Math.max(2,Math.hypot(dx,dz)/.8|0),x0=Math.min(ax,bx),x1=Math.max(ax,bx),z0=Math.min(az,bz),z1=Math.max(az,bz),yn=Math.min(ay,by),N=GRD.N,c=GRD.c,a0=gIx(x0),a1=gIx(x1),d0=gIx(z0),d1=gIx(z1),st=++LST;let m=0;for(let d=d0;d<=d1;d++)for(let a=a0;a<=a1;a++){const L=c[d*N+a];if(!L)continue;for(let j=0;j<L.length;j++){const b=L[j];if(b._s===st)continue;b._s=st;if(!b.see&&b.h>yn&&b.x1>x0&&b.x0<x1&&b.z1>z0&&b.z0<z1)LC[m++]=b}}if(!m)return true;for(let i=1;i<n;i++){const t=i/n,x=ax+dx*t,y=ay+dy*t,z=az+dz*t;for(let j=0;j<m;j++){const b=LC[j];if(y<b.h&&x>b.x0&&x<b.x1&&z>b.z0&&z<b.z1)return false}}return true}
function clearWorld(){try{gfxClr()}catch(e){}GN='conc';GRD.n=-1;if(world){sc.remove(world);world.traverse(o=>{if(o.geometry&&!Object.values(GC).includes(o.geometry))o.geometry.dispose()})}world=new THREE.Group();sc.add(world);boxes.length=solids.length=tgObjs.length=tgs.length=anim.length=emit.length=0;fireL.forEach(l=>sc.remove(l));fireL.length=0;dcP.forEach(d=>d.visible=false);bldP.forEach(d=>d.visible=false);winSpecs.length=0;WIN=null;shP.forEach(m=>m.visible=false);scP.forEach(m=>m.visible=false);smk.length=0}
let GN='conc';
function setGround(n,rep){GN=n;const m=mt(n),t=tx(n);t.m.repeat.set(rep,rep);t.b.repeat.set(rep,rep);const g=new THREE.Mesh(new THREE.PlaneGeometry(420,420),m);g.rotation.x=-PI/2;g.receiveShadow=true;world.add(g)}
function strip(x,z,len,wid,ax,y,mn,uvs,tint){const g=new THREE.PlaneGeometry(wid,len),uv=g.attributes.uv;for(let i=0;i<uv.count;i++)uv.setXY(i,uv.getX(i)*wid/uvs[0],uv.getY(i)*len/uvs[1]);const m=new THREE.Mesh(g,mt(mn));if(ax==='z')m.rotation.set(-PI/2,0,0);else{m.rotation.order='YXZ';m.rotation.set(-PI/2,PI/2,0)}m.position.set(x,y,z);m.receiveShadow=true;world.add(m)}
function road(x,z,len,wid,ax,y,line){strip(x,z,len,wid,ax,y||.03,'asph',[5,5]);if(line)strip(x,z,len,.25,ax,(y||.03)+.012,'dash',[1,6])}
function fenceSeg(x1,z1,x2,z2){const ax=Math.abs(x2-x1)>Math.abs(z2-z1),L=Math.hypot(x2-x1,z2-z1),g=new THREE.PlaneGeometry(L,3),uv=g.attributes.uv;for(let i=0;i<uv.count;i++)uv.setXY(i,uv.getX(i)*L/1.2,uv.getY(i)*3/1.2);const m=mesh(g,mt('fence'),(x1+x2)/2,1.5,(z1+z2)/2,{cs:false});if(!ax)m.rotation.y=PI/2;boxes.push({x0:Math.min(x1,x2)-.15,x1:Math.max(x1,x2)+.15,z0:Math.min(z1,z2)-.15,z1:Math.max(z1,z2)+.15,h:3,see:true});const n=Math.ceil(L/6);for(let i=0;i<=n;i++){const t=i/n;box(lerp(x1,x2,t),lerp(z1,z2,t),.15,3.2,.15,mt('dark'),1,{nc:true})}}
let WNIGHT=false;const winSpecs=[],shP=[];let WIN=null,WGM=null,shI=0;const WW=1.3,WH=1.75;
function mergeG(L){const P=[],N=[],U=[],I=[];let o=0;for(const g of L){const p=g.attributes.position.array,n=g.attributes.normal.array,u=g.attributes.uv.array,ix=g.index.array;for(let i=0;i<p.length;i++){P.push(p[i]);N.push(n[i])}for(let i=0;i<u.length;i++)U.push(u[i]);for(let i=0;i<ix.length;i++)I.push(ix[i]+o);o+=p.length/3}const r=new THREE.BufferGeometry();r.setAttribute('position',new THREE.Float32BufferAttribute(P,3));r.setAttribute('normal',new THREE.Float32BufferAttribute(N,3));r.setAttribute('uv',new THREE.Float32BufferAttribute(U,2));r.setIndex(I);return r}
function frameG(){const L=[],b=(w,h,d,x,y,z)=>{const g=new THREE.BoxGeometry(w,h,d);g.translate(x,y,z);L.push(g)};
b(.14,WH+.28,.16,-WW/2-.07,0,.07);b(.14,WH+.28,.16,WW/2+.07,0,.07);b(WW+.28,.14,.16,0,WH/2+.07,.07);b(WW+.46,.12,.3,0,-WH/2-.06,.13);b(.06,WH,.06,0,0,.04);b(WW,.06,.06,0,.14,.04);return mergeG(L)}
function winMats(){const mk=(w,h,fn)=>{const c=document.createElement('canvas');c.width=w;c.height=h;fn(c.getContext('2d'),w,h);const t=new THREE.CanvasTexture(c);t.encoding=THREE.sRGBEncoding;t.anisotropy=LITE?1:4;return t};
const glass=mk(128,256,(g,w,h)=>{const gr=g.createLinearGradient(0,0,0,h);gr.addColorStop(0,'#b7d3e6');gr.addColorStop(.55,'#6f93ab');gr.addColorStop(1,'#33495a');g.fillStyle=gr;g.fillRect(0,0,w,h);
g.save();g.rotate(-.5);for(const a of[[20,26,.28],[62,8,.35],[88,14,.18]]){g.fillStyle='rgba(255,255,255,'+a[2]+')';g.fillRect(a[0]-40,-80,a[1],420)}g.restore();
for(let i=0;i<260;i++){g.fillStyle='rgba('+(R()<.5?20:230)+','+(R()<.5?25:235)+',230,'+R()*.06+')';g.fillRect(R()*w,R()*h,1+R()*3,1+R()*10)}g.fillStyle='rgba(0,0,0,.14)';g.fillRect(0,h-26,w,26)});
const crack=mk(256,256,(g,w,h)=>{const cx=w/2,cy=h/2;g.lineCap='round';
for(let i=0;i<14;i++){let a=i/14*6.283+R()*.3,x=cx,y=cy,L=40+R()*90,s=0;g.strokeStyle='rgba(240,248,255,.9)';g.lineWidth=1.6;g.beginPath();g.moveTo(x,y);while(s<L){const st=8+R()*12;a+=(R()-.5)*.35;x+=Math.cos(a)*st;y+=Math.sin(a)*st;g.lineTo(x,y);s+=st}g.stroke()}
for(let r=14;r<110;r+=22+R()*14){g.strokeStyle='rgba(230,242,255,.55)';g.lineWidth=1;g.beginPath();for(let k=0;k<=14;k++){const a=k/14*6.283,rr=r*(.85+R()*.3),px=cx+Math.cos(a)*rr,py=cy+Math.sin(a)*rr;k?g.lineTo(px,py):g.moveTo(px,py)}g.stroke()}
const rg=g.createRadialGradient(cx,cy,0,cx,cy,12);rg.addColorStop(0,'rgba(255,255,255,.95)');rg.addColorStop(1,'rgba(255,255,255,0)');g.fillStyle=rg;g.fillRect(cx-14,cy-14,28,28)});
const shard=mk(128,256,(g,w,h)=>{g.fillStyle='rgba(190,215,230,.55)';g.strokeStyle='rgba(255,255,255,.8)';g.lineWidth=1;
const tri=(a,b,c,d,e,f)=>{g.beginPath();g.moveTo(a,b);g.lineTo(c,d);g.lineTo(e,f);g.closePath();g.fill();g.stroke()};
for(let x=0;x<w;x+=10+R()*10){const d=6+R()*34;tri(x,0,x+8+R()*10,0,x+R()*14,d)}for(let x=0;x<w;x+=10+R()*10){const d=4+R()*20;tri(x,h,x+8+R()*10,h,x+R()*10,h-d)}
for(let y=0;y<h;y+=14+R()*16){const d=4+R()*18;tri(0,y,0,y+10+R()*12,d,y+R()*10)}for(let y=0;y<h;y+=14+R()*16){const d=4+R()*18;tri(w,y,w,y+10+R()*12,w-d,y+R()*10)}});
const room=v=>mk(64,128,(g,w,h)=>{const gr=g.createLinearGradient(0,0,0,h);gr.addColorStop(0,'#2a2a2c');gr.addColorStop(.5,'#8a8578');gr.addColorStop(1,'#3b362f');g.fillStyle=gr;g.fillRect(0,0,w,h);
if(v===1){g.fillStyle='#b9ab8c';g.fillRect(0,0,22,h);g.fillRect(w-18,0,18,h);g.fillStyle='rgba(0,0,0,.18)';for(let x=3;x<22;x+=6)g.fillRect(x,0,2,h);for(let x=w-15;x<w;x+=6)g.fillRect(x,0,2,h)}
if(v===2){g.fillStyle='#cfc9bb';g.fillRect(0,0,w,h*.6);g.fillStyle='rgba(0,0,0,.35)';for(let y=2;y<h*.6;y+=5)g.fillRect(0,y,w,2)}
const vg=g.createRadialGradient(w/2,h/2,8,w/2,h/2,h*.75);vg.addColorStop(0,'rgba(0,0,0,0)');vg.addColorStop(1,'rgba(0,0,0,.6)');g.fillStyle=vg;g.fillRect(0,0,w,h)});
const po=f=>({polygonOffset:true,polygonOffsetFactor:f,polygonOffsetUnits:f}),sg=new THREE.BufferGeometry();
sg.setAttribute('position',new THREE.Float32BufferAttribute([0,0,0,.1,0,0,.03,.12,0],3));sg.computeVertexNormals();
WGM={glass:new THREE.MeshBasicMaterial(Object.assign({map:glass,transparent:true,opacity:.62,depthWrite:false},po(-4))),crack:new THREE.MeshBasicMaterial(Object.assign({map:crack,transparent:true,depthWrite:false},po(-6))),shard:new THREE.MeshBasicMaterial(Object.assign({map:shard,transparent:true,depthWrite:false},po(-5))),
int:[0,1,2].map(v=>new THREE.MeshBasicMaterial(Object.assign({map:room(v)},po(-2)))),fr:new THREE.MeshStandardMaterial({color:0xffffff,roughness:.55,metalness:.35}),sh:new THREE.MeshStandardMaterial({color:0xcde4ef,roughness:.1,metalness:.2,transparent:true,opacity:.6,side:THREE.DoubleSide}),sg:sg}}
function buildWindows(){const N=winSpecs.length;if(!N||LITE){WIN=null;return}if(!WGM)winMats();WGM.glass.color.setScalar(WNIGHT?.3:1);
const Z=new THREE.Matrix4().makeTranslation(0,-9999,0),q=new THREE.Quaternion(),ax=new THREE.Vector3(0,1,0),one=new THREE.Vector3(),pos=new THREE.Vector3(),mx=new THREE.Matrix4(),col=new THREE.Color();
const gG=new THREE.PlaneGeometry(WW,WH),gl=new THREE.InstancedMesh(gG,WGM.glass,N),cr=new THREE.InstancedMesh(new THREE.PlaneGeometry(.95,.95),WGM.crack,N),sh=new THREE.InstancedMesh(gG,WGM.shard,N),fr=new THREE.InstancedMesh(frameG(),WGM.fr,N);
const vv=winSpecs.map(()=>{const r=R();return r<.5?0:r<.78?1:2}),cn=[0,0,0];vv.forEach(v=>cn[v]++);const ints=cn.map((c,v)=>c?new THREE.InstancedMesh(gG,WGM.int[v],c):null),ki=[0,0,0];
const pal=[0x2a2d30,0x3a3f42,0xd9d4c8,0x6b3a28,0xe8e6df];const P=[],st=[];
for(let i=0;i<N;i++){const s=winSpecs[i],k=s.s||1,nx=Math.sin(s.ry),nz=Math.cos(s.ry);q.setFromAxisAngle(ax,s.ry);one.set(k,k,k);
mx.compose(pos.set(s.x,s.y,s.z),q,one);fr.setMatrixAt(i,mx);fr.setColorAt(i,col.setHex(pal[R()*5|0]).convertSRGBToLinear());
mx.compose(pos.set(s.x+nx*.04*k,s.y,s.z+nz*.04*k),q,one);gl.setMatrixAt(i,mx);cr.setMatrixAt(i,Z);sh.setMatrixAt(i,Z);
const v=vv[i],kk=ki[v]++;mx.compose(pos.set(s.x+nx*.012*k,s.y,s.z+nz*.012*k),q,one);ints[v].setMatrixAt(kk,mx);
if(WNIGHT&&R()<.38){const b=.8+R()*.2;col.setRGB(b,b*.82,b*.5)}else{const b=.8+R()*.5;col.setRGB(.17*b,.19*b,.22*b)}ints[v].setColorAt(kk,col);
P.push({x:s.x,y:s.y,z:s.z,nx:nx,nz:nz,k:k,ry:s.ry});st.push(0)}
[[gl,2],[cr,3],[sh,2],[fr,0]].forEach(a=>{a[0].frustumCulled=false;a[0].renderOrder=a[1];world.add(a[0])});ints.forEach(m=>{if(m){m.frustumCulled=false;world.add(m)}});
WIN={gl:gl,cr:cr,sh:sh,P:P,st:st,Z:Z};winSpecs.length=0}
function addWins(x,z,w,h,d,y0,k){y0=y0||0;k=k||1;for(let y=y0+2.35;y+WH/2*k+.55<=y0+h;y+=3.6)for(const f of[[0,1,w,x,z+d/2],[0,-1,w,x,z-d/2],[1,0,d,x+w/2,z],[-1,0,d,x-w/2,z]]){const nx=f[0],nz=f[1],len=f[2],n=Math.floor((len-1.6)/3.4);if(n<1)continue;const sp=len/n;
for(let i=0;i<n;i++){const o=(i+.5)*sp-len/2;if(nz===1&&y<3&&!y0&&Math.abs(o)<1.9)continue;winSpecs.push({x:nx?f[3]:f[3]+o,y:y,z:nx?f[4]+o:f[4],ry:Math.atan2(nx,nz),s:k})}}}
function sGlass(x,z){const p=panOf(x,z),v=1/(1+Math.hypot(x-P.x,z-P.z)*.03);nz(.5,9000,2500,.55*v,'highpass',p);nz(.28,6500,1800,.4*v,'bandpass',p);nz(.12,3000,800,.3*v,'lowpass',p);for(let i=0;i<6;i++)setTimeout(()=>tn(2400+R()*2800,1800+R()*1500,.09,.1*v,'triangle',p),i*45+R()*60)}
const SURF={stl:'metal',dark:'metal',cont0:'metal',cont1:'metal',cont2:'metal',hull:'metal',deck:'metal',tankc:'metal',bar0:'metal',bar1:'metal',bar2:'metal',crate:'wood',conc:'conc',brick:'conc',asph:'conc',tile:'conc',gravel:'gravel',dirt:'gravel',sand:'sand',grass:'soft',snow:'soft'};
function surfAt(x,z,foot){if(GRD.n!==boxes.length)gridBuild();const N=GRD.N,L=GRD.c[gIx(z)*N+gIx(x)];let bm=null,bh=0;if(L)for(let j=0;j<L.length;j++){const b=L[j];if(x>b.x0&&x<b.x1&&z>b.z0&&z<b.z1&&b.h<=foot+.5&&b.h>bh){bh=b.h;bm=b.mat}}
if(bh>0){const n=bm&&!Array.isArray(bm)&&bm.userData?bm.userData.sn:null;return SURF[n]||'conc'}return SURF[GN]||'conc'}
function npcStep(a,p0,p1){if(Math.floor(p0/PI)===Math.floor(p1/PI))return;const d=Math.hypot(a.position.x-P.x,a.position.z-P.z);if(d>26)return;stepSnd(.13*(1-d/26)+.012,panOf(a.position.x,a.position.z),surfAt(a.position.x,a.position.z,a.position.y))}
function sTink(x,z){const p=panOf(x,z),v=1/(1+Math.hypot(x-P.x,z-P.z)*.03);nz(.12,8000,3000,.3*v,'highpass',p);tn(3800,3000,.08,.12*v,'triangle',p)}
function spawnShard(x,y,z,vx,vy,vz,k){if(!shP.length)for(let i=0;i<70;i++){const m=new THREE.Mesh(WGM.sg,WGM.sh);m.visible=false;m.userData={v:new THREE.Vector3(),s:new THREE.Vector3(),l:0};sc.add(m);shP.push(m)}
const m=shP[shI=(shI+1)%shP.length],u=m.userData;m.position.set(x,y,z);m.scale.setScalar((.6+R()*1.1)*k);m.rotation.set(R()*6,R()*6,R()*6);u.v.set(vx,vy,vz);u.s.set((R()-.5)*14,(R()-.5)*14,(R()-.5)*14);u.l=6+R()*3;m.visible=true}
function updShards(dt){for(const m of shP){if(!m.visible)continue;const u=m.userData;u.l-=dt;if(u.l<=0){m.visible=false;continue}u.v.y-=9.8*dt;m.position.addScaledVector(u.v,dt);
if(m.position.y<.03){m.position.y=.03;u.v.y*=-.2;u.v.x*=.6;u.v.z*=.6;u.s.multiplyScalar(.5)}m.rotation.x+=u.s.x*dt;m.rotation.y+=u.s.y*dt;m.rotation.z+=u.s.z*dt}}
function winShatter(i){const W=WIN;if(!W||W.st[i]===2)return;W.st[i]=2;const p=W.P[i],q=new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0,1,0),p.ry),mx=new THREE.Matrix4(),k=p.k;
W.gl.setMatrixAt(i,W.Z);W.cr.setMatrixAt(i,W.Z);mx.compose(new THREE.Vector3(p.x+p.nx*.045*k,p.y,p.z+p.nz*.045*k),q,new THREE.Vector3(k,k,k));W.sh.setMatrixAt(i,mx);
W.gl.instanceMatrix.needsUpdate=W.cr.instanceMatrix.needsUpdate=W.sh.instanceMatrix.needsUpdate=true;
const tx=p.nz,tz=-p.nx;for(let j=0;j<16;j++){const a=(R()-.5)*WW*k*.9,b=(R()-.5)*WH*k*.9,l=(R()-.5)*2,o=.3+R()*1.6;spawnShard(p.x+tx*a+p.nx*.05,p.y+b,p.z+tz*a+p.nz*.05,tx*l+p.nx*o,R()*1.5-.3,tz*l+p.nz*o,k)}
for(let j=0;j<8;j++)puff({x:p.x+tx*(R()-.5)*WW*k+p.nx*.1,y:p.y+(R()-.5)*WH*k,z:p.z+tz*(R()-.5)*WW*k+p.nz*.1,vx:(R()-.5)*2+p.nx,vy:R()*2,vz:(R()-.5)*2+p.nz,sz:.12,life:.5,col:0xe8f6ff,add:1,grav:7});
sGlass(p.x,p.z)}
function winHit(h,d){const W=WIN,i=h.instanceId;if(i===undefined||W.st[i]>1)return;const p=W.P[i],k=p.k,imm=d.pel>1||d.dmg>=90,hp=h.point;
for(let j=0;j<4;j++)puff({x:hp.x,y:hp.y,z:hp.z,vx:(R()-.5)*3+p.nx*2,vy:R()*2,vz:(R()-.5)*3+p.nz*2,sz:.1,life:.35,col:0xe8f6ff,add:1,grav:9});
if(W.st[i]===0&&!imm){W.st[i]=1;sTink(p.x,p.z);const tx=p.nz,tz=-p.nx,a=clamp((hp.x-p.x)*tx+(hp.z-p.z)*tz,-(WW/2-.3)*k,(WW/2-.3)*k),b=clamp(hp.y-p.y,-(WH/2-.3)*k,(WH/2-.3)*k),
q=new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0,1,0),p.ry).multiply(new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0,0,1),R()*6.28)),mx=new THREE.Matrix4();
mx.compose(new THREE.Vector3(p.x+tx*a+p.nx*.052*k,p.y+b,p.z+tz*a+p.nz*.052*k),q,new THREE.Vector3(k,k,k));W.cr.setMatrixAt(i,mx);W.cr.instanceMatrix.needsUpdate=true}else winShatter(i)}
function winBlast(x,y,z,r){const W=WIN;if(!W)return;for(let i=0;i<W.P.length;i++){const p=W.P[i];if(W.st[i]<2&&Math.hypot(p.x-x,p.y-y,p.z-z)<r)winShatter(i)}}
function mkWall(){const hs=(a,b)=>{const t=Math.sin(a*12.9898+b*78.233)*43758.5453;return t-Math.floor(t)};
return mkT(512,(u,v,x,y)=>{const n1=fbm(u,v,3,5),n2=fbm(u+.37,v+.11,12,3),bv=((1-v)*2)%1,stK=fbm(u,0,28,2),
drip=(bv<.4?(1-bv/.4):0)*Math.max(0,stK-.38)*2.2+(bv>.9?(bv-.9)*3*Math.max(0,stK-.45):0),pm=Math.min(1,Math.max(0,(fbm(u+.31,v+.17,4,4)-.665)*14)),k=.7+.28*n1+.1*(n2-.5)+R()*.05-.38*drip;
let r=170*k,g=160*k,b=140*k,hh=.5+.25*n2+.15*R();
if(pm>0){const row=Math.floor(y/16),off=(row%2)*16,col=Math.floor((x+off)/32),bx=(x+off)%32,by=y%16,mo=bx<2||by<2,sh=hs(row,col);let br,bg,bb,bh;
if(mo){br=120;bg=116;bb=108;bh=.15}else{const s=.75+sh*.5+R()*.1;br=150*s;bg=70*s;bb=52*s;bh=.7+.2*sh}const so=.55+.6*n2;br*=so;bg*=so;bb*=so;r+=(br-r)*pm;g+=(bg-g)*pm;b+=(bb-b)*pm;hh+=(bh-hh)*pm}
return[r,g,b,hh]},(g,gb,s)=>{for(const yy of[0,256]){g.fillStyle='rgba(0,0,0,.35)';g.fillRect(0,yy,s,3);g.fillStyle='rgba(255,255,255,.12)';g.fillRect(0,yy+3,s,4);gb.fillStyle='#000';gb.fillRect(0,yy,s,3);gb.fillStyle='#fff';gb.fillRect(0,yy+3,s,3)}
for(let i=0;i<3;i++){let x=R()*s,y=R()*s*.8,a=1.2+R()*.6;g.strokeStyle='rgba(25,20,15,.55)';gb.strokeStyle='#000';g.lineWidth=gb.lineWidth=1+R();g.beginPath();gb.beginPath();g.moveTo(x,y);gb.moveTo(x,y);for(let j=0;j<18;j++){a+=(R()-.5)*.8;x+=Math.cos(a)*10;y+=Math.sin(a)*10;g.lineTo(x,y);gb.lineTo(x,y)}g.stroke();gb.stroke()}
for(let i=0;i<3500;i++){g.fillStyle='rgba(0,0,0,'+R()*.12+')';g.fillRect(R()*s,R()*s,1+R()*3,1+R()*3)}})}
function bld(x,z,w,h,d,fac){const nm=(fac==='fac'||fac==='facN')?['fac','facB','facC'][Math.abs((x*7+z*13)|0)%3]:fac,F=mt(nm),Rf=mt('conc'),e=box(x,z,w,h,d,[F,F,Rf,Rf,F,F],[7.2,7.2]);box(x,z+d/2+.05,2.2,2.6,.2,mt('dark'),2,{nc:true});const n=1+(w*d%3|0);for(let i=0;i<n;i++)box(x+(i-n/2)*3.5,z,2,1,2,mt('dark'),2,{y0:h,nc:true});addWins(x,z,w,h,d);return e}
TF.snow=()=>mkT(512,(u,v)=>{const n=fbm(u,v,4,5),f=fbm(u+.2,v+.6,16,3),k=.88+.14*n-.05*f+R()*.025;return[232*k,238*k,248*k,.45+.3*n+.12*f+.08*R()]},(g,gb,s)=>{for(let i=0;i<600;i++){g.fillStyle='rgba(255,255,255,'+(.2+R()*.5)+')';g.fillRect(R()*s,R()*s,1+R()*2,1+R()*2)}for(let i=0;i<30;i++){g.strokeStyle='rgba(150,170,200,.18)';g.lineWidth=2+R()*3;const y=R()*s,x=R()*s;g.beginPath();g.moveTo(x,y);g.quadraticCurveTo(x+60,y+10*R(),x+140,y+(R()-.5)*20);g.stroke()}});
TF.deck=()=>mkT(512,(u,v,x,y)=>{const n=fbm(u,v,8,4),dot=((x*7+y*13)%11<2)?.9:1,k=(.52+.22*n+R()*.05)*dot;return[88*k,98*k,100*k,.4+.15*n+(dot<1?.2:0)]},(g,gb,s)=>{for(let i=0;i<=s;i+=128){g.fillStyle='rgba(0,0,0,.4)';g.fillRect(i,0,2,s);g.fillRect(0,i,s,2);gb.fillStyle='#000';gb.fillRect(i,0,3,s);gb.fillRect(0,i,s,3)}for(let i=0;i<24;i++){g.fillStyle='rgba(90,50,25,'+(.05+R()*.1)+')';g.fillRect(R()*s,R()*s,3+R()*8,10+R()*60)}});
TF.hull=()=>mkT(512,(u,v)=>{const n=fbm(u,v,4,4),k=.62+.25*n+R()*.04;return[138*k,148*k,154*k,.5+.2*n]},(g,gb,s)=>{for(let i=0;i<=s;i+=128){g.fillStyle='rgba(0,0,0,.35)';g.fillRect(i,0,2,s);g.fillRect(0,i,s,2);gb.fillStyle='#000';gb.fillRect(i,0,3,s);gb.fillRect(0,i,s,3);for(let j=8;j<s;j+=16){g.fillStyle='rgba(30,30,30,.5)';g.fillRect(i+4,j,2,2);g.fillRect(j,i+4,2,2)}}for(let i=0;i<30;i++){g.fillStyle='rgba(110,60,30,'+(.05+R()*.1)+')';g.fillRect(R()*s,R()*s*.6,2+R()*5,20+R()*100)}});
TF.sea=()=>mkT(512,(u,v)=>{const n=fbm(u,v,4,5),r=fbm(u+.3,v+.5,8,3),cap=Math.max(0,r-.64)*3.2,c=mix([8,42,76],[30,92,132],n);return[c[0]+cap*210,c[1]+cap*205,c[2]+cap*200,.3*n+.55*r]});
TF.grass=()=>mkT(512,(u,v)=>{const n=fbm(u,v,4,5),f=fbm(u+.5,v+.2,16,3),k=.7+.4*f,c=mix([40,62,30],[84,112,48],n);return[c[0]*k,c[1]*k,c[2]*k,.4*n+.5*f+.1*R()]},(g,gb,s)=>{for(let i=0;i<900;i++){g.fillStyle=R()<.5?'rgba(20,40,14,.35)':'rgba(120,90,50,.25)';g.fillRect(R()*s,R()*s,1+R()*3,1+R()*5)}});
TF.dirt=()=>mkT(512,(u,v)=>{const n=fbm(u,v,4,5),k=.7+.4*n;return[108*k,82*k,56*k,.3+.5*n+.2*R()]});
Object.assign(MF,{snow:()=>M(tx('snow'),{roughness:.9,bumpScale:1.2}),deck:()=>M(tx('deck'),{roughness:.7,metalness:.25,bumpScale:2}),hull:()=>M(tx('hull'),{roughness:.6,metalness:.35,bumpScale:2}),sea:()=>M(tx('sea'),{roughness:.2,metalness:.25,bumpScale:1.5}),grass:()=>M(tx('grass'),{roughness:1}),dirt:()=>M(tx('dirt'),{roughness:1}),stl:()=>S(0x3a4046,.5,.6),bark:()=>S(0x4a3a2a,.95)});
const snowSys=(()=>{const N=LITE?500:1200,g=new THREE.BufferGeometry(),p=new Float32Array(N*3);for(let i=0;i<N;i++){p[i*3]=(R()-.5)*50;p[i*3+1]=R()*26;p[i*3+2]=(R()-.5)*50}g.setAttribute('position',new THREE.BufferAttribute(p,3));const m=new THREE.Points(g,new THREE.PointsMaterial({color:0xffffff,size:.22,transparent:true,opacity:.85,depthWrite:false}));m.frustumCulled=false;m.visible=false;sc.add(m);return m})();
function updSnow(dt){if(!snowSys.visible)return;const a=snowSys.geometry.attributes.position,p=a.array,w=(cur&&cur.wind)||2,cx=cam.position.x,cz=cam.position.z;for(let i=0;i<p.length;i+=3){p[i]+=(w+Math.sin(time*.7+i)*.4)*dt;p[i+1]-=(2.2+(i%7)*.12)*dt;p[i+2]+=.6*dt;if(p[i+1]<0)p[i+1]+=26;p[i]=cx+((p[i]-cx+25)%50+50)%50-25;p[i+2]=cz+((p[i+2]-cz+25)%50+50)%50-25}a.needsUpdate=true}
function mkSea(y){const T=tx('sea');T.m.repeat.set(90,90);T.b.repeat.set(90,90);const s=new THREE.Mesh(new THREE.PlaneGeometry(1400,1400),mt('sea'));s.rotation.x=-PI/2;s.position.y=y;s.receiveShadow=true;world.add(s);anim.push((t,dt)=>{T.m.offset.x+=dt*.003;T.m.offset.y+=dt*.005;T.b.offset.x=T.m.offset.x;T.b.offset.y=T.m.offset.y})}
let RP=[];function rail(x1,z1,x2,z2){const L=Math.hypot(x2-x1,z2-z1),n=Math.ceil(L/5),a=Math.atan2(x2-x1,z2-z1);for(let i=0;i<=n;i++)RP.push([lerp(x1,x2,i/n),lerp(z1,z2,i/n)]);for(const y of[.55,1.1])mesh(Bx(.05,.05,L),mt('stl'),(x1+x2)/2,y,(z1+z2)/2,{cs:false,ry:a});boxes.push({x0:Math.min(x1,x2)-.2,x1:Math.max(x1,x2)+.2,z0:Math.min(z1,z2)-.2,z1:Math.max(z1,z2)+.2,h:3,see:true})}
function flushRails(){if(!RP.length)return;const im=new THREE.InstancedMesh(Bx(.07,1.1,.07),mt('stl'),RP.length),mx=new THREE.Matrix4();RP.forEach((p,i)=>{mx.makeTranslation(p[0],.55,p[1]);im.setMatrixAt(i,mx)});im.frustumCulled=false;world.add(im);RP=[]}
function scatterIn(n,kinds,x0,x1,z0,z1){let p=0,t=0;while(p<n&&t<n*30){t++;const x=x0+R()*(x1-x0),z=z0+R()*(z1-z0);if(!freeAt(x,z,false))continue;prop(kinds[R()*kinds.length|0],x,z);p++}}
function padTex(){const c=document.createElement('canvas');c.width=c.height=256;const g=c.getContext('2d');g.fillStyle='#3d4448';g.beginPath();g.arc(128,128,126,0,7);g.fill();g.strokeStyle='#e8c23a';g.lineWidth=8;g.beginPath();g.arc(128,128,112,0,7);g.stroke();g.fillStyle='#f2f2f2';g.font='bold 150px Arial';g.textAlign='center';g.textBaseline='middle';g.fillText('H',128,136);const t=new THREE.CanvasTexture(c);t.encoding=THREE.sRGBEncoding;return t}
function helipad(x,z,y,r){const m=new THREE.Mesh(new THREE.PlaneGeometry(r*2,r*2),new THREE.MeshStandardMaterial({map:padTex(),transparent:true,roughness:.8}));m.rotation.x=-PI/2;m.position.set(x,y,z);m.receiveShadow=true;world.add(m)}
function heli(x,z){mesh(Bx(2.6,2.2,7),mt('olive'),x,1.7,z);mesh(Bx(.5,.5,5),mt('olive'),x,2.4,z+5.5);boxes.push({x0:x-1.3,x1:x+1.3,z0:z-3.5,z1:z+3.5,h:3});const r=mesh(Bx(8,.05,.35),mt('dark'),x,4,z);anim.push((t,dt)=>{r.rotation.y+=dt*12})}
function forest(pts,kind){if(LITE)pts=pts.filter((p,i)=>i%2===0);const N=pts.length;if(!N)return;const q=new THREE.Quaternion(),ax=new THREE.Vector3(0,1,0),pos=new THREE.Vector3(),sv=new THREE.Vector3(),mx=new THREE.Matrix4(),col=new THREE.Color(),pine=kind==='pine',layers=pine?3:2;
const tr=new THREE.InstancedMesh(new THREE.CylinderGeometry(.28,.4,1,7),mt('bark'),N),lf=new THREE.InstancedMesh(pine?new THREE.ConeGeometry(1,1,8):new THREE.IcosahedronGeometry(1,1),S(0xffffff,.92),N*layers);let k=0;
pts.forEach((p,i)=>{const s=p.s,h=(pine?7:6)*s;q.setFromAxisAngle(ax,R()*6.28);mx.compose(pos.set(p.x,h/2,p.z),q,sv.set(s,h,s));tr.setMatrixAt(i,mx);
for(let l=0;l<layers;l++){if(pine){const w=(3.4-l*.9)*s,hh=(3.6-l*.5)*s;mx.compose(pos.set(p.x,h*.45+l*h*.2+hh/2,p.z),q,sv.set(w,hh,w));if(l===0)col.setRGB(.08,.22,.12);else if(l===1)col.setRGB(.25,.4,.3);else col.setRGB(.8,.86,.9)}
else{const w=(2.7-l*.5)*s;mx.compose(pos.set(p.x+(l?(R()-.5)*1.4:0),h*.8+l*s,p.z+(l?(R()-.5)*1.4:0)),q,sv.set(w,w*.7,w));col.setRGB(.06+R()*.07,.22+R()*.2,.05+R()*.05)}lf.setMatrixAt(k,mx);lf.setColorAt(k,col);k++}
boxes.push({x0:p.x-.45*s,x1:p.x+.45*s,z0:p.z-.45*s,z1:p.z+.45*s,h:h,see:true})});
[tr,lf].forEach(m=>{m.castShadow=true;m.frustumCulled=false;world.add(m)});solids.push(tr)}
function blobs(n,kind){if(LITE)n>>=1;const g=kind==='drift'?new THREE.SphereGeometry(1,10,6):new THREE.IcosahedronGeometry(1,0),im=new THREE.InstancedMesh(g,S(kind==='drift'?0xf2f6ff:0xffffff,.95),n),q=new THREE.Quaternion(),ax=new THREE.Vector3(0,1,0),pos=new THREE.Vector3(),sv=new THREE.Vector3(),mx=new THREE.Matrix4(),col=new THREE.Color();let c=0,t=0;
while(c<n&&t<n*20){t++;const x=(R()-.5)*150,z=(R()-.5)*150;if(hitBox(x,z,3)||wpts.some(w=>Math.hypot(x-w[0],z-w[1])<6))continue;q.setFromAxisAngle(ax,R()*6.28);
if(kind==='drift'){const s=2+R()*4;mx.compose(pos.set(x,-.05,z),q,sv.set(s*1.4,.35+R()*.5,s));col.setRGB(1,1,1)}else{const s=.7+R()*.9;mx.compose(pos.set(x,s*.35,z),q,sv.set(s,s*.7,s));col.setRGB(.06+R()*.08,.2+R()*.2,.05+R()*.05)}im.setMatrixAt(c,mx);im.setColorAt(c,col);c++}
im.count=c;im.frustumCulled=false;im.receiveShadow=true;world.add(im)}
function snow(){setGround('snow',45);road(0,7,140,8,'z',.03,true);road(0,8,130,7,'x',.036);fenceSeg(-76,50,-5,50);fenceSeg(5,76,50,50);box(-8,50,6,4,5,mt('conc'),3);box(8,50,6,4,5,mt('conc'),3);
[[-36,30,28,7,12],[36,30,28,7,12],[40,-18,28,12,22],[-40,-46,26,7,16],[-18,-52,10,6,10],[18,-52,10,6,10]].forEach(b=>{bld(b[0],b[1],b[2],b[3],b[4],'fac');box(b[0],b[1],b[2]+.8,.55,b[4]+.8,mt('snow'),4,{y0:b[3],nc:true})});
[[-70,48],[70,48],[-72,-72],[72,-72],[-70,-30],[70,-30]].forEach(t=>tower(t[0],t[1]));mkTg('radar',0,-56,0,true);
for(const p of[[-7,-44],[7,-44],[0,-50]])box(p[0],p[1],p[0]?1:7,1,p[0]?7:1,mt('bag'),1);
for(let i=0;i<12;i++){const z=70-i*12;box(-6.5,z,.3,7,.3,mt('dark'),1);cyl(6.5,z,.15,7,mt('dark'),{seg:6});mesh(Bx(.8,.25,.5),mt('lamp'),-6.1,7,z,{cs:false})}
scatter(34,['crate','barrel','cont','barrier','bag','rock'],true);for(let i=0;i<3;i++){const x=(R()-.5)*90,z=(R()-.5)*90;if(freeAt(x,z,true))fireProp(x,z,true)}
const pts=[];for(let t=0;t<1500&&pts.length<90;t++){const x=(R()-.5)*154,z=(R()-.5)*154;if(Math.abs(x)<8||Math.abs(z-8)<6)continue;if(Math.abs(x)<56&&z>-60)continue;if(hitBox(x,z,4)||wpts.some(w=>Math.hypot(x-w[0],z-w[1])<8))continue;pts.push({x:x,z:z,s:.8+R()*.7})}
forest(pts,'pine');blobs(36,'drift');
box(0,-80,162,8,2,mt('snow'),6);box(0,112,162,8,2,mt('snow'),6);box(-80,16,2,8,194,mt('snow'),6);box(80,16,2,8,194,mt('snow'),6)}
function ship(){mkSea(-2.6);const D=mt('deck'),H=mt('hull'),hs=mesh(boxGeo(34,6,146,6),[H,H,D,H,H,H],0,-3,7);solids.push(hs);
const sh=new THREE.Shape();sh.moveTo(-17,66);sh.lineTo(17,66);sh.lineTo(0,100);sh.lineTo(-17,66);const bg=new THREE.ExtrudeGeometry(sh,{depth:6,bevelEnabled:false});bg.rotateX(-PI/2);bg.translate(0,-6,0);const uv=bg.attributes.uv;for(let i=0;i<uv.count;i++)uv.setXY(i,uv.getX(i)/6,uv.getY(i)/6);solids.push(mesh(bg,[D,H],0,0,0));
rail(-17,-66,-17,80);rail(17,-66,17,80);rail(-17,80,17,80);rail(-17,-66,17,-66);flushRails();
box(0,-18,22,9,18,H,6);addWins(0,-18,22,9,18);box(0,-22,14,3.4,10,H,6,{y0:9});addWins(0,-22,14,4,10,8.55,.85);box(0,-22,15,.4,11,mt('stl'),3,{y0:12.4,nc:true});
cyl(0,-12.2,2.4,6,mt('stl'),{y0:9,seg:16,nc:true});const mast=cyl(0,-22,.25,10,mt('stl'),{y0:12.8,nc:true}),rb=mesh(Bx(5,.35,.5),mt('stl'),0,23.2,-22,{cs:false});anim.push((t,dt)=>{rb.rotation.y+=dt*1.6});
cyl(0,-52,2.6,1.4,H,{seg:16});mesh(Bx(3.2,1.5,4),H,0,2.15,-52);const gb=mesh(new THREE.CylinderGeometry(.22,.22,5,10),mt('dark'),0,2.2,-56.2);gb.rotation.x=PI/2;
for(let r=0;r<8;r++)for(let c=0;c<2;c++)mesh(Bx(1.5,.06,1.5),mt('dark'),c?1.1:-1.1,.04,-30-r*1.9,{cs:false});
helipad(0,60,.03,7);heli(8,60);
[[-13.5,50],[13.5,42],[-13.5,30],[13.5,22],[-13.5,-34],[13.5,-30]].forEach((p,i)=>box(p[0],p[1],2.5,2.6,6.1,mt('cont'+(i%3)),3));
scatterIn(14,['crate','barrel','bag','barrier'],-14,14,-62,76);}
function rig(){mkSea(-9);const D=mt('deck'),H=mt('hull'),pl=mesh(boxGeo(64,1.6,64,6),[H,H,D,H,H,H],0,-.8,0);solids.push(pl);
for(const a of[-26,26])for(const b of[-26,26])mesh(new THREE.CylinderGeometry(1.5,1.9,9,12),mt('stl'),a,-5.5,b,{cs:false});
for(const a of[-26,26]){mesh(Bx(.5,.5,52),mt('stl'),a,-3.6,0,{cs:false});mesh(Bx(52,.5,.5),mt('stl'),0,-3.6,a,{cs:false})}
rail(-31,-31,-31,31);rail(31,-31,31,31);rail(-31,31,31,31);rail(-31,-31,31,-31);flushRails();
bld(-20,18,16,8,12,'hull');
const dx=0,dz=-18;for(const a of[-2.4,2.4])for(const b of[-2.4,2.4])mesh(Bx(.5,28,.5),mt('stl'),dx+a,14,dz+b);
for(let y=3;y<28;y+=4){mesh(Bx(5.2,.25,.25),mt('stl'),dx,y,dz-2.4,{cs:false});mesh(Bx(5.2,.25,.25),mt('stl'),dx,y,dz+2.4,{cs:false});mesh(Bx(.25,.25,5.2),mt('stl'),dx-2.4,y,dz,{cs:false});mesh(Bx(.25,.25,5.2),mt('stl'),dx+2.4,y,dz,{cs:false})}
mesh(Bx(3,1.2,3),mt('stl'),dx,28.4,dz);boxes.push({x0:dx-2.7,x1:dx+2.7,z0:dz-2.7,z1:dz+2.7,h:30,see:true});
mesh(Bx(14,.5,14),mt('deck'),20,.25,22);helipad(20,22,.52,6);
box(24,-12,3,3,3,mt('stl'),3);const cg=new THREE.Group();cg.position.set(24,3.2,-12);world.add(cg);const arm=mesh(Bx(.6,.6,18),mt('stl'),0,1.2,-6,{p:cg,cs:false});arm.rotation.x=.35;anim.push((t,dt)=>{cg.rotation.y=Math.sin(t*.12)*.8});
cyl(-27,-27,.5,22,mt('stl'),{seg:8});emit.push({x:-27,y:22.5,z:-27,t:1e9,a:0});const fl=new THREE.PointLight(0xff7a2a,3,60,2);fl.position.set(-27,22,-27);sc.add(fl);fl.visible=!!CFG.lights;fireL.push(fl);
[[8,14],[-4,6],[12,-24],[-10,-28],[16,2]].forEach((p,i)=>box(p[0],p[1],2.5,2.6,6.1,mt('cont'+(i%3)),3));
scatterIn(14,['crate','barrel','bag','barrier'],-28,28,-28,28);}
function jungle(){setGround('grass',55);strip(0,7,150,6,'z',.03,'dirt',[4,4]);strip(0,8,140,6,'x',.036,'dirt',[4,4]);
[[-34,26,12,4.2,9],[34,24,10,4.2,8],[40,-18,16,4.5,12],[-40,-40,14,4.2,10],[-18,-52,9,4,8],[18,-54,9,4,8]].forEach(b=>{bld(b[0],b[1],b[2],b[3],b[4],'facC');box(b[0],b[1],b[2]+1.2,.25,b[4]+1.2,mt('stl'),3,{y0:b[3],nc:true})});
tower(-60,40);tower(60,-40);for(const p of[[-14,-22],[14,-22],[0,-26]])box(p[0],p[1],5,2.6,8,mt('tarp'),3);for(const p of[[0,36],[-12,30],[12,30],[0,-46],[-7,-46],[7,-46]])box(p[0],p[1],4,1,.9,mt('bag'),1);
fireProp(-10,-32,true);fireProp(12,-34,true);scatter(22,['crate','barrel','bag','rock'],true);
const pts=[];for(let t=0;t<1500&&pts.length<110;t++){const x=(R()-.5)*150,z=(R()-.5)*150;if(Math.abs(x)<5.5||Math.abs(z-8)<5)continue;if(hitBox(x,z,5)||wpts.some(w=>Math.hypot(x-w[0],z-w[1])<7))continue;pts.push({x:x,z:z,s:.8+R()*.7})}
forest(pts,'jungle');blobs(90,'bush');
box(0,-80,162,8,2,mt('grass'),6);box(0,112,162,8,2,mt('grass'),6);box(-80,16,2,8,194,mt('grass'),6);box(80,16,2,8,194,mt('grass'),6)}
function tower(x,z){for(const f of[[0,1],[0,-1],[1,0],[-1,0]])for(const o of[-.95,.95])winSpecs.push({x:x+f[0]*2+(f[0]?0:o),y:8.1,z:z+f[1]*2+(f[0]?o:0),ry:Math.atan2(f[0],f[1]),s:.55});for(const a of[-1.4,1.4])for(const b of[-1.4,1.4])box(x+a,z+b,.35,7,.35,mt('dark'),1);box(x,z,4,2.2,4,mt('olive'),2,{y0:7,nc:true});box(x,z,4.6,.3,4.6,mt('dark'),2,{y0:9.2,nc:true})}
function rock(x,z,s,mn){const m=new THREE.Mesh(new THREE.DodecahedronGeometry(s,1),mt(mn||'rock'));m.scale.set(1+R()*.4,.7+R()*.5,1+R()*.4);m.position.set(x,s*.5,z);m.rotation.y=R()*6;m.castShadow=m.receiveShadow=true;world.add(m);boxes.push({x0:x-s*.9,x1:x+s*.9,z0:z-s*.9,z1:z+s*.9,h:s*1.1});solids.push(m)}
function wheelG(){const g=new THREE.CylinderGeometry(.5,.5,.35,14);g.rotateZ(PI/2);return g}
function car(x,z,rot){const gp=new THREE.Group();gp.position.set(x,0,z);world.add(gp);const wg=wheelG(),cols=['bar0','bar1','bar2','dark','rub'],bm=mt(cols[R()*5|0]);mesh(Bx(1.9,.7,4.2),bm,0,.7,0,{p:gp});mesh(Bx(1.7,.6,2),mt('dark'),0,1.3,-.2,{p:gp});for(const a of[-.9,.9])for(const b of[-1.4,1.4])mesh(wg,mt('rub'),a,.5,b,{p:gp});const sw=!!rot;boxes.push({x0:x-(sw?2.1:.95),x1:x+(sw?2.1:.95),z0:z-(sw?.95:2.1),z1:z+(sw?.95:2.1),h:1.7});if(sw)gp.rotation.y=PI/2;solids.push(gp)}
function fireProp(x,z,light){cyl(x,z,.38,1,mt('bar'+(R()*3|0)),{seg:10});emit.push({x,y:1.1,z,t:1e9,a:0});if(light&&fireL.length<4){const l=new THREE.PointLight(0xff7a2a,2.2,22,2);l.position.set(x,1.6,z);sc.add(l);l.visible=!!CFG.lights;fireL.push(l)}}
function prop(k,x,z){switch(k){
case'crate':{const n=1+(R()*2|0),s=1.3+R()*.5;for(let i=0;i<n;i++)box(x,z,s,s,s,mt('crate'),s,{y0:i*s});CRT.push({x:x,z:z,y:n*s});break}
case'barrel':cyl(x,z,.38,1,mt('bar'+(R()*3|0)),{seg:10});break;
case'cont':{const sw=R()<.5,w=sw?6.1:2.5,d=sw?2.5:6.1,m=mt('cont'+(R()*3|0));box(x,z,w,2.6,d,m,3);if(R()<.35)box(x,z,w,2.6,d,m,3,{y0:2.6});break}
case'barrier':box(x,z,.7,1.1,3.2,mt('conc'),2);break;
case'bag':box(x,z,4,1,.9,mt('bag'),1);break;
case'rock':rock(x,z,1.2+R()*1.6);break;
case'car':car(x,z,R()<.5);break;
case'fire':fireProp(x,z,false);break}}
function freeAt(x,z,roadX){if(Math.abs(x)>74||Math.abs(z)>74)return false;if(roadX&&Math.abs(x)<7)return false;for(const w of wpts)if(Math.hypot(x-w[0],z-w[1])<7)return false;return!hitBox(x,z,2.5)}
function scatter(n,kinds,roadX){let p=0,t=0;while(p<n&&t<n*30){t++;const x=(R()-.5)*140,z=(R()-.5)*140;if(!freeAt(x,z,roadX))continue;prop(kinds[R()*kinds.length|0],x,z);p++}}
const TG={
fuel:{w:2.9,d:6.6,h:3,hp:140,cy:1.6,x:9,build:g=>{const c=mesh(new THREE.CylinderGeometry(1.4,1.4,6,18),mt('white'),0,1.9,0,{p:g});c.rotation.x=PI/2;const b=mesh(new THREE.CylinderGeometry(1.42,1.42,.6,18),mt('red'),0,1.9,0,{p:g});b.rotation.x=PI/2;for(const z of[-1.8,1.8])mesh(Bx(2.4,.5,.6),mt('dark'),0,.25,z,{p:g})}},
radar:{w:4,d:4,h:5,hp:400,cy:3,x:9,build:g=>{mesh(Bx(3.6,3.2,3.6),mt('conc'),0,1.6,0,{p:g});mesh(new THREE.CylinderGeometry(.4,.4,2,8),mt('dark'),0,4.1,0,{p:g});const dg=new THREE.Group();dg.position.y=5.1;g.add(dg);const d=new THREE.Mesh(new THREE.SphereGeometry(2.6,18,8,0,2*PI,0,.75),new THREE.MeshStandardMaterial({color:0xdddddd,roughness:.5,side:THREE.DoubleSide}));d.rotation.x=-.9;d.castShadow=true;dg.add(d);anim.push((t,dt)=>{dg.rotation.y+=dt*.5})}},
tower:{w:2,d:2,h:24,hp:220,cy:10,x:6,build:g=>{for(let i=0;i<6;i++)mesh(new THREE.CylinderGeometry(.22,.3,4,8),i%2?mt('white'):mt('red'),0,2+i*4,0,{p:g});for(let i=1;i<6;i++)mesh(Bx(2.4,.1,.1),mt('dark'),0,i*4,0,{p:g});const l=mesh(new THREE.SphereGeometry(.3,8,8),mt('lamp'),0,24.3,0,{p:g,cs:false});anim.push(t=>{l.visible=Math.sin(t*4)>0})}},
tank:{w:4.2,d:7,h:2.4,hp:420,cy:1.4,x:6,build:g=>{mesh(Bx(3.4,1,6.4),mt('tankc'),0,.95,0,{p:g});for(const s of[-1.9,1.9])mesh(Bx(.8,1.1,6.8),mt('dark'),s,.55,0,{p:g});mesh(Bx(2.2,.8,2.6),mt('tankc'),0,1.9,.3,{p:g});const b=mesh(new THREE.CylinderGeometry(.12,.12,3.6,8),mt('dark'),0,1.95,-2.2,{p:g});b.rotation.x=PI/2}},
truck:{w:2.9,d:8,h:3.4,hp:220,cy:1.8,x:7,build:g=>{const wg=wheelG();mesh(Bx(2.4,1.8,2.2),mt('olive'),0,1.5,-2.8,{p:g});mesh(Bx(2.6,2.4,4.6),mt('tarp'),0,2.05,1.2,{p:g});mesh(Bx(2.2,.5,7.4),mt('dark'),0,.7,0,{p:g});for(const a of[-1.2,1.2])for(const b of[-3,.5,2.6])mesh(wg,mt('rub'),a,.55,b,{p:g})}}};
TG.aa={w:5,d:5,h:4.2,hp:99999,cy:2.8,x:11,build:g=>{mesh(Bx(4.6,1,4.6),mt('conc'),0,.5,0,{p:g});const t=new THREE.Group();t.position.y=1.5;g.add(t);mesh(Bx(2.4,1.2,2.8),mt('tankc'),0,.6,0,{p:t});for(const q of[-.7,.7]){const b=mesh(new THREE.CylinderGeometry(.13,.15,4.6,8),mt('dark'),q,1.7,-1.4,{p:t});b.rotation.x=-1.05}mesh(Bx(.6,.9,1.6),mt('dark'),0,1.5,.9,{p:t});anim.push((tm,dt)=>{t.rotation.y=Math.sin(tm*.25+g.position.x)*.9})}};
function mkTg(kind,x,z,rot,decor){const T=TG[kind],g=new THREE.Group();g.position.set(x,0,z);g.rotation.y=rot||0;world.add(g);T.build(g);const sw=Math.abs(Math.sin(rot||0))>.5,w=sw?T.d:T.w,d=sw?T.w:T.d,o={kind,x,z,hp:T.hp,g,y:T.cy,dead:false,box:{x0:x-w/2,x1:x+w/2,z0:z-d/2,z1:z+d/2,h:T.h}};boxes.push(o.box);g.traverse(c=>{if(c.isMesh){c.castShadow=true;c.receiveShadow=true;if(!decor)c.userData.tg=o}});if(decor)solids.push(g);else{tgObjs.push(g);tgs.push(o)}return o}
function dmgT(o,a,byP){if(o.dead)return;if(NET.g&&byP){const i=NET.tg.indexOf(o);if(i>=0)nSend({k:'dt',i:i,d:a});return}o.hp-=a;if(o.hp<=0){o.dead=true;GRD.n=-1;world.remove(o.g);let i=boxes.indexOf(o.box);if(i>=0)boxes.splice(i,1);i=tgObjs.indexOf(o.g);if(i>=0)tgObjs.splice(i,1);const T=TG[o.kind];box(o.x,o.z,T.w*.8,T.h*.3,T.d*.8,mt('rub'),3,{nc:true});emit.push({x:o.x,y:1.5,z:o.z,t:30,a:0});explode(o.x,1.2,o.z,T.x,120,byP);if(o.kind==='fuel'||o.kind==='tank'||o.kind==='truck')shake=Math.max(shake,clamp(1-Math.hypot(P.x-o.x,P.z-o.z)/48,0,1)*3.4);if(byP&&NET.gk){NET.gs=(NET.gs||0)+150;nSend({k:'gsc',s:NET.gs,l:'TARGET DESTROYED +150'})}else if(byP){score+=150;pop('TARGET DESTROYED +150')}}}
function compound(v){const night=v!=='day',fac=night?'facN':'fac';setGround('gravel',60);road(0,7,140,8,'z',.03,true);road(0,8,130,7,'x',.036);
fenceSeg(-76,50,-5,50);fenceSeg(5,76,50,50);box(-8,50,6,4,5,mt('conc'),3);box(8,50,6,4,5,mt('conc'),3);
bld(-36,30,28,7,12,fac);bld(36,30,28,7,12,fac);bld(40,-18,28,12,22,fac);bld(-40,-46,26,7,16,fac);bld(-18,-52,10,6,10,fac);bld(18,-52,10,6,10,fac);if(v==='final')bld(0,-34,26,14,14,fac);
[[-70,48],[70,48],[-72,-72],[72,-72],[-70,-30],[70,-30]].forEach(t=>tower(t[0],t[1]));
const fuel=v==='day';for(let i=0;i<3;i++){if(fuel)continue;mkTg('fuel',-52,-8-i*8,0,true)}
const rad=mkTg('radar',0,-56,0,v!=='day');world.userData.radar=v==='day'?rad:null;
for(const p of[[-7,-44],[7,-44],[0,-50]])box(p[0],p[1],p[0]?1:7,1,p[0]?7:1,mt('bag'),1);
for(let i=0;i<12;i++){const z=70-i*12;box(-6.5,z,.3,7,.3,mt('dark'),1);cyl(6.5,z,.15,7,mt('dark'),{seg:6});mesh(Bx(.8,.25,.5),mt('lamp'),-6.1,7,z,{cs:false})}
scatter(40,['crate','barrel','cont','barrier','bag','rock','car'],true);if(night)for(let i=0;i<7;i++){const x=(R()-.5)*100,z=(R()-.5)*100;if(freeAt(x,z,true))fireProp(x,z,i<3)}
box(0,-80,162,8,2,mt('conc'),6);box(0,112,162,8,2,mt('conc'),6);box(-80,16,2,8,194,mt('conc'),6);box(80,16,2,8,194,mt('conc'),6)}
function city(){setGround('conc',40);for(const c of[-45,-15,15,45]){road(c,0,160,10,'z',.03);road(0,c,160,10,'x',.045)}
const heli=[-45,-54];for(const gx of[-60,-30,0,30,60])for(const gz of[-60,-30,0,30,60]){if(gx===0&&(gz===0||gz===-30))continue;const h=9+R()*18;bld(gx+(R()-.5),gz+(R()-.5),16+R()*3,h,16+R()*3,'fac')}
scatter(36,['car','barrel','bag','barrier','crate','fire','fire'],false);
mesh(Bx(2.6,2.2,7),mt('olive'),heli[0],1.7,heli[1]);boxes.push({x0:heli[0]-1.3,x1:heli[0]+1.3,z0:heli[1]-3.5,z1:heli[1]+3.5,h:3});const rt2=mesh(Bx(8,.05,.35),mt('dark'),heli[0],4,heli[1]);anim.push((t,dt)=>{rt2.rotation.y+=dt*12});
if(!fireL.length)for(const p of[[15,20],[-15,-20],[45,-15]]){fireProp(p[0]+3,p[1]+2,true)}
box(0,-80,162,8,2,mt('conc'),6);box(0,112,162,8,2,mt('conc'),6);box(-80,16,2,8,194,mt('conc'),6);box(80,16,2,8,194,mt('conc'),6)}
function desert(){setGround('sand',50);road(0,31,92,6,'z',.03);road(0,-10,156,8,'x',.035);
bld(-30,-30,14,5,10,'fac');bld(30,-30,14,5,10,'fac');bld(0,-62,22,6,12,'fac');
for(const p of[[-14,-22],[14,-22],[0,-26]])box(p[0],p[1],5,2.6,8,mt('tarp'),3);
for(const p of[[0,36],[-12,30],[12,30],[0,-46],[-7,-46],[7,-46]])box(p[0],p[1],4,1,.9,mt('bag'),1);
tower(-40,30);tower(40,30);
for(let i=0;i<22;i++){const a=R()*6.28,r=60+R()*14;rock(Math.cos(a)*r*.9,Math.sin(a)*r*.9,2+R()*3,'rock')}
scatter(26,['rock','cont','crate','barrel','car','bag'],false);
box(0,-80,162,8,2,mt('sand'),6);box(0,112,162,8,2,mt('sand'),6);box(-80,16,2,8,194,mt('sand'),6);box(80,16,2,8,194,mt('sand'),6)}
function tbase(){setGround('sand',50);road(0,44,60,5,'z',.03);
const W=mt('sand'),C=mt('conc');
box(0,-44,70,3,1.2,W,4);box(-35,-14,1.2,3,60,W,4);box(35,-14,1.2,3,60,W,4);box(-20,16,30,3,1.2,W,4);box(20,16,30,3,1.2,W,4);
box(-5,16,1.6,4.2,1.6,C,2);box(5,16,1.6,4.2,1.6,C,2);
for(const p of[[-8,21],[8,21],[-3,23],[3,23]])box(p[0],p[1],4,1,.9,mt('bag'),1);
bld(0,-37,16,5,8,'fac');bld(-23,-30,9,4,7,'fac');bld(23,-30,9,4,7,'fac');bld(-24,-12,8,4,7,'fac');
for(const x of[-10,10])box(x,-14,5,2.6,8,mt('tarp'),3);
for(const p of[[-6,-22],[6,-22],[0,-24]])box(p[0],p[1],4,1,.9,mt('bag'),1);
box(10,-30,.25,9,.25,mt('dark'),1);box(11.2,-30,2.2,1.4,.06,mt('dark'),1,{y0:7.3,nc:true});
prop('crate',-13,-26);prop('barrel',-15,-26);prop('crate',13,-26);prop('barrel',15,-26);
for(let i=0;i<22;i++){const a=R()*6.28,r=60+R()*14;rock(Math.cos(a)*r*.9,Math.sin(a)*r*.9,2+R()*3,'rock')}
scatter(14,['rock','crate','barrel','bag'],false);
box(0,-80,162,8,2,mt('sand'),6);box(0,112,162,8,2,mt('sand'),6);box(-80,16,2,8,194,mt('sand'),6);box(80,16,2,8,194,mt('sand'),6)}
TF.dirt=()=>mkT(512,(u,v)=>{const n=fbm(u,v,4,5),f=fbm(u+.3,v+.6,16,3),k=.78+.4*f+.1*R(),c=mix([92,74,52],[150,122,88],n);return[c[0]*k,c[1]*k,c[2]*k,.4*n+.35*f+.25*R()]},(g,gb,s)=>{for(let i=0;i<420;i++){const x=R()*s,y=R()*s,r=.8+R()*2.4;g.fillStyle='rgba('+(R()<.5?60:170)+','+(R()<.5?48:150)+',100,.3)';g.beginPath();g.arc(x,y,r,0,7);g.fill();gb.fillStyle='rgba(255,255,255,.35)';gb.beginPath();gb.arc(x,y,r,0,7);gb.fill()}});
TF.path=()=>mkT(256,(u,v)=>{const n=fbm(u,v,4,4),f=fbm(u+.2,v+.5,16,3),r=Math.exp(-Math.pow((u-.3)*13,2))+Math.exp(-Math.pow((u-.7)*13,2)),k=(.82+.3*f+.08*R())*(1-.22*r),c=mix([150,124,90],[198,170,126],n);return[c[0]*k,c[1]*k,c[2]*k,.55*n-.3*r+.3*f+.15*R()]});
TF.mud=()=>mkT(512,(u,v)=>{const n=fbm(u,v,4,5),f=fbm(u+.4,v+.2,16,3),k=.74+.34*n+.1*(f-.5)+R()*.06,c=mix([168,128,92],[214,180,136],n);return[c[0]*k,c[1]*k,c[2]*k,.45*n+.3*f+.25*R()]},(g,gb,s)=>{
for(let p=0;p<5;p++){const px=R()*s*.8,py=R()*s*.8,pw=s*(.1+R()*.14),ph=s*(.08+R()*.12),bh=s/36,bw=s/17;g.save();g.beginPath();g.rect(px,py,pw,ph);g.clip();
for(let y=0;y<ph/bh+1;y++)for(let x=-1;x<pw/bw+1;x++){const o=y%2?bw/2:0,q=R();g.fillStyle='rgb('+(120+q*40|0)+','+(62+q*22|0)+','+(44+q*16|0)+')';g.fillRect(px+x*bw+o+1,py+y*bh+1,bw-2,bh-2)}
g.restore();gb.fillStyle='#303030';gb.fillRect(px,py,pw,ph);g.strokeStyle='rgba(60,38,22,.55)';g.lineWidth=2;g.strokeRect(px,py,pw,ph)}
for(let i=0;i<7;i++){let x=R()*s,y=R()*s*.6;g.strokeStyle='rgba(50,32,20,.55)';gb.strokeStyle='#000';g.lineWidth=gb.lineWidth=1+R()*1.2;g.beginPath();gb.beginPath();g.moveTo(x,y);gb.moveTo(x,y);for(let j=0;j<9;j++){x+=(R()-.5)*s*.05;y+=R()*s*.05;g.lineTo(x,y);gb.lineTo(x,y)}g.stroke();gb.stroke()}
for(let i=0;i<16;i++){g.fillStyle='rgba(70,48,30,'+(.04+R()*.07)+')';g.fillRect(R()*s,0,2+R()*6,s*(.2+R()*.6))}
for(let i=0;i<260;i++){g.fillStyle='rgba(224,198,120,.5)';g.fillRect(R()*s,R()*s,1+R()*4,1)}});
TF.tile=()=>mkT(512,(u,v)=>{const row=Math.floor(v*20),lx=(u*16+(row%2?.5:0))%1,ly=(v*20)%1,cv=Math.sin(lx*PI),n=fbm(u,v,8,4),k=(.5+.5*cv)*(.72+.4*n)*(.7+.3*ly)*(.92+R()*.1);return[196*k,92*k,56*k,.2+.65*cv*(.4+.6*ly)]},(g,gb,s)=>{for(let i=0;i<60;i++){g.fillStyle='rgba(60,70,40,'+(.06+R()*.1)+')';g.fillRect(R()*s,R()*s,3+R()*10,2+R()*6)}});
const MC=c=>new THREE.Color(c).convertSRGBToLinear();
Object.assign(MF,{dirt:()=>M(tx('dirt')),path:()=>M(tx('path')),mud:()=>M(tx('mud'),{bumpScale:3}),mudB:()=>M(tx('mud'),{bumpScale:3,color:MC(0xe8b9a0)}),mudC:()=>M(tx('mud'),{bumpScale:3,color:MC(0xc9d4bd)}),mudD:()=>M(tx('mud'),{bumpScale:3,color:MC(0xf2ece0)}),
tile:()=>M(tx('tile'),{roughness:.8,bumpScale:3}),rubble:()=>M(tx('conc'),{color:MC(0x8a8078),bumpScale:4}),plank:()=>M(tx('crate'),{color:MC(0x8c6a4a)}),crop:()=>M(tx('gravel'),{color:MC(0x5f7a34)}),
soot:()=>S(0x0a0806,1,0,{transparent:true,opacity:.6,depthWrite:false,polygonOffset:true,polygonOffsetFactor:-2,polygonOffsetUnits:-2}),char:()=>S(0x1a1613,.95,0),hay:()=>S(0xc9a64a,1,0),
clothR:()=>S(0x9a2a24,.9,0),clothB:()=>S(0x2a5a8a,.9,0),clothY:()=>S(0xd9a82a,.9,0),dome:()=>S(0xe8e2d0,.55,.1),moss:()=>S(0x2f7a5a,.6,.1),leaf:()=>S(0x3d6b2a,.95,0),bark:()=>S(0x4a3a2a,.95,0)});
let vfN=0,vsN=0;
function vfire(fx,fy,fz,lt){if(vfN>=(LITE?3:7))return;vfN++;emit.push({x:fx,y:fy,z:fz,t:1e9,a:0});if(lt&&fireL.length<3){const l=new THREE.PointLight(0xff7a2a,2.2,22,2);l.position.set(fx,fy+.6,fz);sc.add(l);l.visible=!!CFG.lights;fireL.push(l)}}
function vsmoke(sx,sy,sz,k){if(vsN>=(LITE?2:4))return;vsN++;smk.push({x:sx,y:sy,z:sz,t:1e9,max:3,a:0,k:k||1.5,wx:.5,wz:.25,inf:1})}
function house(x,z,w,d,h,mn,roof,f,o){o=o||{};const Wm=mt(mn),Dk=mt('dark'),Pl=mt('plank'),Cn=mt('conc');
const nx=f==='+x'?1:f==='-x'?-1:0,nz=f==='+z'?1:f==='-z'?-1:0,tx=-nz,tz=nx,hf=nx?w/2:d/2,fw=nx?d:w;
const at=(a,n)=>[x+nx*n+tx*a,z+nz*n+tz*a];
const pl=(a,n,wd,hh,t,m,y0)=>{const p=at(a,n);return box(p[0],p[1],nx?t:wd,hh,nx?wd:t,m,2,{y0:y0||0,nc:true})};
const wn=(px,pz,ax)=>{const a=ax==='x';box(px,pz,a?.1:1,1.1,a?1:.1,Dk,1,{y0:1.2,nc:true});box(px,pz,a?.18:1.3,.12,a?1.3:.18,Pl,1,{y0:2.3,nc:true});box(px,pz,a?.18:1.3,.12,a?1.3:.18,Pl,1,{y0:1.1,nc:true});box(px,pz,a?.14:1.3,.08,a?1.3:.14,Pl,1,{y0:.97,nc:true})};
box(x,z,w,h,d,Wm,[4,4]);box(x,z,w+.2,.5,d+.2,Cn,2,{nc:true});
const da=o.da===undefined?-1.2:o.da;
pl(da,hf+.05,1.1,2.2,.12,Pl,0);pl(da,hf+.08,1.5,.2,.2,Dk,2.2);pl(da,hf+.55,1.5,.18,.9,Cn,0);
const wp=at(da+3.1,hf+.05);wn(wp[0],wp[1],nx?'x':'z');
const sw=nx?'z':'x',sp1=at(fw/2+.05,-hf*.3),sp2=at(-fw/2-.05,hf*.3);wn(sp1[0],sp1[1],sw);wn(sp2[0],sp2[1],sw);
if(roof==='gable'){gable(x,z,w,d,h,mn)}else{
const sl=box(x,z,w+.5,.35,d+.5,mt('conc'),3,{y0:h,nc:true});solids.push(sl);
box(x,z-d/2-.2,w+.5,.55,.2,Cn,2,{y0:h+.35,nc:true});box(x,z+d/2+.2,w+.5,.55,.2,Cn,2,{y0:h+.35,nc:true});box(x-w/2-.2,z,.2,.55,d+.5,Cn,2,{y0:h+.35,nc:true});box(x+w/2+.2,z,.2,.55,d+.5,Cn,2,{y0:h+.35,nc:true});
cyl(x+w*.22,z-d*.18,.8,1.1,mt('tankc'),{y0:h+.35,nc:true,seg:10})}
if(o.hole){const p=at(da+2.6,hf+.07);box(p[0],p[1],nx?.1:2.4,1.9,nx?2.4:.1,mt('char'),1,{y0:.7,nc:true});const q=at(da+2.6,hf+.9);rock(q[0],q[1],.5,'rubble');const q2=at(da+3.6,hf+.7);rock(q2[0],q2[1],.35,'rubble')}
if(o.burn){const p=at(da+1.4,hf+.06);box(p[0],p[1],nx?.08:fw*.8,h*.7,nx?fw*.8:.08,mt('soot'),1,{y0:h*.3,nc:true});
const q=at(da+3.1,hf+.07);box(q[0],q[1],nx?.1:1.5,1.7,nx?1.5:.1,mt('soot'),1,{y0:2.1,nc:true});
vfire(x,h+.5,z,true);vsmoke(x,h+1,z,1.6)}}
function gable(x,z,w,d,h,mn){const al=w>=d,L=al?w:d,Wd=al?d:w,rise=1.7,th=Math.atan2(rise,Wd/2),sl=Math.sqrt(Wd*Wd/4+rise*rise)+.4,T=mt('tile');
const sh=new THREE.Shape();sh.moveTo(-Wd/2,0);sh.lineTo(Wd/2,0);sh.lineTo(0,rise);
const g=new THREE.ExtrudeGeometry(sh,{depth:L,bevelEnabled:false}),uv=g.attributes.uv;for(let i=0;i<uv.count;i++)uv.setXY(i,uv.getX(i)*.25,uv.getY(i)*.25);
if(al){g.rotateY(PI/2);g.translate(-L/2,0,0)}else g.translate(0,0,-L/2);
const pm=new THREE.Mesh(g,mt(mn));pm.position.set(x,h,z);pm.castShadow=pm.receiveShadow=true;world.add(pm);solids.push(pm);
for(const s of[-1,1]){const e=mesh(boxGeo(al?L+.7:sl,.16,al?sl:L+.7,[2,2]),T,al?x:x+s*Wd/4,h+rise/2+.1,al?z+s*Wd/4:z);if(al)e.rotation.x=-s*th;else e.rotation.z=s*th;solids.push(e)}
mesh(Bx(al?L+.8:.3,.18,al?.3:L+.8),mt('tile'),x,h+rise+.12,z,{cs:false})}
function ruin(x,z,w,d,mn,lt){const Wm=mt(mn),Ch=mt('char');
const fl=new THREE.Mesh(new THREE.PlaneGeometry(w+3,d+3),mt('soot'));fl.rotation.x=-PI/2;fl.position.set(x,.05,z);world.add(fl);
box(x,z,w,.12,d,Ch,3,{nc:true});
const sd=[[0,-d/2,w,0],[0,d/2,w,0],[-w/2,0,d,1],[w/2,0,d,1]];
sd.forEach((q,i)=>{const L=q[2],n=i<2?1+(R()<.5?1:0):1;for(let j=0;j<n;j++){const sl=L*(.25+R()*.3),off=(R()-.5)*(L-sl),hh=.8+R()*(i===0?2.4:1.5),v=q[3]===1,px=v?x+q[0]:x+off,pz=v?z+off:z+q[1];
box(px,pz,v?.5:sl,hh,v?sl:.5,Wm,[3,3]);box(px+(R()-.5)*.3,pz+(R()-.5)*.3,v?.4:sl*.5,.3+R()*.5,v?sl*.5:.4,Wm,[3,3],{y0:hh,nc:true})}});
const nr=LITE?4:8;for(let i=0;i<nr;i++)rock(x+(R()-.5)*(w-1),z+(R()-.5)*(d-1),.45+R()*.9,'rubble');
const sl=mesh(boxGeo(w*.55,.16,d*.45,[2,2]),mt('tile'),x+w*.1,.9,z-d*.1,{ry:R()*3});sl.rotation.x=.32;sl.rotation.z=.22;solids.push(sl);
for(let i=0;i<3;i++){const b=mesh(Bx(.22,.22,3.5),Ch,x+(R()-.5)*w*.6,.8+R()*.4,z+(R()-.5)*d*.6,{ry:R()*3});b.rotation.x=.2+R()*.3}
vfire(x,.6,z,lt);vsmoke(x,1.4,z,1.4)}
function mosque(x,z){const Wm=mt('mudD'),G=mt('moss'),Dm=mt('dome'),Dk=mt('dark');
box(x,z,11,6.5,8,Wm,[4,4]);box(x,z,11.4,.5,8.4,mt('conc'),2,{nc:true});box(x,z+4.05,11.4,.45,.2,G,2,{y0:5.6,nc:true});
box(x,z+4.04,2.2,3.2,.12,Dk,1,{nc:true});box(x,z+4.07,2.8,.3,.2,G,1,{y0:3.2,nc:true});
for(const a of[-3.6,3.6])box(x+a,z+4.05,1,1.7,.1,Dk,1,{y0:1.7,nc:true});
cyl(x,z,2.6,1.2,Wm,{y0:6.5,nc:true,seg:16});
const dm=new THREE.Mesh(new THREE.SphereGeometry(3,18,10,0,2*PI,0,PI/2),Dm);dm.position.set(x,7.7,z);dm.castShadow=true;world.add(dm);solids.push(dm);
cyl(x,z,.12,2,mt('dark'),{y0:10.5,nc:true,seg:6});
const mx=x+7.5,mz=z-1.5;cyl(mx,mz,1,12,Wm,{seg:12});cyl(mx,mz,1.3,.5,G,{y0:9.5,nc:true,seg:12});cyl(mx,mz,1.2,1.6,Wm,{y0:10,nc:true,seg:12});
const cp=new THREE.Mesh(new THREE.ConeGeometry(1.3,2,12),Dm);cp.position.set(mx,12.8,mz);cp.castShadow=true;world.add(cp);
box(x-5.6,z+1.6,.12,1.6,2.6,mt('soot'),1,{y0:3.2,nc:true});vfire(x-5.4,.7,z+1.5,false);vsmoke(x-5.4,2,z+1.5,1.2)}
function stall(x,z,cm){const Pl=mt('plank'),C=mt(cm);box(x,z,3,.9,1.2,Pl,2);
for(const a of[-1.4,1.4])for(const b of[-.6,.6])box(x+a,z+b,.1,2.3,.1,Pl,1,{nc:true});
const cv=mesh(boxGeo(3.4,.06,1.9,[1,1]),C,x,2.4,z);cv.rotation.x=.12;
for(let i=0;i<4;i++)box(x-1.1+i*.75,z,.55,.4,.5,mt(i%2?'crate':'plank'),1,{y0:.9,nc:true})}
function well(x,z){const Cn=mt('rubble');cyl(x,z,1,.95,Cn,{seg:14});for(const a of[-.9,.9])box(x+a,z,.12,2.2,.12,mt('plank'),1,{nc:true});box(x,z,2.1,.14,.14,mt('plank'),1,{y0:2.1,nc:true});cyl(x,z,.6,.05,mt('dark'),{y0:.96,nc:true,seg:12})}
function hay(x,z){cyl(x,z,1.3,1.7,mt('hay'),{seg:12});const c=mesh(new THREE.SphereGeometry(1.3,12,6,0,2*PI,0,PI/2),mt('hay'),x,1.7,z);c.scale.y=.7}
function lwall(x,z,len,ax){box(x,z,ax==='x'?len:.45,1.1,ax==='x'?.45:len,mt('mud'),[3,3])}
function vtree(x,z){const s=.8+R()*.5;cyl(x,z,.28*s,3*s,mt('bark'),{seg:7});const c=mesh(new THREE.IcosahedronGeometry(2.1*s,1),mt('leaf'),x,3.8*s,z);c.scale.y=.85}
function village(){vfN=vsN=0;setGround('dirt',50);
strip(0,0,162,6,'z',.03,'path',[6,6]);strip(0,26,150,5,'x',.035,'path',[6,6]);strip(-15,10,22,20,'z',.04,'path',[6,6]);
strip(-66,0,150,10,'z',.03,'crop',[5,5]);strip(66,0,150,10,'z',.03,'crop',[5,5]);
const H=[[13,50,8,9,3.6,'mud','flat','-x'],[13,36,8,8,3.4,'mudB','gable','-x'],[13,-16,9,8,3.8,'mudC','flat','-x',{burn:1}],[13,-32,8,9,3.4,'mudD','gable','-x'],[13,-50,9,9,3.6,'mud','flat','-x',{hole:1}],
[32,44,9,8,3.4,'mudB','gable','-z'],[32,-24,9,9,3.6,'mudC','flat','-x',{hole:1}],[32,-60,9,8,3.4,'mud','gable','-x'],
[-13,50,8,9,3.6,'mudB','flat','+x'],[-13,36,8,8,3.4,'mud','gable','+x',{burn:1}],[-13,-38,9,8,3.6,'mudD','flat','+x'],[-13,-54,8,8,3.4,'mudC','gable','+x'],
[-31,44,9,8,3.4,'mud','gable','-z'],[-31,-30,9,9,3.6,'mudB','flat','+x',{hole:1}]];
H.forEach(q=>{if(LITE&&Math.abs(q[1])>56&&Math.abs(q[0])>20)return;house(q[0],q[1],q[2],q[3],q[4],q[5],q[6],q[7],q[8])});
ruin(13,0,9,10,'mud',true);ruin(-13,-21,8,9,'mudB',false);ruin(31,18,9,8,'mudC',false);ruin(-31,-10,9,9,'mud',false);ruin(30,-44,8,9,'mudD',false);
mosque(-28,-62);
stall(-22,17,'clothR');stall(-8,17,'clothB');stall(-15,19,'clothY');well(-9,3);
hay(24,56);hay(27,58.5);hay(-24,56);hay(-22,-2);
lwall(22,60,10,'x');lwall(-22,60,10,'x');lwall(22,28,8,'z');lwall(-22,-40,10,'z');lwall(22,-8,6,'x');
for(const p of[[7,66],[-7,58],[7,20],[-7,-12],[7,-60],[-7,-70],[40,24],[-40,24],[42,-10],[-42,-48]])vtree(p[0],p[1]);
for(let zz=64;zz>=-64;zz-=20){cyl(5.4,zz,.14,7,mt('plank'),{seg:6});box(5.4,zz,.12,.12,1.6,mt('plank'),1,{y0:6.4,nc:true})}
for(const p of[[8,26],[-8,26]]){prop('barrel',p[0]+(R()-.5),p[1]+3)}
prop('crate',6,-8);prop('crate',-6,-12);prop('barrel',-6,-30);prop('barrel',6,12);
const bw=mt('mud');box(0,-80,162,3,1.2,bw,4);box(0,112,162,3,1.2,bw,4);box(-80,16,1.2,3,194,bw,4);box(80,16,1.2,3,194,bw,4);
scatter(LITE?8:16,['crate','barrel','bag'],true)}
function buildWorld(m){CRT.length=0;clearHosts();clearWorld();wpts=[m.start];m.st.forEach(s=>{if(s.x!==undefined)wpts.push([s.x,s.z]);if(s.tg)s.tg.forEach(t=>wpts.push([t.x,t.z]))});
env(m);defenses(m);if(m.b==='city')city();else if(m.b==='desert')desert();else if(m.b==='tbase')tbase();else if(m.b==='snow')snow();else if(m.b==='ship')ship();else if(m.b==='jungle')jungle();else if(m.b==='rig')rig();else if(m.b==='border')border();else if(m.b==='arena')arena();else if(m.b==='village')village();else if(m.b==='mount')mount();else compound(m.b);buildWindows();try{gfxGround(m)}catch(e){0}if(m.b!=='ship'&&m.b!=='rig'&&m.b!=='arena'&&m.b!=='mount'&&!m.uav)strip(m.start[0],91,42,8,'z',.03,(m.b==='jungle'||m.b==='village')?'dirt':'asph',[5,5]);
}
function menuWorld(){CRT.length=0;clearHosts();clearWorld();wpts=[MS[0].start];env(MS[0])}
function env(m){nvForce();uavEnd();WNIGHT=!!m.night;snowSys.visible=!!m.snow;SD=m.sd;drawSky(m.sky);const h=m.sky.hor;sc.fog.color.setRGB(h[0]/255,h[1]/255,h[2]/255).convertSRGBToLinear();fogB=[m.fog[0],m.fog[1]];applyFog();hemi.color.set(m.hemi[0]);hemi.groundColor.set(m.hemi[1]);hemi.intensity=m.hemi[2]*(ULTX?.62:1);sun.color.set(m.sunC);sun.intensity=m.sunI;expB=m.exp;rd.toneMappingExposure=expB*CFG.bright;torch.intensity=m.torch;gH.intensity=m.night?.5:1.1;gD.intensity=m.night?.4:1.6;try{gfxEnv(m)}catch(e){0}}
var GFXG=null,GFXF=[],GFXT=0,GFXM={},GFXB=null,GFXPB=null;
function gfxLin(h){return new THREE.Color(h).convertSRGBToLinear()}
function gfxClr(){if(GFXG){try{GFXG.t.dispose();GFXG.m.dispose()}catch(e){}GFXG=null}}
function gfxBlob(){if(!GFXB)GFXB={g:new THREE.PlaneGeometry(1,1),m:new THREE.MeshBasicMaterial({map:tHole,transparent:true,depthWrite:false,opacity:.62,polygonOffset:true,polygonOffsetFactor:-2,polygonOffsetUnits:-2})};return GFXB}
function gfxFL(sk){const k=sk?'fs':'fl';return GFXM[k]||(GFXM[k]=new THREE.MeshBasicMaterial({color:0xffffff,skinning:!!sk}))}
const GFXTINT=[0x9fe08c,0xffd08a,0xdfe6ee],GFXHEL=[0x2d3a26,0x4a3a28,0x2f3236],GFXVST=[0x5a5238,0x2f3626,0x1c1d1f];
function gfxVar(vi){let V=GFXM['v'+vi];if(V)return V;V={};
V.uni=mt(vi===2?'uniH':'uniE').clone();V.uni.color.multiply(gfxLin(GFXTINT[vi]));
V.hel=S(GFXHEL[vi],.5,.2);V.vest=S(GFXVST[vi],.85);V.skin=null;
try{const T=MDS.tac;if(T&&T.mat){const base=T.mat,c=base.clone(),tint=gfxLin(GFXTINT[vi]);c.skinning=true;c.vertexColors=false;
c.onBeforeCompile=function(sh){base.onBeforeCompile(sh);sh.uniforms.uTint={value:tint};sh.fragmentShader=sh.fragmentShader.replace('uniform sampler2D tB;','uniform vec3 uTint;uniform sampler2D tB;').replace('diffuseColor.rgb*=pow(tc,vec3(2.2));','diffuseColor.rgb*=pow(tc,vec3(2.2));if(vTi<.5||vTi>2.5)diffuseColor.rgb*=uTint;')};
c.customProgramCacheKey=()=>'mdtex1t';c.needsUpdate=true;V.skin=c}}catch(e){0}
return GFXM['v'+vi]=V}
function gfxEnemy(g,kind,ally,cz){if(cz)return;const u=g.userData,B=gfxBlob();
const bs=new THREE.Mesh(B.g,B.m);bs.rotation.x=-PI/2;bs.position.y=.07;bs.scale.set(1.35,1.35,1);bs.raycast=function(){};g.add(bs);u.bs=bs;
const fm=[];
if(!ally){const heavy=kind==='heavy'||kind==='boss',rn=Math.random(),vi=heavy?(rn<.5?2:rn<.8?1:0):(rn<.34?0:rn<.67?1:2),V=gfxVar(vi),base=mt(kind==='rifle'?'uniE':'uniH'),hE=mt('helE'),vE=mt('vest');let helm=null;
g.traverse(o=>{if(!o.isMesh)return;if(o.isSkinnedMesh){if(V.skin){o.material=V.skin;fm.push([o,V.skin,1])}return}
if(o.material===base){o.material=V.uni;fm.push([o,V.uni,0])}else if(o.material===hE){o.material=V.hel;helm=o;fm.push([o,V.hel,0])}else if(o.material===vE){o.material=V.vest;fm.push([o,V.vest,0])}});
const Pt=(geo,mat,x,y,z)=>{const m=new THREE.Mesh(geo,mat);m.position.set(x,y,z);m.castShadow=false;m.raycast=function(){};g.add(m);fm.push([m,mat,0]);return m};
Pt(Bx(.1,.12,.05),V.vest,-.1,1.28,-.18);Pt(Bx(.1,.12,.05),V.vest,.1,1.28,-.18);
if(helm){if(Math.random()<.4){helm.scale.y=.62;helm.position.y-=.025;Pt(Bx(.22,.025,.11),V.hel,0,1.775,-.18)}else Pt(Bx(.29,.035,.3),V.hel,0,1.755,0)}
if(heavy){const dm=GFXM.dot||(GFXM.dot=new THREE.SpriteMaterial({map:tSpr,color:0xff2a1a,transparent:true,blending:THREE.AdditiveBlending,depthWrite:false,fog:false,sizeAttenuation:false}));
const sp=new THREE.Sprite(dm);sp.position.set(0,2.12,0);sp.scale.set(.024,.024,1);sp.raycast=function(){};g.add(sp);u.rd=sp}}
const sm=[];g.traverse(o=>{if(o.isMesh&&o.castShadow)sm.push(o)});u.sm=sm;u.sf=0;u.fm=fm;u.wf=0}
function gfxHit(e){const u=e.userData;if(!u.fm||u.dead)return;if(!(u.wf>0)){for(const q of u.fm)q[0].material=gfxFL(q[2]);GFXF.push(e)}u.wf=.1}
function gfxRestore(e){const u=e.userData;if(u.fm)for(const q of u.fm)q[0].material=q[1];u.wf=0}
function gfxDead(e){const u=e.userData;if(u.rd)u.rd.visible=false;if(u.bs)u.bs.visible=false}
function gfxTick(dt){for(let i=GFXF.length-1;i>=0;i--){const e=GFXF[i],u=e.userData;u.wf-=dt;if(u.wf<=0){gfxRestore(e);GFXF.splice(i,1)}}
try{if(!GFXPB){const B=gfxBlob();GFXPB=new THREE.Mesh(B.g,B.m);GFXPB.rotation.x=-PI/2;GFXPB.scale.set(1.5,1.5,1);GFXPB.raycast=function(){};GFXPB.visible=false;sc.add(GFXPB)}
const on=run&&!inLobby&&!cin&&!UA.on&&!(typeof FL!=='undefined'&&FL&&FL.on);GFXPB.visible=!!on;if(on)GFXPB.position.set(P.x,groundAt(P.x,P.z,P.y-1.7)+.07,P.z);
GFXT-=dt;if(GFXT<=0){GFXT=.5;for(const arr of[enemies,allies])for(const e of arr){const u=e.userData;if(!u||!u.sm)continue;const dx=e.position.x-P.x,dz=e.position.z-P.z,far=dx*dx+dz*dz>3600?1:0;if(far!==u.sf){u.sf=far;for(const o of u.sm)o.castShadow=!far}}}}catch(e){}}
function gfxEnv(m){if(!m||!m.n||!m.fog)return;const b=m.b;hemi.intensity*=.84;sun.intensity*=(b==='desert'?1.13:1.06);
if(b==='city'){sun.color.set(0xff8a40);hemi.color.lerp(new THREE.Color(0xffd0a0),.22)}
if(m.night){const n=Math.max(6,m.fog[0]*.9),f=Math.min(m.fog[1],Math.max(m.fog[1]*.88,80-n));fogB=[n,f];applyFog()}}
function gfxRoads(m){const R_=[],add=(x,z,len,w,ax)=>R_.push(ax==='z'?{x0:x-w/2,x1:x+w/2,z0:z-len/2,z1:z+len/2,ax:ax}:{x0:x-len/2,x1:x+len/2,z0:z-w/2,z1:z+w/2,ax:ax}),b=m.b;
if(b==='city'){for(const c of[-45,-15,15,45]){add(c,0,160,10,'z');add(0,c,160,10,'x')}}
else if(b==='desert'){add(0,31,92,6,'z');add(0,-10,156,8,'x')}
else if(b==='tbase')add(0,44,60,5,'z');
else if(b==='border'){add(0,22,120,8,'z');add(0,-40,150,14,'x')}
else{add(0,7,140,8,'z');add(0,8,130,7,'x')}
if(!m.uav&&m.start)add(m.start[0],91,42,8,'z');return R_}
function gfxGround(m){gfxClr();const b=m.b,kind=b==='city'?'c':(b==='desert'||b==='tbase'||b==='border')?'s':(b==='day'||b==='night'||b==='final'||b==='nbase')?'b':'';if(!kind)return;
const S2=Math.min(TEXMAX,LITE?512:1024),k=S2/200,cv=document.createElement('canvas');cv.width=cv.height=S2;const g=cv.getContext('2d');
const X=x=>(x+100)*k,Z=z=>(z+84)*k,rr=(a,c)=>a+Math.random()*(c-a),rx=()=>rr(-97,97),rz=()=>rr(-81,113),roads=gfxRoads(m);
const onR=(x,z,p)=>{for(const r of roads)if(x>r.x0-p&&x<r.x1+p&&z>r.z0-p&&z<r.z1+p)return true;return false};
const rc=(x0,z0,w,h,col)=>{g.fillStyle=col;g.fillRect(X(x0),Z(z0),w*k,h*k)};
const patch=(x,z,a,c,col,al)=>{g.save();g.translate(X(x),Z(z));g.scale(a*k,c*k);const gr=g.createRadialGradient(0,0,0,0,0,1);gr.addColorStop(0,'rgba('+col+','+al+')');gr.addColorStop(.6,'rgba('+col+','+(al*.65)+')');gr.addColorStop(1,'rgba('+col+',0)');g.fillStyle=gr;g.beginPath();g.arc(0,0,1,0,6.2832);g.fill();g.restore()};
const ell=(x,z,a,c,rot,col)=>{g.fillStyle=col;g.beginPath();g.ellipse(X(x),Z(z),a,c,rot,0,6.2832);g.fill()};
if(kind==='c'){
for(let i=0;i<110;i++)patch(rx(),rz(),rr(3,9),rr(3,9),'45,45,42',rr(.05,.11));
const cs=[-45,-15,15,45],fr=(()=>{let iv=[[-80,80]];for(const c of cs){const a=c-5.3,e=c+5.3,nx=[];for(const q of iv){if(e<=q[0]||a>=q[1]){nx.push(q);continue}if(a>q[0])nx.push([q[0],a]);if(e<q[1])nx.push([e,q[1]])}iv=nx}return iv})();
for(const r of roads)for(let i=0,n=((r.x1-r.x0)*(r.z1-r.z0)/38)|0;i<n;i++)patch(rr(r.x0+1,r.x1-1),rr(r.z0+1,r.z1-1),rr(1.2,4),rr(1,3),'10,10,12',rr(.14,.3));
for(const c0 of cs)for(const q of fr){const l=q[1]-q[0];
for(const sd of[-1,1]){const o1=sd>0?c0+5:c0-7.4,o2=sd>0?c0+4.95:c0-5.35,o3=sd>0?c0+4.5:c0-4.8;
rc(o1,q[0],2.4,l,'rgba(184,182,174,.38)');rc(o2,q[0],.4,l,'rgba(214,212,204,.75)');rc(o3,q[0],.3,l,'rgba(15,15,17,.32)');
rc(q[0],o1,l,2.4,'rgba(184,182,174,.38)');rc(q[0],o2,l,.4,'rgba(214,212,204,.75)');rc(q[0],o3,l,.3,'rgba(15,15,17,.32)')}
for(let t=q[0]+1;t<q[1]-2.6;t+=6){rc(c0-.11,t,.22,2.6,'rgba(236,206,92,.9)');rc(t,c0-.11,2.6,.22,'rgba(236,206,92,.9)')}}
for(const a of cs)for(const c of cs)for(const sd of[-1,1])for(let j=-3;j<=3;j++){rc(a+j*1.3-.3,c+sd*6.4-1.2,.6,2.4,'rgba(235,235,228,.8)');rc(a+sd*6.4-1.2,c+j*1.3-.3,2.4,.6,'rgba(235,235,228,.8)')}
}else if(kind==='s'){
for(let i=0;i<70;i++){const x=rx(),z=rz();if(onR(x,z,3))continue;patch(x,z,rr(4,15),rr(3,9),'112,86,52',rr(.16,.3))}
for(let i=0;i<45;i++){const x=rx(),z=rz();if(onR(x,z,3))continue;patch(x,z,rr(4,13),rr(3,8),'238,214,160',rr(.12,.22))}
g.lineCap='round';
for(let i=0;i<380;i++){const x=rx(),z=rz();if(onR(x,z,1.5))continue;const L=rr(5,16),am=rr(.25,.6),wl=rr(2,3.4),an=rr(-.35,.35);
for(const q of[[0,'rgba(104,78,46,.34)',.18],[.32,'rgba(252,236,190,.3)',.14]]){g.strokeStyle=q[1];g.lineWidth=Math.max(1,q[2]*k);g.beginPath();
for(let s=0;s<=10;s++){const t=s/10*L,w=Math.sin(t/wl*6.28)*am+q[0],px=x+Math.cos(an)*t-Math.sin(an)*w,pz=z+Math.sin(an)*t+Math.cos(an)*w;if(s)g.lineTo(X(px),Z(pz));else g.moveTo(X(px),Z(pz))}g.stroke()}}
for(let i=0;i<190;i++){const x=rx(),z=rz();if(onR(x,z,2))continue;const n=Math.random()<.35?(2+Math.random()*3|0):1;
for(let j=0;j<n;j++){const px=x+rr(-1,1),pz=z+rr(-1,1),r=Math.max(1.3,rr(.14,.5)*k);if(onR(px,pz,1))continue;const v=rr(100,150)|0;
ell(px+r*.5/k,pz+r*.45/k,r*1.1,r*.7,0,'rgba(50,38,26,.5)');ell(px,pz,r,r*.72,rr(0,3),'rgb('+v+','+(v*.92|0)+','+(v*.8|0)+')');ell(px-r*.25/k,pz-r*.2/k,r*.5,r*.3,0,'rgba(255,240,205,.35)')}}
for(const r of roads){const dc='rgba(206,178,126,.4)';if(r.ax==='z'){rc(r.x0-.6,r.z0,.6,r.z1-r.z0,dc);rc(r.x1,r.z0,.6,r.z1-r.z0,dc)}else{rc(r.x0,r.z0-.6,r.x1-r.x0,.6,dc);rc(r.x0,r.z1,r.x1-r.x0,.6,dc)}}
}else{
for(let i=0;i<70;i++){const x=rx(),z=rz();if(onR(x,z,2))continue;patch(x,z,rr(3,10),rr(3,8),'50,40,28',rr(.1,.2))}
for(let i=0,t=0;i<16&&t<90;t++){const cx=rr(-85,85),cz=rr(-65,100);if(onR(cx,cz,7))continue;i++;
for(let j=0;j<26;j++){const a=rr(0,6.28),d=rr(0,5.5),px=cx+Math.cos(a)*d,pz=cz+Math.sin(a)*d*.8;if(onR(px,pz,.5))continue;patch(px,pz,rr(1.3,3.2),rr(1.1,2.6),(rr(58,84)|0)+','+(rr(86,116)|0)+','+(rr(40,60)|0),rr(.45,.7))}
g.strokeStyle='rgba(125,155,72,.5)';g.lineWidth=Math.max(1,.07*k);for(let j=0;j<60;j++){const a=rr(0,6.28),d=rr(0,6),px=cx+Math.cos(a)*d,pz=cz+Math.sin(a)*d*.8;if(onR(px,pz,.5))continue;g.beginPath();g.moveTo(X(px),Z(pz));g.lineTo(X(px+rr(-.15,.15)),Z(pz-rr(.15,.4)));g.stroke()}}
for(let i=0,t=0;i<13&&t<120;t++){const w=rr(6,16),h=rr(5,12),x=rr(-80,80),z=rr(-60,95);if([[x,z],[x+w,z],[x,z+h],[x+w,z+h],[x+w/2,z+h/2]].some(p=>onR(p[0],p[1],1)))continue;i++;
rc(x,z,w,h,'rgba(148,146,138,.8)');for(let j=0;j<70;j++)rc(x+rr(0,w),z+rr(0,h),.12,.12,Math.random()<.5?'rgba(60,58,54,.35)':'rgba(205,203,196,.3)');
g.strokeStyle='rgba(58,56,52,.45)';g.lineWidth=Math.max(1,.1*k);for(let jx=3.2;jx<w;jx+=3.2){g.beginPath();g.moveTo(X(x+jx),Z(z));g.lineTo(X(x+jx),Z(z+h));g.stroke()}for(let jz=3.2;jz<h;jz+=3.2){g.beginPath();g.moveTo(X(x),Z(z+jz));g.lineTo(X(x+w),Z(z+jz));g.stroke()}
g.strokeStyle='rgba(52,50,46,.7)';g.lineWidth=Math.max(1,.22*k);g.strokeRect(X(x),Z(z),w*k,h*k)}
g.lineCap='round';g.lineJoin='round';
for(let i=0;i<7;i++){let x=rr(-70,70),z=rr(-55,85),h=rr(0,6.28);const pts=[[x,z]];for(let s=0;s<6;s++){h+=rr(-.7,.7);x+=Math.cos(h)*rr(8,15);z+=Math.sin(h)*rr(8,15);if(onR(x,z,1.5)||Math.abs(x)>85)break;pts.push([x,z])}if(pts.length<3)continue;
for(const q of[[rr(2.2,3.2),'rgba(78,60,38,.32)'],[rr(1.4,2.2),'rgba(112,88,58,.72)'],[.5,'rgba(140,114,80,.35)']]){g.strokeStyle=q[1];g.lineWidth=q[0]*k;g.beginPath();pts.forEach((p,j)=>j?g.lineTo(X(p[0]),Z(p[1])):g.moveTo(X(p[0]),Z(p[1])));g.stroke()}}
}
const t=new THREE.CanvasTexture(cv);t.encoding=THREE.sRGBEncoding;t.anisotropy=Math.min(4,rd.capabilities.getMaxAnisotropy());
const mat=new THREE.MeshStandardMaterial({map:t,transparent:true,roughness:1,metalness:0,depthWrite:false,polygonOffset:true,polygonOffsetFactor:-2,polygonOffsetUnits:-2});
const mesh=new THREE.Mesh(new THREE.PlaneGeometry(200,200),mat);mesh.rotation.x=-PI/2;mesh.position.set(0,.05,16);mesh.receiveShadow=true;mesh.renderOrder=-1;mesh.raycast=function(){};world.add(mesh);GFXG={t:t,m:mat}}
const EW={ak:{dm:1,i:.11,b:[2,5],pz:1},m4:{dm:1,i:.11,b:[2,5],pz:1},smg:{dm:.72,i:.07,b:[3,7],pz:.8},sg:{dm:2.1,i:.5,b:[1,2],pz:.7,sg:1},lmg:{dm:.9,i:.085,b:[4,8],pz:1},dmr:{dm:1.3,i:.2,b:[3,5],pz:.9},pi:{dm:.8,i:.22,b:[1,3],pz:.8}};
function poseGun(u,pt,dt,rc){const ap=u.ap||0;u.kk=(u.kk||0)*Math.pow(.001,dt);const rk=rc?u.kk*ap:0;u.rg.rotation.x=lerp(-.5,pt,ap)+rk*.05;u.rg.rotation.z=0;u.rg.position.set(.06,lerp(1.18,1.4,ap),lerp(-.3,-.38,ap)+u.kk*.05);
u.arms[0].rotation.x=lerp(.8,1.25,ap)+pt*.5+rk*.04;u.arms[1].rotation.x=lerp(.95,1.4,ap)+pt*.5+rk*.03}
function rlPose(u,ph){ph=Math.min(1,Math.max(0,ph));const k=Math.sin(ph*PI),d=Math.abs(Math.sin(ph*2*PI));u.rg.rotation.x=.22+.1*k;u.rg.rotation.z=-.28*k;u.rg.position.set(0,1.28,-.3);u.arms[0].rotation.x=ph>.9?1.05+.35*Math.sin((ph-.9)*10*PI):1.05;u.arms[1].rotation.x=1.45-.8*d}
const FVAR={
a0:{k:'skin',sk:[196,152,118],hr:[38,28,20],st:1,eye:[84,58,34],ears:1},
a1:{k:'skin',sk:[168,120,88],hr:[22,18,16],bd:1,st:1,eye:[52,36,24],ears:1},
a2:{k:'skin',sk:[226,184,152],hr:[118,84,48],eye:[78,116,146],ears:1},
a3:{k:'skin',sk:[128,90,64],hr:[16,14,13],bd:1,st:1,eye:[40,30,22],ears:1,scar:1},
e0:{k:'bal',sk:[176,132,100],fab:[24,25,23],eye:[60,42,28]},
e1:{k:'bal',sk:[150,108,80],fab:[46,50,38],eye:[40,30,22]},
e2:{k:'scarf',sk:[170,126,94],hr:[20,18,16],st:1,eye:[48,34,22],ears:1},
e3:{k:'skin',sk:[160,116,86],hr:[18,16,14],bd:1,st:1,eye:[44,32,22],ears:1,scar:1},
e4:{k:'gog',sk:[190,146,112],hr:[34,26,20],st:1,eye:[70,50,30],ears:1},
e5:{k:'mask',sk:[172,128,96],hr:[24,20,18],eye:[56,40,26],ears:1},
e6:{k:'skull',sk:[168,124,92],fab:[18,18,18],eye:[150,36,28]}};
function paintFace(V){
const c=document.createElement('canvas');c.width=128;c.height=64;const g=c.getContext('2d'),T=6.3,rnd=Math.random;
const cl=v=>v<0?0:v>255?255:v|0,rgb=(a,k)=>{k=k||1;return'rgb('+cl(a[0]*k)+','+cl(a[1]*k)+','+cl(a[2]*k)+')'};
const sk=V.sk,hr=V.hr||[30,24,20],fab=V.fab||[24,24,22],bal=V.k==='bal'||V.k==='skull';
const spk=(x,y,w,h,n,col)=>{g.fillStyle=col;for(let i=0;i<n;i++)g.fillRect((x+rnd()*w)|0,(y+rnd()*h)|0,1,1)};
const el=(x,y,rx,ry,col)=>{g.fillStyle=col;g.beginPath();g.ellipse(x,y,rx,ry,0,0,T);g.fill()};
const fabric=(x,y,w,h)=>{g.fillStyle=rgb(fab);g.fillRect(x,y,w,h);spk(x,y,w,h,w*h/3,'rgba(255,255,255,.07)');spk(x,y,w,h,w*h/3,'rgba(0,0,0,.2)');g.fillStyle='rgba(0,0,0,.13)';for(let i=0;i<h;i+=2)g.fillRect(x,y+i,w,1)};
if(bal)fabric(64,0,64,64);else{g.fillStyle=rgb(sk,.96);g.fillRect(64,0,64,64);spk(64,0,64,64,260,'rgba(60,30,20,.10)');g.fillStyle=rgb(hr);g.fillRect(64,0,64,22);spk(64,0,64,22,200,'rgba(255,255,255,.06)');
if(V.k==='scarf'){g.fillStyle='rgb(166,148,108)';g.fillRect(64,40,64,24)}if(V.bd){g.fillStyle=rgb(hr);g.fillRect(64,38,64,26)}}
g.fillStyle=bal?rgb(fab):V.k==='mask'?'rgb(84,88,84)':V.k==='scarf'?'rgb(166,148,108)':rgb(sk,1.05);g.fillRect(124,60,4,4);g.fillStyle=rgb(sk,.9);g.fillRect(124,56,4,4);
const skinBase=()=>{g.fillStyle=rgb(sk);g.fillRect(0,0,64,64);const gr=g.createRadialGradient(32,32,6,32,34,42);gr.addColorStop(0,'rgba(255,225,190,.10)');gr.addColorStop(1,'rgba(40,10,0,.30)');g.fillStyle=gr;g.fillRect(0,0,64,64);spk(0,0,64,64,420,'rgba(70,35,25,.10)');spk(0,0,64,64,200,'rgba(255,230,200,.08)')};
const hairline=()=>{g.fillStyle=rgb(hr);g.fillRect(0,0,64,9);for(let x=0;x<64;x+=3)g.fillRect(x,9,3,(rnd()*4)|0)};
const eye=(cx,cy)=>{el(cx,cy,7.5,4.8,'rgba(60,30,20,.22)');el(cx,cy,5.2,2.7,'#ebe5db');el(cx,cy+.1,2.5,2.5,rgb(V.eye));el(cx,cy+.1,1.25,1.25,'#070707');g.fillStyle='rgba(255,255,255,.9)';g.fillRect(cx-1.4,cy-1.3,1,1);g.strokeStyle='rgba(25,12,8,.85)';g.lineWidth=1;g.beginPath();g.ellipse(cx,cy,5.4,2.9,0,3.3,6.1);g.stroke();g.strokeStyle='rgba(90,50,40,.35)';g.beginPath();g.ellipse(cx,cy,5.2,2.9,0,.2,2.9);g.stroke()};
const brow=(x0,y0,xm,ym,x1,y1)=>{g.strokeStyle=rgb(hr,1.1);g.lineWidth=2.4;g.lineCap='round';g.beginPath();g.moveTo(x0,y0);g.quadraticCurveTo(xm,ym,x1,y1);g.stroke()};
const eyes=()=>{eye(20,30);eye(44,30);brow(12,26,20,22.5,28,25);brow(36,25,44,22.5,52,26)};
const nose=()=>{g.fillStyle='rgba(255,236,210,.16)';g.fillRect(30,28,3,13);g.fillStyle='rgba(50,20,10,.16)';g.fillRect(35,32,4,10);el(28.5,42,2.2,1.2,'rgba(30,10,5,.55)');el(35.5,42,2.2,1.2,'rgba(30,10,5,.55)')};
const mouth=()=>{g.fillStyle='rgba(60,25,18,.3)';g.fillRect(21,46,22,1);el(32,49.5,7.5,1.3,'#6e342b');el(32,52,6.5,1.9,'#9b5547');g.fillStyle='#2a0f0a';g.fillRect(25,50,14,1);g.fillStyle='rgba(40,15,10,.35)';g.fillRect(23,50,2,1);g.fillRect(39,50,2,1)};
const jaw=()=>{g.fillStyle='rgba(30,10,0,.22)';g.fillRect(0,58,64,6);g.fillStyle='rgba(30,10,0,.14)';g.fillRect(0,0,5,64);g.fillRect(59,0,5,64)};
const stub=()=>{spk(8,40,48,22,650,'rgba(18,14,10,.30)');spk(22,44,20,5,120,'rgba(18,14,10,.4)')};
const beard=()=>{g.fillStyle=rgb(hr,.95);g.beginPath();g.moveTo(3,34);g.lineTo(13,38);g.lineTo(21,44);g.lineTo(43,44);g.lineTo(51,38);g.lineTo(61,34);g.lineTo(61,64);g.lineTo(3,64);g.closePath();g.fill();spk(3,34,58,30,500,'rgba(255,255,255,.07)');spk(3,34,58,30,400,'rgba(0,0,0,.25)');g.fillStyle=rgb(hr);g.fillRect(21,44,22,4)};
const scar=()=>{g.strokeStyle='rgba(196,112,98,.85)';g.lineWidth=1.3;g.beginPath();g.moveTo(47,33);g.lineTo(53,48);g.stroke();g.lineWidth=1;for(let i=0;i<4;i++){const y=37+i*3.2,x=48.4+i*1.5;g.beginPath();g.moveTo(x-1.8,y);g.lineTo(x+1.8,y+.6);g.stroke()}};
const scarf=()=>{g.fillStyle='rgb(168,150,108)';g.beginPath();g.moveTo(0,40);g.lineTo(16,36);g.lineTo(32,38.5);g.lineTo(48,36);g.lineTo(64,40);g.lineTo(64,64);g.lineTo(0,64);g.closePath();g.fill();g.strokeStyle='rgba(96,72,40,.38)';g.lineWidth=1;for(let i=-64;i<64;i+=5){g.beginPath();g.moveTo(i,36);g.lineTo(i+30,66);g.stroke();g.beginPath();g.moveTo(i+64,36);g.lineTo(i+34,66);g.stroke()}g.fillStyle='rgba(60,40,15,.3)';g.fillRect(0,50,64,2);g.fillRect(0,58,64,6);g.fillStyle='rgba(0,0,0,.28)';g.fillRect(0,38,64,2);spk(0,36,64,28,300,'rgba(255,255,255,.06)')};
const gog=()=>{g.fillStyle='#1b1d1f';g.fillRect(0,26,64,7);g.fillRect(29,27,6,4);for(const x of[7,35]){g.fillStyle='#0c0e10';g.fillRect(x,22,22,14);const gr=g.createLinearGradient(x,22,x+22,36);gr.addColorStop(0,'#2d4a5a');gr.addColorStop(.55,'#101a22');gr.addColorStop(1,'#07090b');g.fillStyle=gr;g.fillRect(x+1.5,23.5,19,11);g.fillStyle='rgba(190,225,245,.35)';g.beginPath();g.moveTo(x+4,34);g.lineTo(x+9,24);g.lineTo(x+12,24);g.lineTo(x+7,34);g.closePath();g.fill()}};
const mask=()=>{g.fillStyle='rgb(78,82,78)';g.beginPath();g.moveTo(5,38);g.lineTo(32,34);g.lineTo(59,38);g.lineTo(61,51);g.lineTo(49,63);g.lineTo(15,63);g.lineTo(3,51);g.closePath();g.fill();spk(3,34,58,30,300,'rgba(255,255,255,.07)');g.strokeStyle='#202220';g.lineWidth=2;g.stroke();for(const x of[13,51]){el(x,50,7,7,'#2b2e2b');el(x,50,4.5,4.5,'#4a4e4a');el(x,50,1.8,1.8,'#151715')}g.fillStyle='#181a18';for(let x=26;x<=38;x+=3)g.fillRect(x,45,1.5,12);g.fillStyle='rgba(0,0,0,.35)';g.fillRect(0,0,0,0);g.strokeStyle='#1c1d1c';g.lineWidth=2;g.beginPath();g.moveTo(0,40);g.lineTo(5,39);g.moveTo(64,40);g.lineTo(59,39);g.stroke()};
if(bal){fabric(0,0,64,64);g.fillStyle='rgba(255,255,255,.05)';el(32,46,17,12,'rgba(255,255,255,.04)');
g.fillStyle=rgb(sk);g.fillRect(9,22,46,14);const gr=g.createLinearGradient(0,22,0,36);gr.addColorStop(0,'rgba(20,5,0,.5)');gr.addColorStop(.3,'rgba(0,0,0,0)');gr.addColorStop(.75,'rgba(0,0,0,0)');gr.addColorStop(1,'rgba(20,5,0,.45)');g.fillStyle=gr;g.fillRect(9,22,46,14);spk(9,22,46,14,120,'rgba(70,35,25,.12)');
g.save();g.beginPath();g.rect(9,22,46,14);g.clip();eye(20,30);eye(44,30);brow(12,26,20,22.2,28,24.5);brow(36,24.5,44,22.2,52,26);g.restore();g.fillStyle='rgba(0,0,0,.4)';g.fillRect(9,22,46,1);g.fillRect(9,35,46,1);g.fillStyle='rgba(0,0,0,.25)';g.fillRect(0,0,5,64);g.fillRect(59,0,5,64);g.fillRect(0,59,64,5);
if(V.k==='skull'){g.fillStyle='#d8d4c8';g.beginPath();g.moveTo(14,39);g.lineTo(50,39);g.lineTo(53,52);g.lineTo(45,63);g.lineTo(19,63);g.lineTo(11,52);g.closePath();g.fill();spk(11,39,42,24,160,'rgba(0,0,0,.12)');g.fillStyle='#17110f';g.beginPath();g.moveTo(32,42);g.lineTo(28.5,48);g.lineTo(35.5,48);g.closePath();g.fill();g.fillRect(17,53,30,1.2);for(let x=20;x<=44;x+=3.4)g.fillRect(x,53,1,9);g.fillRect(17,53,1.5,2);}}
else{skinBase();hairline();if(V.st)stub();if(V.bd)beard();if(V.pt==='full')PNT.full(g,el,spk,rnd);if(V.k!=='gog')eyes();nose();if(V.k==='skin'||V.k==='gog')mouth();if(V.pt&&V.pt!=='full'&&PNT[V.pt])PNT[V.pt](g,el,spk,rnd);if(V.sh)PNT.shades(g);if(V.k==='scarf'){if(V.st)spk(10,30,44,8,80,'rgba(18,14,10,.3)');scarf()}if(V.k==='gog')gog();if(V.k==='mask')mask();jaw();if(V.scar)scar()}
return c}
const FCM={},HGC={};
function faceMat(k){return FCM[k]||(FCM[k]=(()=>{const t=new THREE.CanvasTexture(paintFace(FVAR[k]));t.encoding=THREE.sRGBEncoding;t.anisotropy=LITE?1:4;return new THREE.MeshStandardMaterial({map:t,roughness:.86,metalness:0})})())}
function headGeo(ears){const k=ears?1:0;if(HGC[k])return HGC[k];
const L=[],b=new THREE.BoxGeometry(.19,.22,.2),uv=b.attributes.uv;
for(let f=0;f<6;f++)for(let i=0;i<4;i++){const q=f*4+i,u=uv.getX(q),v=uv.getY(q);if(f===5)uv.setXY(q,u*.5,v);else if(f===2)uv.setXY(q,.5+u*.46,.86+v*.14);else uv.setXY(q,.5+u*.46,v)}
L.push(b);
const part=(w,h,d,x,y,z,tu,tv)=>{const g=new THREE.BoxGeometry(w,h,d);g.translate(x,y,z);const a=g.attributes.uv;for(let i=0;i<a.count;i++)a.setXY(i,tu,tv);L.push(g)};
part(.034,.06,.035,0,-.012,-.1175,.985,.03);
if(ears){part(.02,.055,.045,-.105,-.01,0,.985,.09);part(.02,.055,.045,.105,-.01,0,.985,.09)}
let pc=0,ic=0;for(const g of L){pc+=g.attributes.position.count;ic+=g.index.count}
const PP=new Float32Array(pc*3),NN=new Float32Array(pc*3),UU=new Float32Array(pc*2),II=new Uint16Array(ic);let po=0,io=0;
for(const g of L){const n=g.attributes.position.count;PP.set(g.attributes.position.array,po*3);NN.set(g.attributes.normal.array,po*3);UU.set(g.attributes.uv.array,po*2);const ix=g.index.array;for(let i=0;i<ix.length;i++)II[io+i]=ix[i]+po;po+=n;io+=ix.length}
const m=new THREE.BufferGeometry();m.setAttribute('position',new THREE.BufferAttribute(PP,3));m.setAttribute('normal',new THREE.BufferAttribute(NN,3));m.setAttribute('uv',new THREE.BufferAttribute(UU,2));m.setIndex(new THREE.BufferAttribute(II,1));m.computeBoundingSphere();return HGC[k]=m}
function pickFace(kind,ally){if(ally)return'a'+(Math.random()*4|0);if(kind==='boss')return'e6';const r=Math.random();if(kind==='heavy')return r<.6?'e5':'e1';return r<.3?'e0':r<.45?'e1':r<.65?'e2':r<.82?'e3':'e4'}
var MDS={},MDR=[],MDMAX=LITE?6:(window.MO_MOBILE?10:16),MDFAR=45,mdF=0;
function mdB64(s,T){if(typeof s!=='string')return s;const b=atob(s),n=b.length,u=new Uint8Array(n);for(let i=0;i<n;i++)u[i]=b.charCodeAt(i);return new T(u.buffer)}
function mdTex(m){try{const mk=u=>{const t=new THREE.Texture();t.wrapS=t.wrapT=THREE.RepeatWrapping;t.anisotropy=typeof LITE!=='undefined'&&LITE?1:4;const im=new Image();im.onload=()=>{t.image=im;t.needsUpdate=true};im.src=u;return t},TB=mk(MD_TEX.b),TH=mk(MD_TEX.h),TG=mk(MD_TEX.g);
m.vertexColors=false;m.roughness=.78;
m.onBeforeCompile=sh=>{sh.uniforms.tB={value:TB};sh.uniforms.tH={value:TH};sh.uniforms.tG={value:TG};
sh.vertexShader=sh.vertexShader.replace('#include <common>','#include <common>\nattribute vec2 tuv;attribute float tid;varying vec2 vTu;varying float vTi;').replace('#include <begin_vertex>','#include <begin_vertex>\nvTu=tuv;vTi=tid;');
sh.fragmentShader=sh.fragmentShader.replace('#include <common>','#include <common>\nuniform sampler2D tB;uniform sampler2D tH;uniform sampler2D tG;varying vec2 vTu;varying float vTi;').replace('#include <map_fragment>','vec3 tc=vTi<.5?texture2D(tB,vTu).rgb:vTi<1.5?texture2D(tH,vTu).rgb:vTi<2.5?vec3(.03):texture2D(tG,vTu).rgb;diffuseColor.rgb*=pow(tc,vec3(2.2));')};
m.customProgramCacheKey=()=>'mdtex1';m.needsUpdate=true}catch(e){0}}
function mdTpl(key){
if(MDS[key]!==undefined)return MDS[key];if(!window.MD_DATA)return null;let r=null;
try{const d=MD_DATA[key],n=d.n,g=new THREE.BufferGeometry();
g.setAttribute('position',new THREE.BufferAttribute(mdB64(d.pos,Float32Array),3));
g.setAttribute('normal',new THREE.BufferAttribute(mdB64(d.nrm,Int8Array),3,true));
const c8=mdB64(d.col,Uint8Array),cf=new Float32Array(n*3);
for(let i=0;i<n*3;i++){const x=c8[i]/255;cf[i]=x<=.04045?x/12.92:Math.pow((x+.055)/1.055,2.4)}
g.setAttribute('color',new THREE.BufferAttribute(cf,3));if(d.tuv){g.setAttribute('tuv',new THREE.BufferAttribute(mdB64(d.tuv,Uint16Array),2,true));g.setAttribute('tid',new THREE.BufferAttribute(mdB64(d.tid,Uint8Array),1))}
const s8=mdB64(d.si,Uint8Array),w8=mdB64(d.sw,Uint8Array),si=new Uint16Array(n*4),sw=new Float32Array(n*4);
for(let i=0;i<n*4;i++){si[i]=s8[i];sw[i]=w8[i]/255}
g.setAttribute('skinIndex',new THREE.BufferAttribute(si,4));g.setAttribute('skinWeight',new THREE.BufferAttribute(sw,4));
g.setIndex(new THREE.BufferAttribute(mdB64(d.idx,d.idx32?Uint32Array:Uint16Array),1));
g.computeBoundingSphere();g.boundingSphere.radius*=1.3;
r={d:d,geo:g,mat:S(0xffffff,.82,.05,{vertexColors:true,skinning:true})};if(d.tuv)mdTex(r.mat)}
catch(e){0}
return MDS[key]=r}
function mdAttach(g,ally){
const T=mdTpl(ally?'swat':'tac');if(!T){if(!window.MD_DATA){MDP.push([g,ally]);MO_ASSETS.load()}return}
const D=T.d,B=D.bones,u=g.userData,bn=[];
for(let i=0;i<5;i++)bn.push(new THREE.Bone());
bn[1].position.set(B[1][0],B[1][1],B[1][2]);bn[2].position.set(B[2][0]-B[1][0],B[2][1]-B[1][1],B[2][2]-B[1][2]);
bn[3].position.set(B[3][0],B[3][1],B[3][2]);bn[4].position.set(B[4][0]-B[3][0],B[4][1]-B[3][1],B[4][2]-B[3][2]);
bn[0].add(bn[1]);bn[1].add(bn[2]);bn[0].add(bn[3]);bn[3].add(bn[4]);
const m=new THREE.SkinnedMesh(T.geo,T.mat);m.add(bn[0]);g.add(m);g.updateMatrixWorld(true);
m.bind(new THREE.Skeleton(bn),m.matrixWorld);
m.castShadow=true;m.raycast=function(){};m.userData.md=1;m.visible=false;
const rg=u.rg,hide=[],inRg=o=>{for(let p=o;p;p=p.parent)if(p===rg)return true;return false};
g.traverse(o=>{if(!o.isMesh||o===m)return;
if(inRg(o)){if(ally)hide.push(o);return}
if(!ally&&(o.material===mt('vest')||o.material===mt('helE')))return;
hide.push(o)});
if(ally&&D.muzzle&&u.mf&&u.mf.parent){const mf=u.mf;mf.parent.remove(mf);g.add(mf);mf.position.set(D.muzzle[0],D.muzzle[1],D.muzzle[2]-.06)}
MDR.push({g:g,m:m,hide:hide,bn:bn,u:u,on:false,d:0})}
function mdKnee(a,cr){return-(.35*Math.max(0,a)+1.1*Math.max(0,-a)+1.2*cr)}
var MDP=[];
function mdAssetsReady(){const q=MDP.splice(0);for(const e of q){if(e[0].parent){try{mdAttach(e[0],e[1])}catch(x){}}}}
function mdTick(){
if(!MDR.length)return;const cp=cam.position;
for(let i=MDR.length-1;i>=0;i--){const r=MDR[i];if(!r.g.parent){MDR.splice(i,1);continue}
const q=r.g.position,dx=q.x-cp.x,dy=q.y-cp.y,dz=q.z-cp.z;r.d=dx*dx+dy*dy+dz*dz}
if((mdF++&7)===0){const s=MDR.slice().sort((a,b)=>a.d-b.d),f2=MDFAR*MDFAR;
s.forEach((r,i)=>{const on=i<MDMAX&&r.d<f2;if(on!==r.on){r.on=on;r.m.visible=on;for(const o of r.hide)o.visible=!on}})}
for(const r of MDR){if(!r.on)continue;const lg=r.u.legs,a=lg[0].rotation.x,b=lg[1].rotation.x,cr=r.u.cr||0,bn=r.bn;
bn[1].rotation.x=a;bn[2].rotation.x=mdKnee(a,cr);bn[3].rotation.x=b;bn[4].rotation.x=mdKnee(b,cr)}}
function soldier(kind,ally,x,z,cz){const g=new THREE.Group(),big=kind==='boss'?1.2:kind==='heavy'?1.1:1,uni=mt(cz?'uniP':ally?'uniA':kind==='rifle'?'uniE':'uniH');g.rotation.order='YXZ';
const Pt=(geo,mat,px,py,pz,par)=>{const m=new THREE.Mesh(geo,mat);m.position.set(px,py,pz);m.castShadow=true;(par||g).add(m);return m};
Pt(Bx(.4,.2,.25),uni,0,.98,0);Pt(Bx(.44,.5,.26),uni,0,1.3,0);if(cz)czVest(Pt,cz);else{Pt(Bx(.48,.36,.3),mt('vest'),0,1.34,0);Pt(Bx(.38,.1,.06),mt('vest'),0,1.2,-.17)}
let skC;if(cz)skC=czAvatar(Pt,cz);else{{const fk=pickFace(kind,ally);skC=FVAR[fk].sk;Pt(headGeo(FVAR[fk].ears),faceMat(fk),0,1.67,0).userData.head=1}Pt(Bx(.25,.11,.27),mt(ally?'helA':'helE'),0,1.8,0).userData.head=1}
const arms=[];const legs=[-1,1].map(s=>{const lg=new THREE.Group();lg.position.set(s*.11,.92,0);g.add(lg);Pt(Bx(.16,.46,.18),uni,0,-.23,0,lg);Pt(Bx(.14,.42,.16),uni,0,-.66,0,lg);Pt(Bx(.15,.1,.27),mt('boot'),0,-.9,-.03,lg);return lg});
for(const s of[1,-1]){const ar=new THREE.Group();ar.position.set(s*.27,1.5,0);ar.rotation.x=s>0?1.15:1.35;ar.rotation.z=s>0?-.37:.61;g.add(ar);arms.push(ar);Pt(Bx(.11,.28,.11),uni,0,-.14,0,ar);const fa=new THREE.Group();fa.position.y=-.28;fa.rotation.x=.5;ar.add(fa);Pt(Bx(.1,.26,.1),uni,0,-.13,0,fa);{const hm=new THREE.Mesh(handGeo(s,'sgrip'),handMat(skC));hm.rotation.order='YXZ';hm.rotation.set(-PI/2,s*PI/2,0);hm.position.y=-.3;fa.add(hm)}if(s>0)Pt(Bx(.125,.1,.125),mt(ally?'bandA':'bandE'),0,-.1,0,ar)}
if(cz)czPack(Pt,cz);const rg=new THREE.Group();rg.position.set(.06,1.36,-.38);g.add(rg);Pt(Bx(.06,.09,.62),mt('gunM'),0,0,0,rg);Pt(Bx(.03,.03,.3),mt('gunM'),0,.01,-.44,rg);Pt(Bx(.04,.15,.06),mt('gunM'),0,-.11,-.05,rg);Pt(Bx(.05,.1,.2),mt('gunB'),0,-.02,.4,rg);
const mf=mkSpr(tSpr,0xffc060,1,.7);mf.position.set(0,0,-.65);mf.visible=false;rg.add(mf);
const wid=ally?'m4':kind==='boss'?'dmr':kind==='heavy'?(R()<.65?'lmg':'sg'):(()=>{const r=R();return r<.55?'ak':r<.8?'smg':r<.93?'sg':'pi'})();
if(!ally){if(wid==='ak'||wid==='lmg'||wid==='dmr'||wid==='sg'){Pt(Bx(.05,.08,.22),mt('gunW'),0,-.01,.42,rg);Pt(Bx(.056,.05,.22),mt('gunW'),0,-.01,-.28,rg)}
if(wid==='lmg')Pt(Bx(.09,.1,.1),mt('gunM'),0,-.12,-.04,rg);if(wid==='dmr')Pt(Bx(.04,.04,.2),mt('gunB'),0,.07,-.1,rg);if(wid==='smg')rg.scale.z=.72;if(wid==='pi')rg.scale.z=.45;if(wid==='sg')rg.scale.z=1.1}
rg.traverse(m=>{if(m.isMesh)m.castShadow=false});g.scale.setScalar(big);g.position.set(x,0,z);
const hp=kind==='boss'?800:kind==='heavy'?280:ally?160:100;
g.userData=Object.assign({kind,wid,arms,rg,hp,max:hp,legs,mf,mft:0,ph:0,ct:R()*.3,aim:.6,fire:1,left:0,sd:R()<.5?1:-1,sdT:R()*2,slide:0,bl:0,dt:0,pref:12+R()*14,s:2.4+R()*1.2+mi*.25,alert:true,tg:null,idl:R()*3,fy:R()*6,walk:false,dead:0},ally?{a:1}:{e:1});
if(wid==='sg')g.userData.pref=6+R()*5;else if(wid==='smg')g.userData.pref=9+R()*8;
if(!cz)try{mdAttach(g,ally)}catch(e){0}
try{gfxEnemy(g,kind,ally,cz)}catch(e){0}
sc.add(g);return g}
const SPOTS=[],LZ=[];let snW=-99;
function clearLZ(){LZ.forEach(l=>sc.remove(l));LZ.length=0}
function wtower(x,z,sn){const W=mt('crate'),D=mt('dark'),O=mt('olive'),y0=8.4,tp=y0+.3;
for(const a of[-1.7,1.7])for(const b of[-1.7,1.7])box(x+a,z+b,.4,y0,.4,D,1);
for(const s of[-1,1]){const bx=mesh(Bx(6.9,.1,.1),D,x,3.9,z+s*1.7,{cs:false});bx.rotation.z=1.05;const bz=mesh(Bx(.1,.1,6.9),D,x+s*1.7,3.9,z,{cs:false});bz.rotation.x=-1.05}
for(const o of[-.3,.3])box(x+o,z+2.05,.07,y0,.07,D,1,{nc:true});for(let h=.6;h<y0;h+=.7)box(x,z+2.05,.6,.05,.05,D,1,{y0:h,nc:true});
box(x,z,4.8,.3,4.8,W,2,{y0:y0,nc:true});
for(const s of[-1,1]){solids.push(box(x,z+s*2.3,4.8,1,.2,O,2,{y0:tp,nc:true}));solids.push(box(x+s*2.3,z,.2,1,4.8,O,2,{y0:tp,nc:true}))}
for(const a of[-2.3,2.3])for(const b of[-2.3,2.3])box(x+a,z+b,.14,2.6,.14,D,1,{y0:tp,nc:true});
box(x,z,5.6,.25,5.6,O,2,{y0:tp+2.6,nc:true});mesh(Bx(.35,.25,.35),mt('lamp'),x,tp+2.45,z,{cs:false});
if(sn)SPOTS.push({k:'s',x:x,z:z,h:tp})}
function checkpost(x,z,rw,bo,ng){const C=mt('conc'),D=mt('dark'),B=mt('bag'),Rd=mt('red'),Wh=mt('white'),bz=z+1.5;
box(x+bo,bz,2.6,2.6,2.6,C,2);box(x+bo,bz,3.2,.25,3.2,D,2,{y0:2.6,nc:true});box(x+bo+(bo<0?1.31:-1.31),bz,.05,1,1.6,mt('lamp'),1,{y0:1.2,nc:true});
const px=x+rw-.4;box(px,bz,.5,1.1,.5,D,1);const g=new THREE.Group();g.position.set(px,1.1,bz);world.add(g);
for(let i=0;i<6;i++)mesh(Bx(.8,.14,.14),i%2?Wh:Rd,-(.4+i*.8),0,0,{p:g,cs:false});mesh(Bx(.5,.3,.3),D,.35,0,0,{p:g,cs:false});g.rotation.z=-1.05;
box(x-rw+1.4,z+7,2.8,1,.8,C,2);box(x+rw-1.4,z-3,2.8,1,.8,C,2);box(x+bo,z+4,3,1.1,1,B,1);
box(x+rw-1,z+9,.12,2.2,.12,D,1,{nc:true});box(x+rw-1,z+9,1.2,1.2,.1,Rd,1,{y0:1.6,nc:true});box(x+rw-1,z+9,.7,.7,.12,Wh,1,{y0:1.85,nc:true});
for(let i=0;i<ng;i++)SPOTS.push({k:'g',x:x+2.4+i*.8,z:z+.5-i*2.7,h:0})}
function defenses(m){clearLZ();SPOTS.length=0;const k=m.b,ni=Math.max(0,MS.indexOf(m));let t=[],c=null;
if(k==='day'||k==='night'||k==='final'||k==='snow'||k==='nbase'){t=[[-15,44],[15,44],[-60,-32],[62,8],[-30,-62],[30,-62]];c=[0,60,4,-5.9]}
else if(k==='city'){t=[[-7,6],[8,-34]];c=[15,60,5,-2.8]}
else if(k==='desert'){t=[[-14,50],[14,50],[-34,-50],[34,-50]];c=[0,62,3,-4.8]}
else if(k==='tbase'){t=[[-41,22],[41,22],[-41,-50],[41,-50]];c=[0,62,3,-4.8]}
else if(k==='jungle'){t=[[-12,46],[12,46],[-26,-28],[26,-36]];c=[0,62,3,-4.8]}
else if(k==='border'){t=[[-15,44],[15,44],[-60,12],[60,12],[-45,-30],[45,-30]];c=[0,60,4,-5.9]}
else if(k==='rig')t=[[-27.5,27.5],[27,-28]];
else if(k==='village')t=[[-60,-30],[60,-30]];
const n=m.uav?0:Math.min(t.length,5,2+(ni>>1));t.forEach((p,i)=>wtower(p[0],p[1],i<n));if(c&&k==='border')checkpost(c[0],c[1],c[2],c[3],ni>5?3:2)}
function mkGuard(x,z){const e=soldier('rifle',0,x,z),u=e.userData;u.fix=1;u.alert=false;e.rotation.y=u.fy=R()*6.28;return e}
function mkSniper(x,z,h){const e=soldier('rifle',0,x,z),u=e.userData;e.position.y=h;u.sn=1;u.fix=1;u.wid='dmr';u.hp=u.max=90;u.alert=false;u.sc=-1.2;u.ph0=R()*6;u.base=Math.atan2(x,z);e.rotation.y=u.base;
const bl=new THREE.Mesh(Bx(.03,.03,.55),mt('gunM'));bl.position.set(0,.01,-.62);bl.castShadow=true;u.rg.add(bl);const sp=new THREE.Mesh(Bx(.05,.06,.22),mt('gunM'));sp.position.set(0,.08,-.1);u.rg.add(sp);
u.gl=mkSpr(tSpr,0xff3030,1,.5);u.gl.position.set(0,.03,-.95);u.gl.visible=false;u.rg.add(u.gl);
u.lz=new THREE.Mesh(Bx(1,1,1),new THREE.MeshBasicMaterial({color:0xff2a2a,transparent:true,opacity:.7,depthWrite:false}));u.lz.visible=false;u.lz.raycast=function(){};sc.add(u.lz);LZ.push(u.lz);return e}
function spawnFixed(){clearLZ();for(const s of SPOTS)enemies.push(s.k==='s'?mkSniper(s.x,s.z,s.h):mkGuard(s.x,s.z))}
function sniperAI(e,dt){const u=e.userData,ex=e.position.x,ez=e.position.z,ey=e.position.y+1.55;
if(u.fl>0)u.fl-=dt;e.rotation.x=u.fl>0?Math.sin(clamp(u.fl/.2,0,1)*PI)*.15:0;
if(u.mft>0){u.mft-=dt;if(u.mft<=0)u.mf.visible=false}
u.ct-=dt;if(u.ct<=0){u.ct=.25;u.tg=null;const dp=Math.hypot(P.x-ex,P.z-ez),rg=u.alert?cur.vis*1.35:cur.spot*1.5;let bd=1e9;
if(P.hp>0&&dp<rg&&los(ex,ey,ez,P.x,P.y-.2,P.z)){u.tg={pl:1,d:dp};bd=dp}
for(const a of allies){if(a.userData.dead)continue;const d=Math.hypot(a.position.x-ex,a.position.z-ez);if(d<rg&&d<bd&&los(ex,ey,ez,a.position.x,1.3,a.position.z)){u.tg={a:a,d:d};bd=d}}
if(u.tg&&!u.alert){u.alert=true;alertAll(ex,ez,14)}}
let face=u.base+Math.sin(time*.35+u.ph0)*1.2,aimP=0,tg=u.tg;
if(tg&&!tg.pl&&tg.a.userData.dead)tg=u.tg=null;
if(tg){const tx=tg.pl?P.x:tg.a.position.x,tz=tg.pl?P.z:tg.a.position.z,ty=tg.pl?P.y-.3:1.3,dx=tx-ex,dz=tz-ez,d=Math.hypot(dx,dz)||1,chT=1.9-Math.min(.5,mi*.05);
face=Math.atan2(-dx,-dz);aimP=Math.atan2(ty-(e.position.y+1.45),d);u.sc+=dt;
const mx=ex-Math.sin(e.rotation.y)*.9,mz=ez-Math.cos(e.rotation.y)*.9,my=e.position.y+1.5;
if(u.sc>0){const L=Math.hypot(tx-mx,ty-my,tz-mz),lz=u.lz;lz.position.set((mx+tx)/2,(my+ty)/2,(mz+tz)/2);lz.scale.set(.02,.02,L);lz.lookAt(tx,ty,tz);lz.visible=true;u.gl.visible=true;u.gl.scale.setScalar(.3+.9*clamp(u.sc/chT,0,1));
if(tg.pl&&time-snW>7){snW=time;pop('SNIPER ON THE TOWER!');radio('SGT. KHAN','There is a sniper on the tower! I can see the laser, take cover!')}
if(u.sc>=chT){const hit=R()<clamp(.62-d*.003,.3,.6)*(tg.pl&&moving?.7:1)*(tg.pl&&ads>.5?.85:1)*(cur.night?.9:1)*.8;let bx=tx,by=ty,bz=tz;if(!hit){bx+=(R()-.5)*2.6;by+=(R()-.5)*1.4;bz+=(R()-.5)*2.6}
tracer(mx,my,mz,bx,by,bz,.05);u.kk=1;u.mf.visible=true;u.mft=.06;sFar(d,panOf(ex,ez));
if(hit){const dm=12+mi*1.2;if(tg.pl)hurt(dm,ex,ez);else dmgA(tg.a,dm*2)}
u.sc=-(2.6+R()*1.4);u.lz.visible=false;u.gl.visible=false}}else{u.lz.visible=false;u.gl.visible=false}}
else{u.sc=u.sc>0?Math.max(0,u.sc-dt*2):Math.min(0,u.sc+dt);u.lz.visible=false;u.gl.visible=false}
e.rotation.y+=angDiff(face,e.rotation.y)*Math.min(1,dt*(tg?8:2));
u.ap=lerp(u.ap||0,tg?1:0,Math.min(1,dt*6));poseGun(u,aimP,dt);u.legs[0].rotation.x=u.legs[1].rotation.x=0}
const CRASH={g:null,done:0},FL={on:0,g:null,j:null,ji:null,x:0,y:34,z:0,z0:2400,D:1100,ms:[],mt:2,gr:null,fog:null,t:0,q:-1};
function jetM(g,col){const B=mt(col),D=mt('dark'),a=(geo,m,x,y,z)=>mesh(geo,m,x,y,z,{p:g});
a(Bx(9,1,1.3),B,0,1.5,0);const c=a(new THREE.ConeGeometry(.65,3.2,8),B,6.1,1.5,0);c.rotation.z=-PI/2;
a(Bx(3.8,.14,9.4),B,-.8,1.35,0);a(Bx(2,.12,3.8),B,-4,1.4,0);for(const s of[-1,1]){a(Bx(1.9,2.2,.14),B,-3.8,2.6,s*.7);a(Bx(1.8,.8,.4),D,1.2,1.1,s*.9)}
a(Bx(2.2,.5,.9),D,1.6,2.15,0);const e=a(new THREE.CylinderGeometry(.55,.5,1.2,10),D,-4.8,1.5,0);e.rotation.z=PI/2}
function jet(x,z,ry,col){const g=new THREE.Group();g.position.set(x,0,z);g.rotation.y=ry||0;world.add(g);jetM(g,col||'stl');
for(const p of[[2,0],[-2,-1.2],[-2,1.2]])mesh(Bx(.12,.9,.12),mt('dark'),p[0],.45,p[1],{p:g,cs:false});
boxes.push({x0:x-6,x1:x+6,z0:z-4.5,z1:z+4.5,h:2.5});return g}
function wreck(x,z){const g=new THREE.Group();g.position.set(x,0,z);world.add(g);const S=mt('stl'),D=mt('dark'),W=mt('white');
const a=(geo,m,px,py,pz,rx,rz)=>{const e=mesh(geo,m,px,py,pz,{p:g});if(rx)e.rotation.x=rx;if(rz)e.rotation.z=rz;return e};
a(Bx(3.2,3,9),W,0,1.5,0);a(Bx(3,2.6,3.5),D,.2,1.2,-6.2,0,.12);a(Bx(.4,4.5,2.6),S,0,4.2,5.8,-.2);a(Bx(10,.4,3),S,-6,1.2,.5,0,.18);a(Bx(5,.4,3),S,4.6,.9,1.2,0,-.3);
for(let i=0;i<10;i++)a(Bx(.4+R()*1.2,.3+R()*.5,.4+R()),i%2?S:D,(R()-.5)*14,.2,(R()-.5)*20);
boxes.push({x0:x-1.7,x1:x+1.7,z0:z-5,z1:z+5.4,h:3});
const em=[{x:x,y:3.2,z:z-2,t:1e9,a:0},{x:x,y:2.5,z:z+3,t:1e9,a:0},{x:x-6,y:1.5,z:z+.5,t:1e9,a:0}];em.forEach(e=>emit.push(e));world.userData.wEm=em;
if(fireL.length<4){const l=new THREE.PointLight(0xff7a2a,3,40,2);l.position.set(x,3,z);sc.add(l);l.visible=!!CFG.lights;fireL.push(l)}
world.userData.wreck=g}
function wreckFire(on){(world.userData.wEm||[]).forEach(e=>e.t=on?1e9:0)}
function border(){setGround('sand',50);road(0,22,120,8,'z',.03,true);road(0,-40,150,14,'x',.034,true);
fenceSeg(-76,50,-5,50);fenceSeg(5,76,50,50);box(-8,50,6,4,5,mt('conc'),3);box(8,50,6,4,5,mt('conc'),3);
for(const b of[[-36,24,24,6,10],[36,24,24,6,10],[-40,0,20,7,12],[40,-6,22,8,12],[-56,-64,24,10,14],[56,-64,24,10,14]])bld(b[0],b[1],b[2],b[3],b[4],'facN');
world.userData.ej=jet(-30,-52,0,'stl');jet(8,-52,0,'dark');jet(44,-52,0,'olive');wreck(-9,74);
for(let i=0;i<8;i++){const z=70-i*12;box(-6.5,z,.3,7,.3,mt('dark'),1);cyl(6.5,z,.15,7,mt('dark'),{seg:6});mesh(Bx(.8,.25,.5),mt('lamp'),-6.1,7,z,{cs:false})}
scatter(30,['crate','barrel','cont','barrier','bag','rock','car'],true);for(let i=0;i<6;i++){const x=(R()-.5)*100,z=(R()-.5)*100;if(freeAt(x,z,true))fireProp(x,z,i<2)}
box(0,-80,162,8,2,mt('sand'),6);box(0,112,162,8,2,mt('sand'),6);box(-80,16,2,8,194,mt('sand'),6);box(80,16,2,8,194,mt('sand'),6)}
function mkCrashPlane(){const g=new THREE.Group(),S=mt('stl'),W=mt('white'),a=(geo,m,x,y,z)=>mesh(geo,m,x,y,z,{p:g,cs:false});
a(Bx(3.2,3,12),W,0,0,0);const c=a(new THREE.ConeGeometry(1.6,3,10),W,0,0,7.2);c.rotation.x=PI/2;a(Bx(16,.4,3),S,0,-.3,.5);a(Bx(.4,4,2.4),S,0,2.6,-5.2);a(Bx(6,.3,2),S,0,.4,-5.4);g.visible=false;sc.add(g);return g}
function crashHit(){CRASH.done=1;if(CRASH.g)CRASH.g.visible=false;wreckFire(1);const w=world.userData.wreck;if(w)w.visible=true;explode(-9,1.6,74,9,0,false)}
function flyUI(){scBtn=0;scHold=false;fmS='';['fire','ads','rel','swb','jump','pk','zmb','brb','fmb','grb','mkb'].forEach(i=>{const e=$(i);if(e)e.style.display='none'});$('wbar').style.display='none';gun.visible=false}
function flyEnd(){nvSet(0);NV.b=100;uavEnd();if(!FL.on&&!FL.g)return;FL.on=0;if(FL.g){sc.remove(FL.g);FL.g=null}FL.ms=[];world.visible=true;if(FL.fog){sc.fog.near=FL.fog[0];sc.fog.far=FL.fog[1];FL.fog=null}}
function flyStart(){flyEnd();FL.on=1;world.visible=false;const g=FL.g=new THREE.Group();sc.add(g);FL.x=0;FL.y=34;FL.z=FL.z0;FL.ms=[];FL.mt=2.5;FL.t=0;FL.q=-1;P.hp=100;
const gr=FL.gr=new THREE.Mesh(new THREE.PlaneGeometry(1000,1000),mt('sand'));gr.rotation.x=-PI/2;g.add(gr);
for(let i=0;i<30;i++)for(const s of[-1,1])mesh(Bx(1.2,14,1.2),mt('dark'),s*46,7,FL.z0-i*40-20,{p:g,cs:false});
for(let i=0;i<20;i++)for(const s of[-1,1])mesh(Bx(30+R()*40,20+R()*45,30+R()*40),mt('rock'),s*(120+R()*90),10,FL.z0-i*58+R()*30,{p:g,cs:false});
const zb=FL.z0-FL.D;for(const s of[-1,1])mesh(Bx(3,70,3),mt('red'),s*38,35,zb,{p:g,cs:false});mesh(Bx(80,3,3),mt('red'),0,66,zb,{p:g,cs:false});mesh(Bx(76,.1,5),mt('white'),0,.2,zb,{p:g,cs:false});
const j=FL.j=new THREE.Group(),ji=FL.ji=new THREE.Group();j.add(ji);jetM(ji,'stl');j.rotation.y=PI/2;g.add(j);
FL.fog=[sc.fog.near,sc.fog.far];sc.fog.near=90;sc.fog.far=520;cam.fov=70;cam.updateProjectionMatrix();flyUI();ads=0;adsOn=false;firing=false;
radio('SGT. KHAN','SAM launch! Swerve the jet left and right and dodge the missiles!')}
function flyTick(dt){FL.t+=dt;const fx=k.KeyW?1:k.KeyS?-1:-mv.y,st=mv.x+(k.KeyD?1:0)-(k.KeyA?1:0);
FL.x=clamp(FL.x+st*34*dt,-38,38);FL.y=clamp(FL.y+fx*24*dt,14,62);FL.z-=50*dt;const j=FL.j,ji=FL.ji;
j.position.set(FL.x,FL.y,FL.z);ji.rotation.x=lerp(ji.rotation.x,-st*.7,Math.min(1,dt*6));ji.rotation.z=lerp(ji.rotation.z,fx*.3,Math.min(1,dt*5));
FL.gr.position.set(Math.round(FL.x/20)*20,0,Math.round(FL.z/20)*20);cam.position.set(FL.x*.85,FL.y+4.5,FL.z+17);cam.lookAt(FL.x,FL.y+1.5,FL.z-30);
puff({x:FL.x,y:FL.y+1.4,z:FL.z+6.5,vz:14,sz:1.7,life:.22,col:0xffa040,add:1,op:.9});
FL.mt-=dt;if(FL.mt<=0&&FL.z>FL.z0-FL.D+170){FL.mt=2.3+R()*1.2;const lx=FL.x+(R()-.5)*90,lz=FL.z-150-R()*40;mesh(Bx(2,1.2,3),mt('dark'),lx,.6,lz,{p:FL.g,cs:false});
const m=mesh(Bx(.45,.45,2.6),mt('red'),lx,2,lz,{p:FL.g,cs:false});FL.ms.push({m:m,v:new THREE.Vector3(0,28,0),l:0});pop('MISSILE LAUNCH!')}
for(let i=FL.ms.length-1;i>=0;i--){const q=FL.ms[i],m=q.m;q.l+=dt;const dx=FL.x-m.position.x,dy=FL.y-m.position.y,dz=FL.z-m.position.z,d=Math.hypot(dx,dy,dz)||1,kk=Math.min(1,dt*(q.l<.8?.6:1.15));
q.v.x+=(dx/d*72-q.v.x)*kk;q.v.y+=(dy/d*72-q.v.y)*kk;q.v.z+=(dz/d*72-q.v.z)*kk;m.position.addScaledVector(q.v,dt);m.lookAt(m.position.x+q.v.x,m.position.y+q.v.y,m.position.z+q.v.z);
puff({x:m.position.x,y:m.position.y,z:m.position.z,sz:1.1,life:.9,col:0xcccccc,grow:1.6,op:.6});
if(d<4.5){explode(m.position.x,m.position.y,m.position.z,3,0,false);hurt(28,FL.x,FL.z);pop('HIT! JET DAMAGED');FL.g.remove(m);FL.ms.splice(i,1);if(!run)return}
else if(m.position.z>FL.z+25||q.l>9){FL.g.remove(m);FL.ms.splice(i,1);score+=50;pop('MISSILE EVADED +50')}}
if((FL.t*4|0)!==FL.q){FL.q=FL.t*4|0;$('obj').textContent='ESCAPE TO THE BORDER · '+Math.max(0,Math.round(FL.z-(FL.z0-FL.D)))+'m'}
if(FL.z<=FL.z0-FL.D&&!stg.done){score+=500;pop('BORDER CROSSED +500');flyEnd();adv()}}
const UA={on:0,g:null,lead:null,x:0,z:0,yaw:0,alt:40,ammo:5,mx:5,t:0,rg:0,ms:[],mk:[],ret:null,rm:null,pf:false,fog:null,bad:false,ht:0,mvg:0};
const NV={on:0,b:100,bs:null,fl:0,ht:''};
function uavInit(){if(UA.g)return;const g=UA.g=new THREE.Group();
const bm=new THREE.MeshBasicMaterial({color:0xff3a2a,depthTest:false,transparent:true,opacity:.92}),gm=new THREE.MeshBasicMaterial({color:0x5dff7a,depthTest:false,transparent:true,opacity:.92});
const cg=new THREE.ConeGeometry(.55,1.5,4);cg.rotateX(PI);
for(let i=0;i<46;i++){const m=new THREE.Mesh(cg,i<40?bm:gm);m.renderOrder=999;m.visible=false;g.add(m);UA.mk.push(m)}
const rm=UA.rm=new THREE.MeshBasicMaterial({color:0x7dff9c,depthTest:false,transparent:true,opacity:.8,side:THREE.DoubleSide});
const rg=UA.ret=new THREE.Group(),a=new THREE.Mesh(new THREE.RingGeometry(8.5,9,56),rm),b=new THREE.Mesh(new THREE.RingGeometry(.4,1,20),rm);a.rotation.x=b.rotation.x=-PI/2;a.renderOrder=b.renderOrder=998;rg.add(a);rg.add(b);g.add(rg);
UA.lead=soldier('rifle',1,0,0,CZ);UA.lead.userData.name='ALPHA-1';g.add(UA.lead)}
function uavUI(){scBtn=0;scHold=false;fmS='';['ads','rel','swb','jump','pk','zmb','brb','fmb','grb','mkb'].forEach(i=>{const e=$(i);if(e)e.style.display='none'});$('wbar').style.display='none';gun.visible=false;$('fire').style.display='block';$('stick').style.display='block';$('xh').style.display='none';$('scp').style.opacity=0;$('adsv').style.opacity=0;ads=0;adsOn=false;scopeOn=false;const nb=$('nvb');if(nb)nb.style.display='none'}
function uavStart(s){uavInit();
if(!UA.on){UA.on=1;sc.add(UA.g);UA.x=P.x;UA.z=P.z-8;UA.yaw=0;UA.alt=40;UA.ammo=UA.mx;UA.t=.6;UA.rg=0;UA.ms.length=0;UA.pf=false;UA.fog=[sc.fog.near,sc.fog.far];sc.fog.near=150;sc.fog.far=620;cam.fov=58;cam.updateProjectionMatrix();document.body.classList.add('uvon');$('fire').textContent='STRIKE';firing=false;lkB.x=lkB.y=0}
uavUI();stg.ri=0;stg.sk=0;stg.dg=false;stg.hold=0;stg.wv=5;
(s.amb||[]).forEach(g=>{for(let i=0;i<g.n;i++)spawnE(g.heavy&&i<g.heavy?'heavy':'rifle',g.at,g.idle===0?false:true)});
if(s.tg){s.tg.forEach(t=>stg.tgl.push(mkTg(t.k,t.x,t.z,t.rot||0)));for(let i=0;i<(s.guards||0);i++)spawnE('rifle',s.at,true)}}
function uavEnd(){if(!UA.on)return;UA.on=0;if(UA.g){UA.ms.forEach(q=>UA.g.remove(q.m));UA.ms.length=0;sc.remove(UA.g)}if(UA.fog){sc.fog.near=UA.fog[0];sc.fog.far=UA.fog[1];UA.fog=null}document.body.classList.remove('uvon');$('fire').textContent='FIRE';$('xh').style.display='';firing=false;cam.fov=CFG.fov;cam.updateProjectionMatrix();$('dmg').style.opacity=0}
function uavCoop(s){const a=s.amb||[];let n=0,hv=0;a.forEach(g=>{n+=g.n;hv+=g.heavy||0});const at=a.length?a[0].at:[P.x,P.z-30,20];
if(s.tg)return{t:'destroy',tg:s.tg,guards:s.guards||4,at:s.at||at,o:s.o,s:s.s};return{t:'kill',n:Math.max(4,n),heavy:hv,at:at,o:s.o,s:s.s}}
function uavStrike(){if(UA.t>0)return;if(UA.ammo<=0){pop('NO MISSILES - RELOADING');return}if(UA.bad){pop('DANGER CLOSE - HOLD FIRE');return}
UA.ammo--;UA.t=1;const m=new THREE.Mesh(Bx(.4,.4,2.6),mt('red'));const sx=cam.position.x,sy=cam.position.y-2,sz=cam.position.z;m.position.set(sx,sy,sz);UA.g.add(m);
UA.ms.push({m:m,sx:sx,sy:sy,sz:sz,tx:UA.x,tz:UA.z,t:0,d:.9});nz(.5,2600,500,.35);shake=Math.max(shake,.5);if(R()<.4)radio('EAGLE-7',['Hellfire away!','Missile in the air!','Impact in one second!'][R()*3|0])}
function uavStage(s,dt,alive){const rt=s.route;let near=false;
for(const e of enemies){const u=e.userData;if(u.dead||!u.alert)continue;if(Math.hypot(e.position.x-P.x,e.position.z-P.z)<34){near=true;break}}
stg.dg=near;UA.mvg=0;
if(stg.ri<rt.length){const w=rt[stg.ri],dx=w[0]-P.x,dz=w[1]-P.z,d=Math.hypot(dx,dz);
if(d<2.6){stg.ri++;stg.sk=0}
else if(!near){const sp=3.7*dt;let mvd=false;for(const an of[0,.7,-.7,1.4,-1.4]){const ca=Math.cos(an),sa=Math.sin(an),mx=(dx*ca-dz*sa)/d*sp,mz=(dx*sa+dz*ca)/d*sp;if(!hitBox(P.x+mx,P.z+mz,.55)){P.x+=mx;P.z+=mz;P.yaw=Math.atan2(-mx,-mz);mvd=true;break}}
UA.mvg=mvd?1:0;if(mvd)stg.sk=Math.max(0,stg.sk-dt);else{stg.sk+=dt;if(stg.sk>2.5){stg.sk=0;stg.ri++}}}}
const done=stg.ri>=rt.length;
if(done&&s.hold&&stg.hold<s.hold){stg.hold+=dt;stg.wv-=dt;if(stg.wv<=0&&alive<8){stg.wv=6;for(let i=0;i<2;i++)spawnE(R()<.25?'heavy':'rifle',[P.x,P.z,36],false)}}
const tl=stg.tgl.filter(o=>!o.dead).length;let tx=s.o;if(stg.tgl.length)tx+=' ('+(stg.tgl.length-tl)+'/'+stg.tgl.length+')';
tx+=' · '+(!done?(near?'SQUAD PINNED DOWN':'SQUAD ADVANCING'):(s.hold&&stg.hold<s.hold?'HOLD '+Math.ceil(s.hold-stg.hold)+'s':alive?'CLEAR THE HOSTILES ('+alive+')':tl?'DESTROY THE TARGETS':''));
if($('obj').textContent!==tx)$('obj').textContent=tx;
if(done&&(!s.hold||stg.hold>=s.hold)&&!alive&&!tl)adv()}
function uavTick(dt){
const fx=k.KeyW?1:k.KeyS?-1:-mv.y,st=mv.x+(k.KeyD?1:0)-(k.KeyA?1:0);
{const a=1-Math.exp(-dt*22),ux=lkB.x*a,uy=lkB.y*a;lkB.x-=ux;lkB.y-=uy;UA.yaw+=ux;UA.alt=clamp(UA.alt+uy*70,26,62)}
const s=Math.sin(UA.yaw),c=Math.cos(UA.yaw),sp=(12+UA.alt*.28)*(k.ShiftLeft?1.6:1);
UA.x=clamp(UA.x+(-s*fx+c*st)*sp*dt,-74,74);UA.z=clamp(UA.z+(-c*fx-s*st)*sp*dt,-74,74);
if(!NET.g)for(let i=enemies.length-1;i>=0&&run;i--){const q=enemies[i];if(q.userData.sn)sniperAI(q,dt);else enemyAI(q,dt)}
updAllies(dt,true);stageTick(dt);updHosts(dt);updAmb(dt);if(!run)return;
P.hurtT+=dt;if(P.hurtT>4&&P.hp<100&&P.hp>0)P.hp=Math.min(100,P.hp+9*dt);hitFlash*=Math.pow(.92,dt*60);{const lo=P.hp<30&&P.hp>0&&!PV.on;if(lo){lowHbT-=dt;if(lowHbT<=0){lowHbT=.9;sHeart(.8)}}else lowHbT=0;$('dmg').style.opacity=Math.min(1,hitFlash+(lo?.2+.1*Math.sin(time*7):0))}
UA.t=Math.max(0,UA.t-dt);if(UA.ammo<UA.mx){UA.rg+=dt;if(UA.rg>=5){UA.rg=0;UA.ammo++}}else UA.rg=0;
if(firing&&!UA.pf)uavStrike();UA.pf=firing;
let bad=Math.hypot(UA.x-P.x,UA.z-P.z)<15;for(const a of allies)if(!a.userData.dead&&Math.hypot(UA.x-a.position.x,UA.z-a.position.z)<15)bad=true;
UA.bad=bad;UA.rm.color.set(bad?0xff4a3a:0x7dff9c);UA.ret.position.set(UA.x,.25,UA.z);
for(let i=UA.ms.length-1;i>=0;i--){const q=UA.ms[i];q.t+=dt;const u=Math.min(1,q.t/q.d),e=u*u,px=lerp(q.sx,q.tx,e),pz=lerp(q.sz,q.tz,e),py=lerp(q.sy,.8,e);q.m.position.set(px,py,pz);
const e2=Math.min(1,(q.t+.03)/q.d),e3=e2*e2;if(u<1)q.m.lookAt(lerp(q.sx,q.tx,e3),lerp(q.sy,.8,e3),lerp(q.sz,q.tz,e3));
puff({x:px,y:py,z:pz,sz:.9,life:.7,col:0xdddddd,grow:1.5,op:.55});
if(u>=1){UA.g.remove(q.m);UA.ms.splice(i,1);ST.wid=null;explode(q.tx,.8,q.tz,9,330,true);if(!run)return}}
const r=UA.alt*.55;shake*=.9;cam.position.set(UA.x+s*r+(R()-.5)*shake*.25,UA.alt+(R()-.5)*shake*.25,UA.z+c*r);cam.lookAt(UA.x,0,UA.z);
let ei=0;for(const e of enemies){if(ei>=40)break;if(e.userData.dead)continue;const m=UA.mk[ei++];m.visible=true;m.position.set(e.position.x,e.position.y+3.4,e.position.z);m.rotation.y=time*3;m.scale.setScalar(Math.max(1,cam.position.distanceTo(m.position)*.04))}
for(;ei<40;ei++)UA.mk[ei].visible=false;
let fi=40;const fm=a=>{if(fi>=46)return;const m=UA.mk[fi++];m.visible=true;m.position.set(a.x,3.6,a.z);m.rotation.y=time*3;m.scale.setScalar(Math.max(1,cam.position.distanceTo(m.position)*.04))};
fm({x:P.x,z:P.z});for(const a of allies)if(!a.userData.dead)fm({x:a.position.x,z:a.position.z});for(;fi<46;fi++)UA.mk[fi].visible=false;
const L=UA.lead,lu=L.userData;L.position.set(P.x,0,P.z);L.rotation.y+=angDiff(P.yaw,L.rotation.y)*Math.min(1,dt*8);lu.ph=(lu.ph||0)+UA.mvg*dt*9;const sw=UA.mvg?Math.sin(lu.ph)*.75:0;lu.legs[0].rotation.x=lerp(lu.legs[0].rotation.x,sw,.3);lu.legs[1].rotation.x=lerp(lu.legs[1].rotation.x,-sw,.3);lu.ap=lerp(lu.ap||0,stg.dg?1:0,Math.min(1,dt*6));poseGun(lu,0,dt);
UA.ht-=dt;if(UA.ht<=0){UA.ht=.15;const sec=Math.floor(time)%60;$('uvt').textContent='UAV EAGLE-7 · LIVE FEED · ALT '+Math.round(UA.alt)+'M';$('uvm').textContent=(cur?cur.loc:'')+' · '+(sec%2?'● REC':'○ REC');
let al=0;for(const e of enemies)if(!e.userData.dead)al++;const sq=allies.filter(a=>!a.userData.dead).length+1;
$('uvs').innerHTML='HELLFIRE '+'▮'.repeat(UA.ammo)+'▯'.repeat(UA.mx-UA.ammo)+'<br>'+(UA.t>0?'RELOADING...':UA.ammo?'READY':'EMPTY')+'<br>HOSTILES '+al+'<br>SQUAD '+sq+'/4 · HP '+Math.max(0,Math.round(P.hp));
$('uvw').textContent=UA.bad?'DANGER CLOSE - FRIENDLIES IN THE BLAST ZONE':(stg.dg?'SQUAD PINNED DOWN - STRIKE THE HOSTILES':'')}}
function nvSet(on){if(on===!!NV.on)return;const bd=document.body;
if(on){NV.bs={hi:hemi.intensity,hc:hemi.color.clone(),hg:hemi.groundColor.clone(),si:sun.intensity,sc:sun.color.clone(),ex:expB,fb:fogB?fogB.slice():null,fc:sc.fog.color.clone(),tr:torch.intensity};
sc.environment=null;gs.environment=null;hemi.intensity=2.1;hemi.color.set(0xb6ffc8);hemi.groundColor.set(0x4d7d5b);sun.intensity=.9;sun.color.set(0xc8ffd6);expB=1.55;rd.toneMappingExposure=expB*CFG.bright;fogB=[24,175];applyFog();sc.fog.color.setRGB(.01,.045,.02);torch.intensity=0;NV.on=1;bd.classList.add('nv');$('nvb').classList.add('on')}
else{if(ENVT&&ULTX){sc.environment=ENVT;gs.environment=ENVT}const b=NV.bs;if(b){hemi.intensity=b.hi;hemi.color.copy(b.hc);hemi.groundColor.copy(b.hg);sun.intensity=b.si;sun.color.copy(b.sc);expB=b.ex;rd.toneMappingExposure=expB*CFG.bright;fogB=b.fb;applyFog();sc.fog.color.copy(b.fc);torch.intensity=b.tr}NV.bs=null;NV.on=0;bd.classList.remove('nv');$('nvb').classList.remove('on')}
rdDirty=true}
function nvForce(){NV.on=0;NV.bs=null;NV.b=100;NV.fl=0;document.body.classList.remove('nv');const b=$('nvb');if(b)b.classList.remove('on')}
function nvToggle(){if(!run||paused||cin||!cur||!cur.nv||UA.on)return;if(NV.on){nvSet(0);tn(900,500,.08,.1)}else{if(NV.b<12){pop('NVG BATTERY LOW');return}nvSet(1);tn(500,1300,.12,.12)}}
function nvUI(v){const b=$('nvb');if(b)b.style.display=v&&cur&&cur.nv&&!UA.on?'block':'none';const h=$('nvh');if(h&&!v){h.style.display='none';NV.ht=''}}
function nvTick(dt){if(NV.on){NV.b-=dt*1.15;if(NV.b<=0){NV.b=0;nvSet(0);pop('NVG BATTERY DEAD - RECHARGING')}}else if(NV.b<100)NV.b=Math.min(100,NV.b+dt*3.2);
NV.fl*=Math.pow(.05,dt);const f=$('nvfl');f.style.opacity=NV.on?Math.min(1,NV.fl):0;
const sh=cur&&cur.nv&&run&&!cin&&!UA.on,t=sh?'NVG '+(NV.on?'ON':'OFF')+' · BATTERY '+Math.round(NV.b)+'%':'';if(t!==NV.ht){NV.ht=t;const h=$('nvh');h.textContent=t;h.style.display=sh?'block':'none'}}
addEventListener('keydown',e=>{if(e.code==='KeyN'&&!e.repeat)nvToggle()});
{const b=$('nvb');b.addEventListener('touchstart',e=>{e.preventDefault();e.stopPropagation();nvToggle()},{passive:false});b.addEventListener('touchend',e=>e.preventDefault(),{passive:false});b.addEventListener('mousedown',e=>e.stopPropagation());b.addEventListener('click',nvToggle)}
function angDiff(a,b){let d=a-b;while(d>PI)d-=2*PI;while(d<-PI)d+=2*PI;return d}
function alertAll(x,z,r){for(const e of enemies)if(!e.userData.alert&&Math.hypot(e.position.x-x,e.position.z-z)<r)e.userData.alert=true}
function spawnE(kind,near,idle){let x=0,z=0,t=0,ok=false;while(t<80&&!ok){t++;const a=R()*6.28,r=near?Math.sqrt(R())*near[2]:30+R()*45;x=(near?near[0]:P.x)+Math.cos(a)*r;z=(near?near[1]:P.z)+Math.sin(a)*r;ok=Math.abs(x)<72&&Math.abs(z)<72&&(!cur||!cur.deck||(x>cur.deck[0]&&x<cur.deck[1]&&z>cur.deck[2]&&z<cur.deck[3]))&&!hitBox(x,z,1.2)&&Math.hypot(x-P.x,z-P.z)>(idle?16:22)}
if(!ok)return null;const e=soldier(kind,0,x,z);e.userData.alert=!idle;enemies.push(e);return e}
function pickTarget(e,dp){const u=e.userData,ex=e.position.x,ez=e.position.z;let best=null,bd=1e9;
if(P.hp>0&&dp<cur.vis&&los(ex,1.55,ez,P.x,P.y-.2,P.z)){best={x:P.x,y:P.y-.3,z:P.z,pl:1,d:dp};bd=dp*(R()<.5?.6:1)}
for(const a of allies){if(a.userData.dead)continue;const d=Math.hypot(a.position.x-ex,a.position.z-ez);if(d<cur.vis&&d<bd&&los(ex,1.55,ez,a.position.x,1.3,a.position.z)){best={x:a.position.x,y:1.3,z:a.position.z,a:a,d:d};bd=d}}
if(!u.alert){if(best&&best.d<cur.spot){u.alert=true;alertAll(ex,ez,14)}else best=null}
if(best){if(!u.tg||u.tg.pl!==best.pl)u.aim=.45+R()*.5;u.tg=best;u.tgk=best;u.tgkT=6}else{u.tg=null;u.aim=.6}}
function enemyShot(e,tg,d){const u=e.userData,sc2=e.scale.x,mx=e.position.x-Math.sin(e.rotation.y)*.7,mz=e.position.z-Math.cos(e.rotation.y)*.7,my=1.45*sc2;
const ew=EW[u.wid]||EW.ak,ph=clamp(.58-d*.012,.06,.5)*(.55+.45*Math.min(1,(u.acq||0)/2.2))*(ew.sg?(d<14?1.5:.3):1)*(1+mi*.05)*(tg.pl&&moving?.8:1)*(tg.pl&&ads>.5?.9:1)*(cur.night?.85:1)*(PV.on?1:.75),hit=R()<ph;let bx=tg.x,by=tg.y,bz=tg.z;if(!hit){bx+=(R()-.5)*3;by+=(R()-.5)*1.6;bz+=(R()-.5)*3;if(tg.pl&&Math.hypot(bx-tg.x,bz-tg.z)<1.5)whiz()}
tracer(mx,my,mz,bx,by,bz,.04);u.kk=1;u.mf.visible=true;u.mft=.05;sFar(Math.hypot(e.position.x-P.x,e.position.z-P.z),panOf(e.position.x,e.position.z));
if(hit){const dm=(4.5+mi)*(u.kind==='heavy'?1.35:u.kind==='boss'?1.6:1)*ew.dm;if(tg.pl)hurt(dm,e.position.x,e.position.z);else dmgA(tg.a,dm*1.4)}}
let cvB=0;
function cvPath(x1,z1,x2,z2){const n=Math.max(2,Math.hypot(x2-x1,z2-z1)/.6|0);for(let i=1;i<n;i++){const t=i/n;if(hitBox(x1+(x2-x1)*t,z1+(z2-z1)*t,.5))return false}return true}
function coverFind(x,z,tx,tz,ty,rad,dmin,dmax,lx,lz,lr){
const dc=Math.hypot(x-tx,z-tz),cs=[];
for(let j=0;j<boxes.length;j++){const b=boxes[j];if(b.see||b.pl||b.h<1.3)continue;const nx=b.x0>x?b.x0:b.x1<x?b.x1:x,nz=b.z0>z?b.z0:b.z1<z?b.z1:z,dq=Math.hypot(nx-x,nz-z);if(dq>rad)continue;cs.push({b:b,dq:dq})}
cs.sort((a,b)=>a.dq-b.dq);if(cs.length>12)cs.length=12;
const pts=[];
for(const c of cs){const b=c.b,cx=x<b.x0+.4?b.x0+.4:x>b.x1-.4?b.x1-.4:x,cz=z<b.z0+.4?b.z0+.4:z>b.z1-.4?b.z1-.4:z;
for(const s of[[-1,0,b.x0-.75,cz],[1,0,b.x1+.75,cz],[0,-1,cx,b.z0-.75],[0,1,cx,b.z1+.75]]){const px=s[2],pz=s[3];if(Math.abs(px)>72||Math.abs(pz)>72)continue;
if((tx-px)*s[0]+(tz-pz)*s[1]>-.6)continue;const dt=Math.hypot(px-tx,pz-tz);if(dt<dmin||dt>dmax)continue;if(lr&&Math.hypot(px-lx,pz-lz)>lr)continue;
pts.push({b:b,x:px,z:pz,sc:Math.hypot(px-x,pz-z)+(dt>dc+3?(dt-dc)*1.5:0)+R()*2})}}
pts.sort((a,b)=>a.sc-b.sc);let tests=0;
for(const p of pts){if(tests++>=7)break;if(hitBox(p.x,p.z,.45))continue;const b=p.b,low=b.h<1.75;if(los(tx,ty,tz,p.x,low?1.2:1.45,p.z))continue;
let w=null;if(!cvPath(x,z,p.x,p.z)){let bl=1e9;for(const q of[[b.x0-.9,b.z0-.9],[b.x1+.9,b.z0-.9],[b.x0-.9,b.z1+.9],[b.x1+.9,b.z1+.9]]){if(Math.abs(q[0])>72||Math.abs(q[1])>72||hitBox(q[0],q[1],.45))continue;if(!cvPath(x,z,q[0],q[1])||!cvPath(q[0],q[1],p.x,p.z))continue;const l=Math.hypot(q[0]-x,q[1]-z)+Math.hypot(q[0]-p.x,q[1]-p.z);if(l<bl){bl=l;w=q}}if(!w)continue}
const ux=tx-p.x,uz=tz-p.z,ul=Math.hypot(ux,uz)||1,ex=-uz/ul,ez=ux/ul,sg=R()<.5?1:-1;let kx=p.x,kz=p.z,ok=false;
for(const o of[1.3*sg,-1.3*sg,2*sg,-2*sg]){const qx=p.x+ex*o,qz=p.z+ez*o;if(Math.abs(qx)>72||Math.abs(qz)>72||hitBox(qx,qz,.4))continue;if(!los(qx,1.45,qz,tx,ty,tz)||!cvPath(p.x,p.z,qx,qz))continue;kx=qx;kz=qz;ok=true;break}
if(!ok&&low&&b.h<1.55&&los(p.x,1.6,p.z,tx,ty,tz))ok=true;if(!ok)continue;
return{x:p.x,z:p.z,kx:kx,kz:kz,low:low,w:w}}
return null}
function eFire(e,u,tg,d,dt){u.aim-=dt;u.fire-=dt;if(u.aim<=0&&u.fire<=0){const ew=EW[u.wid]||EW.ak;if(u.left<=0)u.left=ew.b[0]+(R()*(ew.b[1]-ew.b[0]+1)|0);enemyShot(e,tg,d);u.left--;u.fire=u.left>0?ew.i:(.9+R()*1.2)*ew.pz}}
function cvTick(e,u,tg,dt,d){
if(!tg||u.kind==='boss'||u.sn||u.fix||!u.alert){if(u.cvS){u.cvS=0;u.crT=0}return 0}
if(u.cvp===undefined)u.cvp=R()<(u.kind==='heavy'?.4:.8)?1:0;if(!u.cvp){u.cvS=0;u.crT=0;return 0}
if(tg.pl){tg.x=P.x;tg.z=P.z}else if(tg.a){tg.x=tg.a.position.x;tg.z=tg.a.position.z}
const ex=e.position.x,ez=e.position.z;let s=u.cvS||0;u.cvRe=(u.cvRe||0)-dt;
if(s===0){u.crT=0;if(u.cvRe>0||d>u.pref+20||d<7||cvB<=0)return 0;u.cvRe=1+R()*1.5;cvB--;
const c=coverFind(ex,ez,tg.x,tg.z,tg.y,15,Math.min(9,u.pref*.5),u.cvAdv?Math.max(u.pref*.6,d-5):u.pref+14);if(!c)return 0;
u.cvP=c;u.cvS=s=1;u.cvTm=7;u.cvCy=2+(R()*3|0);u.cvTx=tg.x;u.cvTz=tg.z;u.cvW=c.w?1:0;u.cvAdv=0}
const c=u.cvP;u.cvK=(u.cvK||0)-dt;
if(u.cvK<=0){u.cvK=.5;if(Math.hypot(tg.x-u.cvTx,tg.z-u.cvTz)>14||(s===2&&los(tg.x,tg.y,tg.z,c.x,c.low?1.2:1.45,c.z))){u.cvS=0;u.cvRe=.3;u.crT=0;return 0}}
u.ms=0;u.mx=0;u.mz=0;
const go=(gx,gz,k)=>{const dx=gx-ex,dz=gz-ez,l=Math.hypot(dx,dz);if(l>.35){u.mx=dx/l;u.mz=dz/l;u.ms=u.s*k}return l};
if(s===1){u.cvTm-=dt;u.crT=0;let gx=c.x,gz=c.z;if(u.cvW&&c.w){gx=c.w[0];gz=c.w[1];if(Math.hypot(gx-ex,gz-ez)<.7)u.cvW=0}
const l=go(gx,gz,1.3);if((l<.5&&!u.cvW)||u.cvTm<=0){if(u.cvTm<=0&&l>2){u.cvS=0;u.cvRe=.5;u.ms=0;return 0}u.cvS=2;u.cvTm=.7+R()*1.3+(u.hp<u.max*.4?1.5:0)}return 1}
if(s===2){u.cvTm-=dt;u.crT=c.low?1:0;if(u.cvTm<=0){u.cvS=3;u.cvTm=1.5+R()*1.7;u.aim=.2+R()*.3;u.left=0}return 3}
u.cvTm-=dt;u.crT=0;const l=go(c.kx,c.kz,.9);if(u.fl>0&&u.cvTm>.6)u.cvTm=.1;
if(u.cvTm<=0){if(--u.cvCy<=0){u.cvS=0;u.cvRe=2+R()*2;u.cvAdv=1;u.ms=0;return 0}u.cvS=2;u.cvTm=.8+R()*1.4;u.crT=c.low?1:0;u.ms=0;return 3}
return l>.5?4:2}
function aCover(a,u,dt){
let t=u.tg&&!u.tg.userData.dead?u.tg:null;if(t){u.tgk=t;u.tgkT=6}else{u.tgkT=(u.tgkT||0)-dt;if(u.tgkT>0&&u.tgk&&!u.tgk.userData.dead)t=u.tgk}
if(!t||P.hp<=0){u.cvS=0;u.crT=0;u.hold=0;return 0}
const ax=a.position.x,az=a.position.z,tx=t.position.x,tz=t.position.z,td=Math.hypot(tx-ax,tz-az);let s=u.cvS||0;u.cvRe=(u.cvRe||0)-dt;
if(s===0){u.crT=0;u.hold=0;if(u.cvRe>0||td<7||cvB<=0)return 0;u.cvRe=1.2+R()*1.2;cvB--;
const c=coverFind(ax,az,tx,tz,1.3,13,6,70,P.x,P.z,16);if(!c)return 0;u.cvP=c;u.cvS=s=1;u.cvTm=6;u.cvCy=3+(R()*3|0);u.cvW=c.w?1:0;u.cvTx=tx;u.cvTz=tz}
const c=u.cvP;
if(Math.hypot(c.x-P.x,c.z-P.z)>20||Math.hypot(tx-u.cvTx,tz-u.cvTz)>16){u.cvS=0;u.cvRe=.4;u.crT=0;u.hold=0;return 0}
u.cvK=(u.cvK||0)-dt;if(u.cvK<=0){u.cvK=.6;if(s===2&&los(tx,1.3,tz,c.x,c.low?1.2:1.45,c.z)){u.cvS=0;u.cvRe=.3;u.crT=0;u.hold=0;return 0}}
let gx,gz;u.hold=1;
if(s===1){u.cvTm-=dt;u.crT=0;gx=c.x;gz=c.z;if(u.cvW&&c.w){gx=c.w[0];gz=c.w[1];if(Math.hypot(gx-ax,gz-az)<.8)u.cvW=0}if((Math.hypot(c.x-ax,c.z-az)<.5&&!u.cvW)||u.cvTm<=0){u.cvS=2;u.cvTm=.8+R()*1.2}}
else if(s===2){u.cvTm-=dt;u.crT=c.low?1:0;gx=c.x;gz=c.z;if(u.cvTm<=0){u.cvS=3;u.cvTm=1.6+R()*1.6}}
else{u.cvTm-=dt;u.crT=0;gx=c.kx;gz=c.kz;if(Math.hypot(gx-ax,gz-az)<.5)u.hold=0;if(u.cvTm<=0){if(--u.cvCy<=0){u.cvS=0;u.cvRe=2.5;u.crT=0;u.hold=0;return 0}u.cvS=2;u.cvTm=.9+R()*1.3;u.crT=c.low?1:0}}
u.cx=gx;u.cz=gz;return 1}
function enemyAI(e,dt){const u=e.userData,ex=e.position.x,ez=e.position.z,dpx=P.x-ex,dpz=P.z-ez,dp=Math.hypot(dpx,dpz);u.ct-=dt;if(u.ct<=0){u.ct=.3+R()*.2;pickTarget(e,dp)}u.acq=u.tg&&u.alert?(u.acq||0)+dt:Math.max(0,(u.acq||0)-dt*2);u.cvN=(u.cvN||0)-dt;u.tgkT=(u.tgkT||0)-dt;e.rotation.x=u.fl>0?Math.sin(clamp(u.fl/.2,0,1)*PI)*.2:0;if(u.fl>0)u.fl-=dt;
let mvx=0,mvz=0,spd=0,face=null;
if(u.mft>0){u.mft-=dt;if(u.mft<=0)u.mf.visible=false}
if(!u.alert){u.idl-=dt;if(u.idl<=0){u.idl=2+R()*3;u.fy=R()*6.28;u.walk=R()<.35}if(u.walk){spd=1.2;mvx=-Math.sin(u.fy);mvz=-Math.cos(u.fy)}face=u.fy}
else{const tg=u.tg||(u.cvS&&u.tgkT>0?u.tgk:null),tx=tg?tg.x:P.x,tz=tg?tg.z:P.z,dx=tx-ex,dz=tz-ez,d=Math.hypot(dx,dz)||1,nx=dx/d,nz=dz/d;face=Math.atan2(-dx,-dz);u.sdT-=dt;if(u.sdT<=0){u.sdT=1.5+R()*2;u.sd=-u.sd}
const cm=cvTick(e,u,tg,dt,d);if(cm){mvx=u.mx;mvz=u.mz;spd=u.ms;if(cm===1&&spd>0)face=Math.atan2(-mvx,-mvz);else if(cm===2&&u.tg)eFire(e,u,u.tg,d,dt)}else if(u.cv&&u.cvT>0){u.cvT-=dt;const cx=u.cv.x-ex,cz=u.cv.z-ez,cd=Math.hypot(cx,cz);if(cd>.7){mvx=cx/cd;mvz=cz/cd;spd=u.s*1.2}u.fire=Math.max(u.fire,.15);u.aim=Math.max(u.aim,.2)}else if(tg){if(d>u.pref+5){if(u.fa===undefined)u.fa=R()<.35?(R()<.5?.65:-.65):0;const fa=d>u.pref+14?u.fa:0,cf=Math.cos(fa),sf=Math.sin(fa);mvx=nx*cf-nz*sf;mvz=nx*sf+nz*cf;spd=u.s}else if(d<u.pref-7){mvx=-nx;mvz=-nz;spd=u.s*.7}else{mvx=-nz*u.sd;mvz=nx*u.sd;spd=u.s*.6}
u.aim-=dt;u.fire-=dt;if(u.aim<=0&&u.fire<=0){const ew=EW[u.wid]||EW.ak;if(u.left<=0)u.left=ew.b[0]+(R()*(ew.b[1]-ew.b[0]+1)|0);enemyShot(e,tg,d);u.left--;u.fire=u.left>0?ew.i:(.9+R()*1.2)*ew.pz;if(u.left<=0&&tg.pl&&!u.sn&&!u.fix&&u.kind!=='boss'&&(u.cvN||0)<=0&&!u.cvp&&R()<(u.hp<u.max*.6?.7:.3))tryCover(e,tg)}}
else if(d>8){mvx=nx;mvz=nz;spd=u.s}
if(u.slide>0){u.slide-=dt;mvx=-nz*u.sd;mvz=nx*u.sd;spd=u.s}}
if(u.stg>0){u.stg-=dt;spd*=.35}if(face!==null)e.rotation.y+=angDiff(face,e.rotation.y)*Math.min(1,dt*8);
if(spd){const n2x=ex+mvx*spd*dt,n2z=ez+mvz*spd*dt;let bl=0;if(!hitBox(n2x,ez,.5)&&(Math.abs(n2x)<76||Math.abs(n2x)<Math.abs(ex)))e.position.x=n2x;else bl=1;if(!hitBox(e.position.x,n2z,.5)&&(Math.abs(n2z)<76||Math.abs(n2z)<Math.abs(ez)))e.position.z=n2z;else bl=1;if(bl){u.bl+=dt;if(u.bl>.4){u.bl=0;u.sd=-u.sd;u.slide=.9}}{const p0=u.ph;u.ph+=spd*dt*2.4;npcStep(e,p0,u.ph)}}
{const hasT=u.alert&&u.tg;u.ap=lerp(u.ap||0,hasT?1:0,Math.min(1,dt*6));let pt=0;if(hasT){const dd=Math.hypot(u.tg.x-ex,u.tg.z-ez)||1;pt=Math.atan2(u.tg.y-1.45*e.scale.x,dd)}poseGun(u,pt,dt)}
const sw=spd?Math.sin(u.ph)*.75:0;u.cr=lerp(u.cr||0,u.crT||0,Math.min(1,dt*7));if(u.by===undefined)u.by=e.position.y;e.position.y=u.by-u.cr*.26*e.scale.x;const cc=u.cr*.7;u.legs[0].rotation.x=lerp(u.legs[0].rotation.x,sw+cc,.3);u.legs[1].rotation.x=lerp(u.legs[1].rotation.x,-sw+cc,.3)}
function deathSetup(e,head){const u=e.userData;e.rotation.x=0;if(u.by!==undefined)e.position.y=u.by;u.cr=0;u.cvS=0;let dx=hitDir.x,dz=hitDir.z;const l=Math.hypot(dx,dz)||1;dx/=l;dz/=l;u.ex=hitDir.ex;u.hd=head?1:0;u.ty=(!head&&!u.ex&&R()<.3)?1:0;
const a=Math.atan2(dx,dz)+(u.ty?(R()<.5?1:-1)*1.1:0)+(u.ex?0:(R()-.5)*.4);u.fx=Math.sin(a);u.fz=Math.cos(a);u.vk=u.ex?7:head?3.4:1.8+Math.min(2.5,hitDir.p/40);u.vy=u.ex?5.5:0;
u.yq=new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0,1,0),e.rotation.y);u.ax=new THREE.Vector3(u.fz,0,-u.fx);u.qf=new THREE.Quaternion();u.ab=u.arms.map(r=>r.rotation.x);u.th=0;
const hy=(head?1.7:1.3)*e.scale.x;for(let i=0;i<(head?14:9);i++)puff({x:e.position.x,y:e.position.y+hy,z:e.position.z,vx:dx*(2+R()*3)+(R()-.5)*2,vy:R()*2.5,vz:dz*(2+R()*3)+(R()-.5)*2,sz:.1+R()*.14,life:.45+R()*.3,col:0x8a0f0f,grav:9,op:.9});
if(bldP.length){const m=bldP[bI=(bI+1)%bldP.length];m.position.set(e.position.x,.03+bI*.0008,e.position.z);m.scale.setScalar(.01);m.visible=true;u.bm=m}}
function corpseAnim(e,dt){const u=e.userData;if(u.fx===undefined)return;if(u.dt>3.6&&u.vk<=.05&&!u.vy)return;u.dt+=dt;const T=u.ty?.85:u.hd?.45:.6,k=Math.min(1,u.dt/T),ang=1.55*(1-Math.pow(1-k,3))+(u.dt>T?Math.sin((u.dt-T)*20)*Math.exp(-(u.dt-T)*10)*.05:0);
u.qf.setFromAxisAngle(u.ax,ang);e.quaternion.copy(u.qf).multiply(u.yq);
if(u.vk>.05){const nx=e.position.x+u.fx*u.vk*dt,nz=e.position.z+u.fz*u.vk*dt;if(!hitBox(nx,e.position.z,.35))e.position.x=nx;if(!hitBox(e.position.x,nz,.35))e.position.z=nz;u.vk*=Math.pow(.03,dt)}
if(u.ex||u.vy){e.position.y+=u.vy*dt;u.vy-=18*dt;if(e.position.y<0){e.position.y=0;u.vy=0}}
const s1=ss(0,.35,k),s2=ss(.35,1,k);
for(let i=0;i<2;i++){const sd=i?1:-1;u.legs[i].rotation.x=Math.sin(k*3.2)*.55*sd*(u.ty?1.6:1)-(u.ty?.9*k:0);u.legs[i].rotation.z=sd*.12*k;const a=u.arms[i];a.rotation.x=lerp(lerp(u.ab[i],2.5,s1),.5,s2);a.rotation.z=(i?-1:1)*.7*k}
if(!u.th&&u.dt>=T*.9){u.th=1;const dd=Math.hypot(e.position.x-P.x,e.position.z-P.z);nz(.1,700,150,.5/(1+dd*.08));tn(80,40,.12,.4/(1+dd*.08))}
if(u.bm&&u.dt>.3)u.bm.scale.setScalar(.2+Math.min(1,(u.dt-.3)/3)*1.1)}
function dmgE(e,a,byP,head){const u=e.userData;if(u.dead)return;sHitE(e,byP,head);try{gfxHit(e)}catch(_){}if(byP)ST.h++;if(NET.g){if(byP&&u.nid)nSend({k:'dmg',id:u.nid,d:a,h:head?1:0,yw:P.yaw});return}u.hp-=a;u.fl=.2;u.stg=.45;u.acq=(u.acq||0)*.4;u.alert=true;alertAll(e.position.x,e.position.z,16);if(u.hp<=0)killE(e,byP,head)}
function killE(e,byP,head){const u=e.userData;if(!u.dead)sDieE(e,byP,head);try{gfxDead(e)}catch(_){}if(u.kind==='boss'&&cur&&cur.b==='final')shake=Math.max(shake,clamp(1-Math.hypot(e.position.x-P.x,e.position.z-P.z)/48,0,1)*3.4);u.dead=1;u.dt=0;u.mf.visible=false;deathSetup(e,head);if(u.sn){u.vk=Math.min(u.vk,.5);u.vy=0;u.ex=0;u.lz.visible=false;u.gl.visible=false;if(u.bm){u.bm.visible=false;u.bm=null}}const i=enemies.indexOf(e);if(i>=0)enemies.splice(i,1);corpses.push(e);if(corpses.length>(LITE?6:14)){const oc=corpses.shift();if(oc.userData.bm)oc.userData.bm.visible=false;sc.remove(oc)}if(u.e){dropFromE(e);dropKit(e)}
const pts=(u.kind==='boss'?1000:u.kind==='heavy'?250:u.sn?200:100)+(head?50:0);if(byP&&NET.gk){NET.gs=(NET.gs||0)+pts;nSend({k:'gsc',s:NET.gs,l:(head?'HEADSHOT +':'KILL +')+pts})}else if(byP){score+=pts;ST.k++;if(head)ST.hs++;if(ST.wid)wkAdd(ST.wid);ksN++;ksT=4.5;let sb=0;if(ksN>1){sb=Math.min(ksN,8)*20;score+=sb}pop((head?'HEADSHOT +':'KILL +')+pts+(sb?' \u00b7 STREAK x'+ksN+' +'+sb:''));hmT=1}else score+=pts/2;stg.killed=(stg.killed||0)+(u.fix?0:1);if(u.kind==='boss')stg.boss=null;
if(R()<.25&&performance.now()-lastR>5000){lastR=performance.now();radio('SGT. KHAN',['Target down!','Another one down!','Nice shot, sir!'][R()*3|0])}}
function dmgA(a,d){const u=a.userData;if(u.dead)return;if(u.rm){nSend({k:'hit',d:d});return}u.hp-=d;if(u.hp<=0){u.dead=1;u.dt=0;if(u.by!==undefined)a.position.y=u.by;u.cr=0;radio('SGT. KHAN','Man down! Cover Alpha!')}}
const ST={sh:0,h:0,hs:0,k:0,t0:0,wid:null};let dsx=0,dsz=0,dindT=0,hbT=0,healOn=0,ksN=0,ksT=0;
function hurt(d,sx,sz){if(!run)return;if(PV.on&&(PV.frz||PV.inv>0))return;if(UA.on)d*=.5;if(!PV.on)d*=.6;P.hp-=d;P.hurtT=0;hitFlash=Math.min(1,hitFlash+.35+d*.03);if(sx||sz){dsx=sx;dsz=sz;dindT=1}hap(d>15?60:28);nz(.12,400,100,.5);if(P.hp<30&&P.hp>0)sGrunt();if(P.hp<=0)die()}
const ANAMES=['KHAN','BILAL','ALI'],AO=[[-3,2.5],[3.2,1],[-6,-1.5]];
function mkAllies(){allies.forEach(a=>sc.remove(a));allies.length=0;if(cur&&cur.solo)return;ANAMES.forEach((n,i)=>{const a=soldier('rifle',1,P.x+(i%2?3:-3),P.z+3+i);a.userData.name=n;a.userData.alert=true;allies.push(a)})}
function reviveAllies(){allies.forEach((a,i)=>{const u=a.userData;if(u.dead||u.hp<u.max){u.dead=0;u.hp=u.max;a.rotation.x=0;u.cr=0;u.cvS=0;u.by=0;u.hold=0;a.position.set(P.x+(i%2?3:-3),0,P.z+3)}})}
function allyWarp(a,u,i){if((u.wpT||0)>time)return;const fy=P.yaw;let bx=0,bz=0,ok=false;
for(let q=0;q<18&&!ok;q++){const off=(R()-.5)*2+(i-1)*.5,rad=3+(q>>1)*.4+R()*1.5,x=P.x+Math.sin(fy+off)*rad,z=P.z+Math.cos(fy+off)*rad;
if(Math.abs(x)>Math.max(73,Math.abs(P.x)+4)||Math.abs(z)>Math.max(73,Math.abs(P.z)+4)||hitBox(x,z,.6))continue;
if(q<10&&!cvPath(x,z,P.x,P.z))continue;
let cl=false;for(const o of allies)if(o!==a&&!o.userData.dead&&Math.hypot(o.position.x-x,o.position.z-z)<1.3){cl=true;break}if(cl)continue;
bx=x;bz=z;ok=true}
if(!ok)return;a.position.x=bx;a.position.z=bz;u.stk=0;u.sk1=0;u.dvT=0;u.cvS=0;u.cvRe=2;u.hold=0;u.crT=0;u.wpT=time+4}
function updAllies(dt,fight){allies.forEach((a,i)=>{const u=a.userData;if(u.dead){corpseAnim(a,dt);return}if(u.rm){nRm(a,dt);return}
if(u.mft>0){u.mft-=dt;if(u.mft<=0)u.mf.visible=false}
const s=Math.sin(P.yaw),c=Math.cos(P.yaw),cvm=fight?aCover(a,u,dt):(u.cvS=0,u.crT=0,u.hold=0,0);
let tx=cvm?u.cx:P.x+c*AO[i][0]-s*AO[i][1],tz=cvm?u.cz:P.z-s*AO[i][0]-c*AO[i][1];
if(!cvm){{const Lx=Math.max(73,Math.abs(P.x)+8),Lz=Math.max(73,Math.abs(P.z)+8);tx=clamp(tx,-Lx,Lx);tz=clamp(tz,-Lz,Lz)}
if(hitBox(tx,tz,.5)){let k=.8,ok=false;for(let q=0;q<5;q++){const sx=P.x+(tx-P.x)*k,sz=P.z+(tz-P.z)*k;if(!hitBox(sx,sz,.5)){tx=sx;tz=sz;ok=true;break}k-=.17}if(!ok){tx=P.x;tz=P.z}}}
const dP=Math.hypot(P.x-a.position.x,P.z-a.position.z);
if(fight&&dP>34)allyWarp(a,u,i);
let dx=tx-a.position.x,dz=tz-a.position.z,d=Math.hypot(dx,dz),spd=0;
if(d>(cvm?.35:1.2)){const want=Math.min(8.5,d*2.2)*(fight&&u.tg&&!u.tg.userData.dead&&(u.ap||0)>.5?.7:1),ox=a.position.x,oz=a.position.z,ds=want*dt,base=Math.atan2(dz,dx);
u.dvT=(u.dvT||0)-dt;const dv=u.dv||1,seq=u.dvT>0?[0,dv*.6,dv*1.2,dv*1.9,-dv*.6,-dv*1.2,-dv*1.9]:[0,.6,-.6,1.2,-1.2,1.9,-1.9];
for(const an of seq){const nx=ox+Math.cos(base+an)*ds,nz2=oz+Math.sin(base+an)*ds;if((Math.abs(nx)<75||Math.abs(nx)<Math.abs(ox))&&(Math.abs(nz2)<75||Math.abs(nz2)<Math.abs(oz))&&!hitBox(nx,nz2,.5)){a.position.x=nx;a.position.z=nz2;if(an){u.dv=an>0?1:-1;u.dvT=1.2}break}}
if(Math.hypot(a.position.x-ox,a.position.z-oz)<ds*.1){const nx=ox+dx/d*ds,nz2=oz+dz/d*ds;if(!hitBox(nx,oz,.5))a.position.x=nx;else if(!hitBox(ox,nz2,.5))a.position.z=nz2}
const mvd=Math.hypot(a.position.x-ox,a.position.z-oz);spd=dt>0?mvd/dt:0;{const p0=u.ph;u.ph+=spd*dt*2.4;npcStep(a,p0,u.ph)}
if(fight&&dP>6&&mvd<ds*.35)u.stk=(u.stk||0)+dt;else u.stk=Math.max(0,(u.stk||0)-dt*2);
if(u.stk>1&&!u.sk1){u.sk1=1;if(u.cvS){u.cvS=0;u.cvRe=3;u.hold=0;u.crT=0}u.dv=-(u.dv||1);u.dvT=1.6}
if(u.stk>2.4&&dP>8){allyWarp(a,u,i)}
if(u.stk<=0)u.sk1=0}
else{u.stk=0;u.sk1=0}
for(const o of allies){if(o===a||o.userData.dead||o.userData.rm)continue;const ox=a.position.x-o.position.x,oz=a.position.z-o.position.z,od=Math.hypot(ox,oz);if(od<1.1){const pu=(1.1-od)*Math.min(1,dt*5),ux=(od<.01?R()-.5:ox/od)*pu,uz=(od<.01?R()-.5:oz/od)*pu;if(!hitBox(a.position.x+ux,a.position.z,.5))a.position.x+=ux;if(!hitBox(a.position.x,a.position.z+uz,.5))a.position.z+=uz}}
let face=spd?Math.atan2(-dx,-dz):a.rotation.y;
if(fight){u.ct-=dt;if(u.ct<=0){u.ct=.4;u.tg=null;let bd=48;for(const e of enemies){const q=Math.hypot(e.position.x-a.position.x,e.position.z-a.position.z);if(q<bd&&los(a.position.x,1.5,a.position.z,e.position.x,1.3,e.position.z)){bd=q;u.tg=e}}}
if(u.tg&&!u.tg.userData.dead){const t=u.tg,tdx=t.position.x-a.position.x,tdz=t.position.z-a.position.z,td=Math.hypot(tdx,tdz);face=Math.atan2(-tdx,-tdz);u.fire-=dt;if(u.fire<=0&&!(u.rl>0)&&(u.ap||0)>.8&&!u.hold&&Math.abs(angDiff(face,a.rotation.y))<.14){u.fire=u.left>0?.12:.5+R()*.5;if(u.left<=0)u.left=3;u.left--;const mg=(u.mag===undefined?30:u.mag)-1;u.mag=mg;if(mg<=0){u.rl=2.3;u.left=0}const hit=R()<(u.cvS?.62:.5)*(1-td/80);tracer(a.position.x,1.45,a.position.z,t.position.x+(hit?0:(R()-.5)*3),1.2,t.position.z,.035);u.kk=Math.min(1.8,(u.kk||0)*.6+1);u.mf.visible=true;u.mft=.05;sFar(td*.7+Math.hypot(a.position.x-P.x,a.position.z-P.z)*.3,panOf(a.position.x,a.position.z),2000);if(hit){hitDir.x=tdx;hitDir.z=tdz;hitDir.p=22;hitDir.ex=0;dmgE(t,22*(t.userData.kind==='boss'?.5:1),0,false)}}}else u.tg=null}
if(cvm&&!spd&&!u.tg&&u.tgk&&!u.tgk.userData.dead)face=Math.atan2(-(u.tgk.position.x-a.position.x),-(u.tgk.position.z-a.position.z));a.rotation.y+=angDiff(face,a.rotation.y)*Math.min(1,dt*8);{const has=fight&&u.tg&&!u.tg.userData.dead;if(u.rl>0){u.rl-=dt;if(u.rl<=0){u.mag=30;u.fire=.3;u.left=0}}else if(!has&&u.mag<18)u.rl=2.3;
u.ap=lerp(u.ap||0,has&&!(u.rl>0)?1:0,Math.min(1,dt*6));let pt=0;if(has){const t=u.tg;pt=Math.atan2(t.position.y+1.2-(a.position.y+1.42),Math.hypot(t.position.x-a.position.x,t.position.z-a.position.z)||1)}
pt+=Math.sin(time*1.3+i*2.1)*.012*(spd?2.2:1)+(spd?Math.sin(u.ph*2)*.02:0);poseGun(u,pt,dt,1);if(u.rl>0)rlPose(u,1-u.rl/2.3);
a.rotation.x=lerp(a.rotation.x,-(u.ap>.5?.04:.12)*Math.min(1,spd/6),Math.min(1,dt*8))}const sw=spd?Math.sin(u.ph)*.75:0;u.cr=lerp(u.cr||0,u.crT||0,Math.min(1,dt*7));if(u.by===undefined)u.by=a.position.y;a.position.y=u.by-u.cr*.26;const cc=u.cr*.7;u.legs[0].rotation.x=lerp(u.legs[0].rotation.x,sw+cc,.3);u.legs[1].rotation.x=lerp(u.legs[1].rotation.x,-sw+cc,.3)})}
const shwG=new THREE.RingGeometry(.88,1,40);shwG.rotateX(-PI/2);const shwP=[];for(let i=0;i<4;i++){const m=new THREE.Mesh(shwG,new THREE.MeshBasicMaterial({color:0xffe0b0,transparent:true,opacity:0,blending:THREE.AdditiveBlending,depthWrite:false,fog:false,side:THREE.DoubleSide}));m.visible=false;m.raycast=function(){};m.userData={t:0,r:8};sc.add(m);shwP.push(m)}let shwI=0;
const scM=new THREE.MeshBasicMaterial({map:radTex([[0,'rgba(0,0,0,.9)'],[.55,'rgba(14,10,6,.65)'],[1,'rgba(0,0,0,0)']]),transparent:true,depthWrite:false,polygonOffset:true,polygonOffsetFactor:-2}),scP=[];for(let i=0;i<8;i++){const m=new THREE.Mesh(new THREE.PlaneGeometry(1,1),scM);m.rotation.x=-PI/2;m.visible=false;m.raycast=function(){};sc.add(m);scP.push(m)}let scI=0;
const smk=[],SMC=[0x2a2826,0x3a3835,0x4d4a45,0x66615a];
function explode(x,y,z,rad,dmg,byP){if(NV.on)NV.fl=Math.max(NV.fl,clamp(1.15-Math.hypot(P.x-x,P.z-z)/38,0,1));winBlast(x,y,z,rad*1.8+5);const K=LITE?.55:1,S=clamp(rad/7.5,.7,1.6),gy=y<4,dc=Math.hypot(P.x-x,P.z-z);
puff({x,y:y+.6,z,sz:rad*1.5,life:.14,col:0xfff4d0,add:1,op:1});puff({x,y:y+.8,z,sz:rad*.9,life:.28,col:0xffffff,add:1,op:1,grow:rad*.6});
for(let i=0;i<(14*K|0);i++){const a=R()*6.28,b=R()*PI*.8,sp=(3+R()*6)*S;puff({x:x+(R()-.5),y:y+.4+R()*.6,z:z+(R()-.5),vx:Math.cos(a)*Math.sin(b)*sp,vy:Math.abs(Math.cos(b))*sp*.9+2,vz:Math.sin(a)*Math.sin(b)*sp,sz:(2.2+R()*2.2)*S,life:.4+R()*.5,col:[0xffd27a,0xff8a2a,0xff5a10][R()*3|0],add:1,grow:(3+R()*2)*S,drag:2.6,op:.95})}
for(let i=0;i<(10*K|0);i++)puff({x:x+(R()-.5)*2,y:y+.6,z:z+(R()-.5)*2,vx:(R()-.5)*3,vy:3+R()*4,vz:(R()-.5)*3,sz:(1.8+R()*1.4)*S,life:.9+R()*.6,col:0x6a2a10,grow:2.5*S,drag:1.2,op:.55});
for(let i=0;i<(18*K|0);i++)puff({x:x+(R()-.5)*2.5,y:y+.8+R(),z:z+(R()-.5)*2.5,vx:(R()-.5)*5*S,vy:2.5+R()*4.5,vz:(R()-.5)*5*S,sz:(2+R()*1.6)*S,life:3.5+R()*2.5,col:SMC[R()*4|0],grow:(5+R()*3)*S,drag:.55,op:.6});
smk.push({x,y:y+.5,z,t:3,max:3,a:0,k:S,wx:(R()-.5)*.7,wz:(R()-.5)*.7});
if(gy)for(let i=0;i<(16*K|0);i++){const a=i/(16*K)*6.28+R()*.3,sp=7+R()*5;puff({x,y:.35,z,vx:Math.cos(a)*sp*S,vy:.3+R()*.6,vz:Math.sin(a)*sp*S,sz:(1.2+R())*S,life:1+R()*.7,col:R()<.5?0x9a8a6a:0x7a6e58,grow:3*S,drag:2.2,op:.5})}
for(let i=0;i<(16*K|0);i++){const a=R()*6.28,sp=(4+R()*8)*S;puff({x,y:y+.4,z,vx:Math.cos(a)*sp,vy:6+R()*9,vz:Math.sin(a)*sp,sz:.16+R()*.14,life:1.2+R()*.9,col:[0x2b231b,0x4a3f33,0x6b5d4a][R()*3|0],grav:16,op:1})}
for(let i=0;i<(26*K|0);i++){const a=R()*6.28,b=R()*PI*.9,sp=10+R()*16;puff({x,y:y+.4,z,vx:Math.cos(a)*Math.sin(b)*sp,vy:Math.abs(Math.cos(b))*sp,vz:Math.sin(a)*Math.sin(b)*sp,sz:.2,life:.5+R()*.7,col:0xffd060,add:1,grav:14,drag:.6})}
for(let i=0;i<(6*K|0);i++)puff({x:x+(R()-.5)*3,y:y+.6,z:z+(R()-.5)*3,vx:(R()-.5)*2,vy:1.5+R()*2,vz:(R()-.5)*2,sz:.15,life:2.2+R()*1.2,col:0xff7a20,add:1,grav:-.6,op:.9});
{const m=shwP[shwI=(shwI+1)%shwP.length];m.position.set(x,gy?.15:y,z);m.userData.t=0;m.userData.r=rad*2.6;m.scale.setScalar(.4);m.material.opacity=.65;m.visible=true}
if(gy){const m=scP[scI=(scI+1)%scP.length],q=rad*(.9+R()*.3);m.position.set(x,.036+scI*.0008,z);m.scale.setScalar(q);m.rotation.z=R()*6;m.visible=true}
expL.position.set(x,y+1,z);expL.intensity=24*S;shake=Math.max(shake,clamp(1-dc/48,0,1)*1.7);sBoom(dc,panOf(x,z));if(dc<14){const q=1-dc/14;tn(5200,4800,.5+q*1.6,.03+q*.08);tn(3100,3000,.35+q*1.2,.02+q*.05)}
for(const e of enemies.slice()){const d=Math.hypot(e.position.x-x,e.position.z-z);if(d<rad){hitDir.x=e.position.x-x;hitDir.z=e.position.z-z;hitDir.p=120;hitDir.ex=1;dmgE(e,dmg*(1-d/rad)*1.3,byP,false);hitDir.ex=0}}
for(const a of allies){const d=Math.hypot(a.position.x-x,a.position.z-z);if(d<rad)dmgA(a,dmg*(1-d/rad)*.8)}
if(dc<rad)hurt(dmg*(1-dc/rad)*.6,x,z);if(PV.on&&byP)pvBlast(x,z,rad,dmg);
for(const o of tgs.slice()){if(o.dead)continue;const d=Math.hypot(o.x-x,o.z-z);if(d<rad+2)dmgT(o,dmg*(1-d/(rad+2))*1.4,byP)}}
const gun=new THREE.Group(),lh=new THREE.Group(),muz=new THREE.Object3D();cam2.add(gun);
function wearEdges(g,gb,s,col,a){g.strokeStyle='rgba('+col+','+a+')';g.lineWidth=5;g.strokeRect(2,2,s-4,s-4);g.lineWidth=2;g.strokeRect(8,8,s-16,s-16);gb.strokeStyle='#000';gb.lineWidth=4;gb.strokeRect(1,1,s-2,s-2)}
function scratches(g,gb,s,n,col){for(let i=0;i<n;i++){let x=R()*s,y=R()*s,a=R()*6.28,L=8+R()*40;g.strokeStyle='rgba('+col+','+(.12+R()*.3)+')';g.lineWidth=.5+R()*.9;gb.strokeStyle='rgba(0,0,0,.7)';gb.lineWidth=g.lineWidth;g.beginPath();gb.beginPath();g.moveTo(x,y);gb.moveTo(x,y);g.lineTo(x+Math.cos(a)*L,y+Math.sin(a)*L);gb.lineTo(x+Math.cos(a)*L,y+Math.sin(a)*L);g.stroke();gb.stroke()}}
function pits(g,gb,s,n,col){for(let i=0;i<n;i++){const x=R()*s,y=R()*s,r=.5+R()*1.4;g.fillStyle='rgba('+col+','+(.2+R()*.4)+')';g.beginPath();g.arc(x,y,r,0,7);g.fill();gb.fillStyle='rgba(0,0,0,.6)';gb.beginPath();gb.arc(x,y,r,0,7);gb.fill()}}
TF.gunM=()=>mkT(512,(u,v)=>{const st=vn(u*3,v*70,64)*.55+vn(u*7,v*150,64)*.3,n=fbm(u,v,8,4),k=.62+.5*st+.2*n+R()*.07;return[52*k,56*k,62*k,.25+.5*st+.25*n]},(g,gb,s)=>{wearEdges(g,gb,s,'150,155,162',.45);scratches(g,gb,s,70,'175,180,188');pits(g,gb,s,120,'12,12,14');for(let i=0;i<14;i++){g.fillStyle='rgba(60,32,14,'+(.04+R()*.08)+')';g.fillRect(R()*s,R()*s,2+R()*10,2+R()*14)}});
TF.gunB=()=>mkT(512,(u,v,x,y)=>{const dx=(x%5)-2.5,dy=(y%5)-2.5,dot=Math.max(0,1-Math.hypot(dx,dy)/2.3),n=fbm(u,v,8,3),k=.5+.18*n+.22*dot+R()*.05;return[38*k,40*k,43*k,.35*n+.6*dot]},(g,gb,s)=>{wearEdges(g,gb,s,'110,112,116',.35);scratches(g,gb,s,40,'120,122,128')});
TF.gunW=()=>mkT(512,(u,v)=>{const n=fbm(u,v,4,4),w=fbm(u*.5+.3,v,6,3),rg=Math.sin((v*34+n*7+w*3)*PI*2)*.5+.5,fine=vn(u*2,v*180,64),k=.5+.4*rg*rg+.18*fine+.1*n+R()*.04;return[128*k,72*k,34*k,.3+.55*rg+.15*fine]},(g,gb,s)=>{g.fillStyle='rgba(255,230,190,.07)';g.fillRect(0,0,s,s);scratches(g,gb,s,45,'30,16,6');pits(g,gb,s,60,'20,10,4');wearEdges(g,gb,s,'200,150,90',.25)});
TF.gunS=()=>mkT(512,(u,v)=>{const st=vn(u*2,v*90,64)*.6+vn(u*5,v*200,64)*.25,k=.78+.35*st+R()*.05;return[176*k,180*k,186*k,.2+.7*st]},(g,gb,s)=>{scratches(g,gb,s,60,'240,244,250');wearEdges(g,gb,s,'255,255,255',.3)});
TF.gunG=()=>mkT(512,(u,v,x,y)=>{const dx=(x%6)-3,dy=(y%6)-3,dot=Math.max(0,1-Math.hypot(dx,dy)/2.6),n=fbm(u,v,6,4),k=.55+.3*n+.18*dot+R()*.05;return[78*k,94*k,60*k,.4*n+.55*dot]},(g,gb,s)=>{scratches(g,gb,s,50,'140,150,110');wearEdges(g,gb,s,'150,160,120',.3)});
TF.glove=()=>mkT(256,(u,v,x,y)=>{const n=fbm(u,v,16,3),wv=Math.sin(x*1.3)*Math.sin(y*1.3),k=.5+.3*n+.12*wv+R()*.05;return[44*k,36*k,30*k,.4*n+.35*(wv*.5+.5)]},(g,gb,s)=>{pits(g,gb,s,120,'12,8,6')});
Object.assign(MF,{gunM:()=>M(tx('gunM'),{roughness:.42,metalness:.6,bumpScale:2.4,envMapIntensity:1.1}),gunB:()=>M(tx('gunB'),{roughness:.66,metalness:.12,bumpScale:3.2,envMapIntensity:.5}),gunW:()=>M(tx('gunW'),{roughness:.42,metalness:.04,bumpScale:1.8,envMapIntensity:.7}),gunS:()=>M(tx('gunS'),{roughness:.26,metalness:.75,bumpScale:1.2,envMapIntensity:1.2}),gunG:()=>M(tx('gunG'),{roughness:.6,metalness:.06,bumpScale:3,envMapIntensity:.5}),glove:()=>M(tx('glove'),{roughness:.8,bumpScale:2})});
TF.pisM=()=>mkT(256,(u,v)=>{const n=fbm(u,v,8,4),st=vn(u*4,v*60,64)*.5+vn(u*9,v*140,64)*.25,k=.55+.45*st+.22*n+R()*.06;return[40*k,44*k,52*k,.25+.5*st+.25*n]},(g,gb,s)=>{wearEdges(g,gb,s,'170,176,186',.55);scratches(g,gb,s,60,'190,196,205');pits(g,gb,s,90,'8,8,10');for(let i=0;i<8;i++){g.fillStyle='rgba(70,40,18,'+(.04+R()*.08)+')';g.fillRect(R()*s,R()*s,2+R()*10,2+R()*12)}});
TF.pisG=()=>mkT(256,(u,v,x,y)=>{const dx=(x%4)-2,dy=(y%4)-2,dot=Math.max(0,1-Math.hypot(dx,dy)/1.9),n=fbm(u,v,8,3),k=.5+.2*n+.25*dot+R()*.05;return[34*k,36*k,39*k,.3*n+.65*dot]},(g,gb,s)=>{wearEdges(g,gb,s,'120,122,128',.4);scratches(g,gb,s,40,'135,138,145');pits(g,gb,s,50,'6,6,8')});
Object.assign(MF,{pisM:()=>M(tx('pisM'),{roughness:.4,metalness:.62,bumpScale:2.6,envMapIntensity:1.1}),pisG:()=>M(tx('pisG'),{roughness:.64,metalness:.1,bumpScale:3.4,envMapIntensity:.5})});
const HTX={},HMT={},HGEO={},HSKIN_P=[196,152,118],HR={};let trigK=0;
function handTex(sk){const k=sk.join(',');if(HTX[k])return HTX[k];
const S=LITE?128:256,cv=document.createElement('canvas');cv.width=cv.height=S;const g=cv.getContext('2d');
g.fillStyle='rgb('+k+')';g.fillRect(0,0,S,S);
for(let i=0;i<46;i++){const x=R()*S,y=R()*S,r=S*(.06+R()*.16),gr=g.createRadialGradient(x,y,0,x,y,r),w=R()<.55;gr.addColorStop(0,w?'rgba(200,95,85,.11)':'rgba(255,232,210,.10)');gr.addColorStop(1,'rgba(0,0,0,0)');g.fillStyle=gr;g.fillRect(x-r,y-r,r*2,r*2)}
g.lineCap='round';
for(let i=0;i<5;i++){g.strokeStyle='rgba(76,102,128,.09)';g.lineWidth=S*.03;g.beginPath();let x=R()*S,y=S*.1;g.moveTo(x,y);for(let j=0;j<4;j++){x+=(R()-.5)*S*.12;y+=S*.22;g.lineTo(x,y)}g.stroke()}
g.lineWidth=1;
for(const cy of[.1,.9])for(let q=-1;q<=1;q++){g.strokeStyle='rgba(95,50,38,'+(q?.2:.32)+')';g.beginPath();const y0=S*(cy+q*.026);g.moveTo(0,y0);for(let x=0;x<=S;x+=S/8)g.lineTo(x,y0+(R()-.5)*2);g.stroke()}
for(let i=0;i<S*S/45;i++){g.fillStyle='rgba(70,40,30,'+(.1+R()*.16)+')';g.fillRect(R()*S,R()*S,1,1)}
g.lineWidth=.6;for(let i=0;i<S*1.2;i++){const x=R()*S,y=R()*S,l=3+R()*3;g.strokeStyle='rgba(46,32,24,.32)';g.beginPath();g.moveTo(x,y);g.lineTo(x+(R()-.5)*1.5,y-l);g.stroke()}
const id=g.getImageData(0,0,S,S),d=id.data;for(let i=0;i<d.length;i+=4){const n=1+(R()-.5)*.09;d[i]*=n;d[i+1]*=n;d[i+2]*=n}g.putImageData(id,0,0);
const t=new THREE.CanvasTexture(cv);t.encoding=THREE.sRGBEncoding;t.anisotropy=LITE?1:4;return HTX[k]=t}
const hmk=sk=>new THREE.MeshStandardMaterial({map:handTex(sk),bumpMap:LITE?null:handTex(sk),bumpScale:.8,vertexColors:true,roughness:.58,metalness:0,envMapIntensity:.35,emissive:new THREE.Color(.05,.018,.012)});
function handMat(sk){if(sk===HSKIN_P)return HPM||(HPM=hmk(czHandCol()));const k=sk.join(',');return HMT[k]||(HMT[k]=hmk(sk))}
const HPOSE={
relax:{f:[[.22,.34,.2],[.26,.4,.24],[.3,.46,.26],[.34,.5,.28]],sp:[-.06,-.01,.04,.1],th:[[-.55,-.2,-.8],[-.35,-.2,-.9],[-.1,-.1,-1]]},
pgrip:{f:[[.4,.5,.3],[.9,1.55,.9],[.95,1.6,.9],[.95,1.5,.85]],sp:[-.02,0,0,.02],th:[[-.2,-.05,-.97],[-.1,-.1,-.99],[0,-.12,-.99]]},
cgrip:{f:[[.85,1.35,.85],[.9,1.45,.85],[.95,1.5,.85],[.95,1.5,.8]],sp:[-.04,0,.02,.04],th:[[-.6,-.15,-.78],[-.4,-.15,-.9],[-.2,-.1,-.97]]},
sgrip:{f:[[.9,1.5,.9],[.95,1.55,.9],[.95,1.55,.9],[.95,1.5,.85]],sp:[-.02,0,0,.02],th:[[-.25,-.1,-.95],[-.15,-.1,-.98],[0,-.1,-1]]}};
HPOSE.lgrip=HPOSE.sgrip;
function handGeo(side,pose,part){const lo=pose==='sgrip',key=side+pose+(part||'')+(LITE?'l':'h');if(HGEO[key])return HGEO[key];
const P=HPOSE[pose],V=THREE.Vector3,Yv=new V(0,1,0),parts=[],seg=lo?5:LITE?6:10,sg=lo?5:LITE?6:10,sh=lo?4:LITE?5:8;
const SK=[.95,.92,.9],KN=[.9,.8,.77],NL=[1,.97,.95],X=x=>x*side,add=(g,c)=>parts.push([g,c]);
const ball=(x,y,z,rx,ry,rz,c)=>{const g=new THREE.SphereGeometry(1,sg,sh);g.scale(rx,ry,rz);g.translate(x,y,z);add(g,c)};
const limb=(a,b,ra,rb,c)=>{const d=b.clone().sub(a),L=d.length(),g=new THREE.CylinderGeometry(rb,ra,L,seg,1,true);g.applyMatrix4(new THREE.Matrix4().makeRotationFromQuaternion(new THREE.Quaternion().setFromUnitVectors(Yv,d.clone().normalize())));const m=a.clone().add(b).multiplyScalar(.5);g.translate(m.x,m.y,m.z);add(g,c)};
const nail=(a,d,len,r)=>{if(lo)return;const up=new V(0,1,0),n=up.sub(d.clone().multiplyScalar(d.y)).normalize(),c=a.clone().add(d.clone().multiplyScalar(len*.5)).add(n.clone().multiplyScalar(r*.8)),xa=new V().crossVectors(n,d).normalize(),g=new THREE.SphereGeometry(1,sg,sh);g.scale(r*.62,r*.2,len*.3);g.applyMatrix4(new THREE.Matrix4().makeBasis(xa,n,d).setPosition(c));add(g,NL)};
if(part!=='idx'){ball(0,0,0,.043,.0165,.05,SK);ball(X(-.024),-.011,.012,.021,.0145,.03,SK);ball(X(.02),-.007,.022,.017,.011,.026,SK)}
if(part!=='idx'){const w=new THREE.CylinderGeometry(.03,.0315,.07,seg+2,1,true);w.rotateX(PI/2);w.scale(1,.72,1);w.translate(0,0,.075);add(w,SK)}
const BX=[-.0305,-.0105,.0095,.0285],BY=[.002,.003,.002,0],BZ=[-.047,-.05,-.047,-.04],
FL=[[.04,.023,.019],[.044,.026,.02],[.041,.025,.019],[.033,.019,.017]],
FR=[[.0098,.0088,.0079,.007],[.01,.009,.0081,.0072],[.0094,.0085,.0077,.0068],[.0085,.0076,.0069,.0062]];
for(let f=0;f<4;f++){if(part==='noidx'&&f===0)continue;if(part==='idx'&&f!==0)continue;let p=part==='idx'?new V(0,0,0):new V(X(BX[f]),BY[f],BZ[f]),ang=0;if(part!=='idx')ball(p.x,p.y+.003,p.z,.0105,.0095,.0105,KN);
for(let s=0;s<3;s++){ang+=P.f[f][s];const d=new V(X(P.sp[f])*Math.cos(ang),-Math.sin(ang),-Math.cos(ang)).normalize(),q=p.clone().add(d.clone().multiplyScalar(FL[f][s]));
limb(p,q,FR[f][s],FR[f][s+1],SK);const r=FR[f][s+1];ball(q.x,q.y,q.z,r*1.05,r*1.05,r*1.05,s<2?KN:SK);if(s===2)nail(p,d,FL[f][2],FR[f][2]);p=q}}
if(part!=='idx'){let p=new V(X(-.03),-.01,.008);const TL=[.034,.031,.025],TR=[.0125,.0112,.01,.0092];
for(let i=0;i<3;i++){const d=new V(X(P.th[i][0]),P.th[i][1],P.th[i][2]).normalize(),q=p.clone().add(d.clone().multiplyScalar(TL[i]));
limb(p,q,TR[i],TR[i+1],SK);ball(q.x,q.y,q.z,TR[i+1]*1.05,TR[i+1]*1.05,TR[i+1]*1.05,i<2?KN:SK);if(i===2)nail(p,d,TL[i],TR[i]);p=q}}
let nv=0,ni=0;parts.forEach(([g])=>{nv+=g.attributes.position.count;ni+=g.index.count});
const pos=new Float32Array(nv*3),nor=new Float32Array(nv*3),uv=new Float32Array(nv*2),col=new Float32Array(nv*3),idx=new Uint16Array(ni);let vo=0,io=0;
parts.forEach(([g,c])=>{const n=g.attributes.position.count;pos.set(g.attributes.position.array,vo*3);nor.set(g.attributes.normal.array,vo*3);uv.set(g.attributes.uv.array,vo*2);for(let i=0;i<n;i++){col[(vo+i)*3]=c[0];col[(vo+i)*3+1]=c[1];col[(vo+i)*3+2]=c[2]}const ix=g.index.array;for(let i=0;i<ix.length;i++)idx[io+i]=ix[i]+vo;vo+=n;io+=ix.length;g.dispose()});
const G=new THREE.BufferGeometry();G.setAttribute('position',new THREE.BufferAttribute(pos,3));G.setAttribute('normal',new THREE.BufferAttribute(nor,3));G.setAttribute('uv',new THREE.BufferAttribute(uv,2));G.setAttribute('color',new THREE.BufferAttribute(col,3));G.setIndex(new THREE.BufferAttribute(idx,1));G.computeBoundingSphere();return HGEO[key]=G}
const HSLV=(()=>{const g=new THREE.CylinderGeometry(.04,.05,.62,12,1,true);g.rotateX(PI/2);g.scale(1,.9,1);return g})();
function handRig(par,side,pose,sk,slv,ax,tilt,idx){const h=new THREE.Mesh(handGeo(side,pose,idx?'noidx':undefined),handMat(sk));par.add(h);if(idx){const ix=new THREE.Mesh(handGeo(side,pose,'idx'),handMat(sk));ix.position.set(-.0305*side,.002,-.047);par.add(ix);h.userData.ix=ix}const sv=new THREE.Group();sv.position.z=.1;if(Array.isArray(tilt))sv.rotation.set(tilt[0],tilt[1],tilt[2]);else sv.rotation[ax]=tilt;par.add(sv);const c=new THREE.Mesh(HSLV,slv);c.position.z=.31;sv.add(c);return h}
const gM=mt('gunM'),gB=mt('gunB'),gW=mt('gunW'),gS=mt('gunS'),gG=mt('gunG'),gl=mt('glove'),sl=mt('uniP'),shM=S(0xa02a22,.6,.1),cylG=(r,l)=>{const g=new THREE.CylinderGeometry(r,r,l,10);g.rotateX(PI/2);return g};
const pM=mt('pisM'),pG=mt('pisG'),vK=S(0x08090b,.85,.15),dotW=new THREE.MeshBasicMaterial({color:0xf2f2e6});
const ejP=(a,x,y,z,h,d,pr)=>{a(Bx(.0022,h,d),vK,x,y,z,pr);a(Bx(.0032,.003,d+.008),gM,x,y+h/2+.0015,z,pr);a(Bx(.0032,.003,d+.008),gM,x,y-h/2-.0015,z,pr)};
function GP(geo,m,x,y,z,par){const e=new THREE.Mesh(geo,m);e.position.set(x,y,z);(par||gun).add(e);return e}
{const rH=new THREE.Group();rH.position.set(.026,-.11,.15);rH.rotation.z=-PI/2;gun.add(rH);HR.rH=rH;HR.ix=handRig(rH,1,'pgrip',HSKIN_P,sl,'y',.45,1).userData.ix;
const rK=new THREE.Group();rK.position.set(.077,-.035,0);rK.quaternion.setFromRotationMatrix(new THREE.Matrix4().makeBasis(new THREE.Vector3(0,0,1),new THREE.Vector3(0,-1,0),new THREE.Vector3(1,0,0)));gun.add(rK);handRig(rK,1,'lgrip',HSKIN_P,sl,null,[-.35,.6,0]);rK.visible=false;HR.rK=rK}
{const sn=Math.sin(.5),cs=Math.cos(.5),q=new THREE.Quaternion().setFromRotationMatrix(new THREE.Matrix4().makeBasis(new THREE.Vector3(-cs,0,-sn),new THREE.Vector3(0,-1,0),new THREE.Vector3(-sn,0,cs)));
for(const k of['C','F']){const g=new THREE.Group();g.position.set(-.037,-.03,.068);g.quaternion.copy(q);lh.add(g);handRig(g,-1,k==='C'?'cgrip':'lgrip',HSKIN_P,sl,'x',-.4);HR['l'+k]=g}
const g=new THREE.Group();g.position.set(.014,-.01,.06);g.rotation.z=PI/2;lh.add(g);handRig(g,-1,'lgrip',HSKIN_P,sl,'y',-.45);HR.lP=g;g.visible=false}gun.add(lh);gun.add(muz);
const gFlash=new THREE.PointLight(0xffa850,0,3,2);gun.add(gFlash);const fm=mkSpr(tSpr,0xffcc66,1,.3);fm.material.opacity=0;gun.add(fm);
const dotM=new THREE.MeshBasicMaterial({color:0xff2020}),dotS=mkSpr(tSpr,0xff2020,1,.014);gun.add(dotS);gun.visible=false;
const gh={t:0,mv:0,zp:0,zv:0,pp:0,pv:0,yp:0,yv:0,rp:0,rv:0,sx:0,svx:0,sy:0,svy:0,ly:0,lv:0,st:0,cr:0,draw:1,wasG:true,lvy:0};
function kf(F,t){if(t<=F[0][0])return F[0].slice(1);for(let i=1;i<F.length;i++)if(t<=F[i][0]){const a=F[i-1],b=F[i],k=ss(a[0],b[0],t),r=[];for(let j=1;j<a.length;j++)r.push(a[j]+(b[j]-a[j])*k);return r}return F[F.length-1].slice(1)}
const WD={
m4:{n:'M4A1',s:'M4',cl:2,type:'mag',cap:30,rate:.09,auto:1,dmg:34,hd:100,pel:1,spr:.007,spa:.0015,rk:.011,rh:.007,kz:1,rf:1,zoom:.64,hip:[.19,-.215,-.46],ads:[0,-.147,-.34],hold:[0,-.06,-.42],well:[0,-.15,-.07],chp:[0,.1,.12],mm:[.042,.2,.066],mag0:4,mmax:7,sup:2,mv:1,dr:1,bk:0,al:38,fr:[45,150,.6],mz:[0,.035,-.87],dot:[0,.15,-.07],snd:0,fs:.3},
ak:{n:'AK-47',s:'AK',cl:2,type:'mag',cap:30,rate:.105,auto:1,dmg:42,hd:115,pel:1,spr:.009,spa:.002,rk:.017,rh:.012,kz:1.3,rf:1.1,zoom:.64,hip:[.19,-.215,-.46],ads:[0,-.112,-.32],hold:[0,-.06,-.4],well:[0,-.13,-.09],chp:[.03,.05,.05],mm:[.04,.2,.07],mag0:3,mmax:6,sup:2,mv:.98,dr:.9,bk:.6,al:42,fr:[40,140,.55],mz:[0,.035,-.93],dot:null,snd:1,fs:.34},
lmg:{n:'RPK LMG',s:'RPK',cl:2,type:'mag',cap:75,rate:.085,auto:1,dmg:38,hd:105,pel:1,spr:.011,spa:.003,rk:.013,rh:.012,kz:1.2,rf:1.9,zoom:.66,hip:[.19,-.22,-.48],ads:[0,-.112,-.34],hold:[0,-.07,-.45],well:[0,-.13,-.09],chp:[.03,.05,.05],mm:[.09,.16,.1],mag0:2,mmax:3,sup:1,mv:.88,dr:.8,bk:.6,al:46,fr:[45,150,.6],mz:[0,.035,-1.07],dot:null,snd:2,fs:.38},
smg:{n:'MP7 SMG',s:'MP7',cl:2,type:'mag',cap:30,rate:.066,auto:1,dmg:24,hd:70,pel:1,spr:.011,spa:.003,rk:.008,rh:.008,kz:.7,rf:.85,zoom:.7,hip:[.18,-.2,-.42],ads:[0,-.118,-.3],hold:[0,-.08,-.27],well:[0,-.15,-.12],chp:[.03,.05,.08],mm:[.036,.19,.05],mag0:4,mmax:7,sup:2,mv:1.07,dr:1.3,bk:0,al:16,fr:[18,60,.45],mz:[0,.04,-.78],dot:[0,.118,-.05],snd:3,fs:.18},
sg:{n:'M870 SHOTGUN',s:'870',cl:2,type:'shell',cap:6,rate:.8,auto:0,dmg:15,hd:25,pel:8,spr:.045,spa:.03,rk:.06,rh:.02,kz:2.4,rf:1,zoom:.68,hip:[.19,-.22,-.45],ads:[0,-.105,-.34],hold:[0,-.05,-.43],well:[0,-.1,-.05],chp:[0,0,0],mm:[.03,.06,.03],rsv0:24,rmax:48,rsup:10,mv:1,dr:.9,bk:0,al:45,fr:[7,32,.1],mz:[0,.045,-.97],dot:null,snd:4,fs:.45},
dmr:{n:'SVD DMR',s:'SVD',cl:2,type:'mag',cap:10,rate:.42,auto:0,dmg:95,hd:190,pel:1,spr:.004,spa:.0004,rk:.05,rh:.012,kz:2,rf:1.15,zoom:.3,scope:1,hip:[.19,-.215,-.46],ads:[0,-.118,-.3],hold:[0,-.06,-.44],well:[0,-.13,-.06],chp:[.034,.05,.05],mm:[.04,.17,.07],mag0:4,mmax:6,sup:1,mv:.94,dr:.8,bk:.5,al:48,fr:null,mz:[0,.035,-1.15],dot:null,snd:5,fs:.4},
snp:{n:'AWM SNIPER',s:'AWM',cl:2,type:'mag',cap:5,rate:1.1,auto:0,dmg:180,hd:400,pel:1,spr:.002,spa:.0001,rk:.07,rh:.012,kz:2.6,rf:1.35,zoom:.18,scope:1,hip:[.19,-.215,-.46],ads:[0,-.118,-.3],hold:[0,-.06,-.44],well:[0,-.13,-.06],chp:[.034,.05,.05],mm:[.04,.17,.07],mag0:5,mmax:7,sup:1,mv:.9,dr:.7,bk:.9,al:60,fr:null,mz:[0,.035,-1.3],dot:null,snd:5,fs:.5},
kn:{n:'COMBAT KNIFE',s:'KNIFE',cl:0,type:'melee',cap:1,rsv0:0,rmax:0,rsup:0,rate:.45,auto:0,dmg:110,hd:110,pel:1,spr:0,spa:0,rk:0,rh:0,kz:1,rf:1,zoom:1,hip:[.17,-.2,-.38],ads:[.17,-.2,-.38],hold:[0,0,0],well:[0,0,0],chp:[0,0,0],mm:[.01,.01,.01],mag0:0,mmax:0,sup:0,mv:1.12,dr:1,bk:0,al:6,fr:null,mz:[0,0,-.3],dot:null,snd:6,fs:0},
pi:{n:'M9 PISTOL',s:'M9',cl:1,type:'mag',cap:15,rate:.14,auto:0,dmg:28,hd:80,pel:1,spr:.009,spa:.003,rk:.02,rh:.012,kz:1.1,rf:.8,zoom:.78,hip:[.14,-.2,-.42],ads:[0,-.079,-.28],hold:[-.04,-.1,.09],well:[0,-.17,.085],chp:[-.02,.03,.1],mm:[.0325,.12,.051],mag0:4,mmax:8,sup:2,mv:1.05,dr:1.5,bk:1,al:26,fr:[20,70,.5],mz:[0,.034,-.205],dot:null,snd:6,fs:.16}};
function relBuild(id){const d=WD[id];if(d.type!=='mag')return;const H=d.hold,Wl=d.well,C=d.chp,V=[-.2,-.52,0],f=d.rf*1.2;
const T=[[0,H[0],H[1],H[2],0,0],[.27,H[0],H[1],H[2],.38,-.12],[.51,Wl[0],Wl[1],Wl[2],.5,-.2],[.81,V[0],V[1],V[2],.5,-.16],[.87,V[0],V[1],V[2],.5,-.16],[1.29,Wl[0],Wl[1]-.19,Wl[2],.5,-.2],[1.47,Wl[0],Wl[1]-.02,Wl[2],.45,-.18],[1.614,Wl[0],Wl[1]-.05,Wl[2],.45,-.1],[1.95,H[0],H[1],H[2],0,0]];
const E=T.slice(0,8).concat([[1.86,C[0],C[1],C[2],.3,-.05],[2.3,C[0],C[1],C[2],.3,-.05],[2.65,H[0],H[1],H[2],0,0]]),sc_=r=>[r[0]*f].concat(r.slice(1));
d.FT=T.map(sc_);d.FE=E.map(sc_);d.ET=[[.5,'drop'],[.8,'stow'],[.86,'grab'],[1.47,'insert']].map(e=>[e[0]*f,e[1]]);d.EE=[[.5,'drop'],[.86,'grab'],[1.47,'insert'],[1.98,'rack'],[2.17,'release']].map(e=>[e[0]*f,e[1]]);d.tT=1.95*f;d.tE=2.65*f}for(const id in WD)relBuild(id);
const WM={};
function mkW(id,fn){const o={g:new THREE.Group(),mag:new THREE.Group(),nm:new THREE.Group(),ch:null,chb:0,cht:.06};const a=(geo,m,x,y,z,pr)=>{const e=new THREE.Mesh(geo,m);e.position.set(x,y,z);(pr||o.g).add(e);return e};fn(a,o);o.g.add(o.mag);o.g.visible=false;o.nm.visible=false;gun.add(o.g);lh.add(o.nm);WM[id]=o}
function MG(o,m,pos,pcs){o.mag.position.set(pos[0],pos[1],pos[2]);for(const p of pcs)for(const par of[o.mag,o.nm]){const e=new THREE.Mesh(Bx(p[0],p[1],p[2]),m);e.position.set(p[3],p[4],p[5]);e.rotation.x=p[6]||0;par.add(e)}}
mkW('m4',(a,o)=>{a(Bx(.058,.085,.26),gM,0,-.005,.02);a(Bx(.056,.07,.36),gM,0,.06,-.04);a(Bx(.026,.016,.52),gB,0,.102,-.12);a(Bx(.024,.048,.19),gB,0,.074,-.285);for(let i=0;i<6;i++)a(Bx(.03,.008,.012),gB,0,.112,-.34+i*.07);
a(Bx(.066,.066,.34),gB,0,.02,-.36);for(const s of[-1,1])a(Bx(.012,.012,.3),gM,s*.036,.02,-.36);a(cylG(.0105,.28),gM,0,.035,-.66);a(cylG(.017,.075),gB,0,.035,-.83);a(Bx(.006,.072,.006),gB,0,.078,-.6);
a(cylG(.02,.24),gB,0,.02,.25);a(Bx(.05,.1,.2),gB,0,-.01,.4);a(Bx(.036,.095,.052),gB,0,-.095,.1).rotation.x=.3;a(Bx(.01,.03,.08),gM,0,-.055,.03);a(Bx(.05,.04,.075),gB,0,-.065,-.06);a(Bx(.002,.02,.07),gB,.029,.06,0);
a(Bx(.034,.018,.06),gB,0,.118,-.04);a(Bx(.04,.006,.07),gB,0,.171,-.04);for(const s of[-1,1])a(Bx(.006,.043,.07),gB,s*.017,.1485,-.04);a(Bx(.004,.004,.004),dotM,0,.15,-.07);
MG(o,gM,[0,-.12,-.06],[[.042,.145,.066,0,.0075,0,0],[.042,.07,.066,0,-.095,-.01,.2]]);ejP(a,.0285,.062,-.02,.026,.07);o.ch=a(Bx(.032,.014,.035),gM,0,.108,.14);o.chb=.14;o.cht=.06});
function akB(a,o,L,drum){const bl=.3+L;a(Bx(.054,.075,.3),gM,0,.02,0);a(Bx(.05,.028,.34),gM,0,.07,-.02);a(Bx(.06,.05,.35),gW,0,.012,-.315);a(Bx(.05,.025,.31),gW,0,.06,-.335);
a(cylG(.0105,bl+.1),gM,0,.035,-.45-(bl+.1)/2);a(cylG(.012,.34+L*.5),gM,0,.078,-.52-L*.25);a(cylG(.016,.06),gB,0,.035,-.58-bl);a(Bx(.008,.067,.008),gB,0,.0765,-.52-bl);a(Bx(.022,.052,.04),gM,0,.066,-.67-L*.5);a(Bx(.034,.022,.04),gM,0,.095,-.02);
a(Bx(.045,.095,.395),gW,0,-.015,.3375);a(Bx(.036,.125,.052),gW,0,-.0806,.1).rotation.x=.3;a(Bx(.05,.07,.075),gB,0,-.05,-.06);if(L)for(const s of[-1,1])a(Bx(.01,.016,.23),gS,s*.03,-.016,-.595);
if(drum)MG(o,gM,[0,-.1,-.09],[[.06,.16,.1,0,.03,0,0],[.09,.09,.1,0,-.09,0,0]]);else MG(o,gM,[0,-.1,-.09],[[.04,.15,.07,0,.015,0,0],[.04,.1,.07,0,-.1,-.028,.3]]);
ejP(a,.0275,.04,-.06,.03,.09);o.ch=a(Bx(.014,.03,.045),gM,.033,.05,.03);o.chb=.03;o.cht=.1}
mkW('ak',(a,o)=>akB(a,o,0,0));mkW('lmg',(a,o)=>akB(a,o,.14,1));
mkW('smg',(a,o)=>{a(Bx(.052,.08,.26),gM,0,.015,0);a(Bx(.046,.045,.34),gM,0,.06,-.06);a(Bx(.026,.012,.3),gB,0,.088,-.1);for(let i=0;i<8;i++)a(Bx(.028,.005,.012),gM,0,.0955,-.215+i*.03);
a(cylG(.011,.28),gM,0,.04,-.36);a(cylG(.0125,.03),gM,0,.04,-.505);a(cylG(.0225,.25),gM,0,.04,-.64);for(let i=0;i<6;i++)a(cylG(.0242,.007),gB,0,.04,-.545-i*.04);a(cylG(.02,.012),gB,0,.04,-.768);a(cylG(.0085,.004),vK,0,.04,-.7745);
a(Bx(.034,.014,.09),gM,0,0,-.26);a(Bx(.03,.14,.04),gB,0,-.04,-.26);for(let i=0;i<5;i++)a(Bx(.032,.004,.044),gM,0,-.085+i*.02,-.26);a(Bx(.03,.012,.044),gM,0,-.112,-.26);
a(Bx(.036,.12,.052),gB,0,-.085,.1).rotation.x=.3;a(Bx(.05,.063,.075),gB,0,-.0535,-.04);
a(Bx(.05,.058,.034),gM,0,.03,.148);for(const s of[-1,1]){a(cylG(.007,.2),gM,s*.022,.026,.255);const hp=a(cylG(.0115,.01),gM,s*.0285,.03,.158);hp.rotation.y=PI/2}
a(Bx(.048,.082,.022),gM,0,.026,.36);a(Bx(.05,.088,.01),vK,0,.026,.376);a(Bx(.012,.018,.022),gB,.0275,.05,.165);
for(const s of[-1,1])for(let i=0;i<5;i++)a(Bx(.002,.014,.012),vK,s*.0235,.062,-.2+i*.03);for(let i=0;i<3;i++)a(Bx(.0535,.0025,.16),vK,0,-.012+i*.012,0);ejP(a,.0235,.062,-.02,.02,.07);
a(Bx(.034,.018,.06),gB,0,.098,-.04);a(Bx(.04,.006,.07),gB,0,.139,-.04);for(const s of[-1,1])a(Bx(.006,.043,.07),gB,s*.017,.1165,-.04);
MG(o,gM,[0,-.11,-.12],[[.036,.155,.05,0,.0125,0,0],[.036,.06,.05,0,-.09,-.01,.15]]);MG(o,gB,[0,-.11,-.12],[[.04,.01,.054,0,-.123,-.0145,.15]]);
o.ch=a(Bx(.012,.02,.03),gM,.03,.05,.08);o.chb=.08;o.cht=.07});
mkW('sg',(a,o)=>{a(Bx(.058,.085,.3),gM,0,.01,0);a(cylG(.016,.8),gM,0,.045,-.54);a(cylG(.014,.68),gM,0,-.012,-.48);a(Bx(.016,.01,.6),gS,0,.066,-.55);a(Bx(.006,.032,.006),gB,0,.074,-.93);a(Bx(.03,.05,.02),gM,0,.075,-.04);a(cylG(.02,.03),gB,0,.04,-.94);
a(Bx(.05,.1,.33),gW,0,-.02,.415);a(Bx(.044,.085,.12),gW,0,-.04,.2);a(Bx(.04,.045,.08),gB,0,-.0525,.02);a(Bx(.036,.105,.05),gB,0,-.0825,.1).rotation.x=.3;
const fo=new THREE.Object3D();fo.position.set(0,-.005,-.43);o.g.add(fo);a(Bx(.062,.052,.2),gW,0,0,0,fo);a(Bx(.066,.056,.012),gM,0,0,-.1,fo);ejP(a,.0295,.02,-.03,.03,.1);o.ch=fo;o.chb=-.43;o.cht=.14;
o.nm.add(new THREE.Mesh(cylG(.011,.06),shM));const sb=new THREE.Mesh(cylG(.0115,.016),csM);sb.position.z=.03;o.nm.add(sb)});
mkW('dmr',(a,o)=>{a(Bx(.054,.08,.3),gM,0,.015,0);a(Bx(.05,.03,.34),gM,0,.065,-.03);a(Bx(.058,.05,.41),gW,0,.01,-.345);a(Bx(.05,.022,.36),gW,0,.05,-.37);a(cylG(.0115,.6),gM,0,.035,-.8);a(cylG(.017,.08),gB,0,.035,-1.1);a(cylG(.012,.4),gM,0,.072,-.62);a(Bx(.022,.056,.04),gM,0,.054,-.8);
a(Bx(.03,.024,.2),gB,0,.086,-.03);a(cylG(.022,.26),gB,0,.116,-.04);a(cylG(.03,.05),gB,0,.116,-.18);a(cylG(.026,.04),gB,0,.116,.1);a(Bx(.02,.026,.02),gB,0,.14,-.04);
a(Bx(.04,.085,.43),gW,0,-.01,.355);a(Bx(.036,.12,.052),gW,0,-.085,.1).rotation.x=.3;a(Bx(.05,.063,.075),gB,0,-.0535,-.06);
MG(o,gM,[0,-.1,-.06],[[.04,.135,.07,0,.0175,0,0],[.04,.05,.07,0,-.07,-.02,.25]]);o.ch=a(Bx(.014,.016,.04),gM,.033,.05,.05);o.chb=.05;o.cht=.09;ejP(a,.0275,.03,-.04,.03,.09)});
mkW('pi',(a,o)=>{const K=1.16,gy=-.075,gz=.085,X=x=>x*K,Y=y=>gy+(y-gy)*K,Z=z=>gz+(z-gz)*K,RK=-.2,
b=(w,h,d,x,y,z,m,pr)=>pr?a(Bx(w*K,h*K,d*K),m,x*K,y*K,z*K,pr):a(Bx(w*K,h*K,d*K),m,X(x),Y(y),Z(z)),
cy=(r,l,x,y,z,m,pr)=>pr?a(cylG(r*K,l*K),m,x*K,y*K,z*K,pr):a(cylG(r*K,l*K),m,X(x),Y(y),Z(z));
b(.03,.03,.17,0,-.014,-.01,pG);b(.028,.012,.09,0,-.032,-.068,pG);for(let i=0;i<3;i++)b(.03,.004,.008,0,-.0395,-.1+i*.02,gB);
b(.034,.1,.05,0,-.078,.088,pG).rotation.x=RK;for(const s of[-1,1])b(.003,.076,.04,s*.0185,-.08,.088,gB).rotation.x=RK;b(.02,.088,.01,0,-.076,.114,pG).rotation.x=RK;b(.018,.012,.024,0,.003,.104,gM);
b(.007,.032,.008,0,-.051,-.02,pG);b(.007,.018,.01,0,-.058,-.017,pG).rotation.x=.55;b(.007,.007,.083,0,-.067,.0215,pG);b(.007,.024,.012,0,-.048,.035,gM).rotation.x=.3;
b(.005,.012,.012,.0185,-.042,.062,gM);b(.004,.008,.034,-.017,.006,.02,gM);b(.004,.01,.018,-.0165,0,-.05,gM);
const sd=new THREE.Object3D();sd.position.set(0,Y(.023),Z(-.015));o.g.add(sd);
b(.032,.036,.22,0,-.001,0,pM,sd);for(const s of[-1,1])b(.006,.006,.205,s*.0125,.0185,0,pM,sd).rotation.z=s*.75;b(.014,.004,.2,0,.02,0,gM,sd);
for(let i=0;i<7;i++)b(.012,.0016,.0022,0,.0222,.018+i*.011,vK,sd);b(.012,.0035,.04,0,.0222,-.07,vK,sd);
for(const s of[-1,1]){for(let i=0;i<5;i++)b(.0016,.024,.0042,s*.0168,0,.056+i*.0095,gB,sd);for(let i=0;i<4;i++)b(.0016,.022,.0042,s*.0168,0,-.058-i*.0095,gB,sd)}
b(.0022,.016,.058,.0165,.008,-.01,vK,sd);b(.0032,.003,.066,.0167,.0175,-.01,pM,sd);b(.0032,.003,.066,.0167,-.0005,-.01,pM,sd);b(.0025,.012,.006,.0172,.006,.024,gM,sd);
b(.026,.005,.014,0,.0225,.092,gM,sd);for(const s of[-1,1]){b(.0075,.012,.008,s*.0075,.0285,.095,gM,sd);b(.0028,.0028,.0012,s*.0075,.0305,.1,dotW,sd)}
b(.008,.006,.014,0,.0225,-.098,gM,sd);b(.0045,.011,.007,0,.0285,-.099,gM,sd);b(.003,.003,.0012,0,.029,-.0955,dotW,sd);
cy(.0085,.05,0,-.004,-.125,gM,sd);a(cylG(.0052*K,.003*K),vK,0,-.004*K,-.1515*K,sd);cy(.0112,.012,0,-.003,-.106,gB,sd);b(.03,.03,.012,0,-.003,-.114,pM,sd);
const mp=[[.029,.105,.044,0,0,0,RK],[.034,.009,.052,0,-.0545,.011,RK]].map(p=>[p[0]*K,p[1]*K,p[2]*K,p[3]*K,p[4]*K,p[5]*K,p[6]]);
MG(o,gM,[0,Y(-.09),Z(.088)],[mp[0]]);MG(o,gB,[0,Y(-.09),Z(.088)],[mp[1]]);o.ch=sd;o.chb=sd.position.z;o.cht=.068});
function knifeGeo(){const st=[[-.045,.0165,-.0165,1],[-.1,.0165,-.0165,1],[-.2,.0165,-.0162,1],[-.255,.0128,-.0125,.92],[-.29,.0068,-.0072,.6],[-.318,.0012,.0012,.05]],P=[],Ls=[];
for(const s of st){const t=s[1],e=s[2],m=Math.min(t,e+.011),w=.0026*s[3];Ls.push([[-w,t],[w,t],[w,m],[0,e],[-w,m]].map(p=>[p[0],p[1],s[0]]))}
for(let i=0;i<Ls.length-1;i++)for(let k=0;k<5;k++){const k1=(k+1)%5,A=Ls[i][k],B=Ls[i][k1],C=Ls[i+1][k1],D=Ls[i+1][k];P.push(A,B,C,A,C,D)}
const g=new THREE.BufferGeometry(),f=new Float32Array(P.length*9/3);P.forEach((p,i)=>{f[i*3]=p[0];f[i*3+1]=p[1];f[i*3+2]=p[2]});g.setAttribute('position',new THREE.BufferAttribute(f,3));g.computeVertexNormals();g.computeBoundingSphere();return g}
const KBG=knifeGeo(),KBM=new THREE.MeshStandardMaterial({color:LITE?0xe2e6ea:0xdfe4ea,metalness:LITE?.55:1,roughness:LITE?.3:.1,envMapIntensity:1.35});let KENV=null;
function knEnv(){if(KENV!==null||LITE)return;KENV=0;try{const W=256,H=128,c=document.createElement('canvas');c.width=W;c.height=H;const g=c.getContext('2d'),gr=g.createLinearGradient(0,0,0,H);gr.addColorStop(0,'#cfe2ff');gr.addColorStop(.48,'#f4f7fb');gr.addColorStop(.5,'#8a8f96');gr.addColorStop(1,'#1c1e22');g.fillStyle=gr;g.fillRect(0,0,W,H);g.fillStyle='#fff';g.fillRect(30,10,60,26);g.fillRect(150,16,26,34);g.fillRect(200,8,40,18);g.fillStyle='#0b0c0e';g.fillRect(90,50,18,40);g.fillRect(180,60,30,30);
const t=new THREE.CanvasTexture(c);t.mapping=THREE.EquirectangularReflectionMapping;t.encoding=THREE.sRGBEncoding;const pg=new THREE.PMREMGenerator(rd);pg.compileEquirectangularShader();const rt=pg.fromEquirectangular(t);pg.dispose();t.dispose();KBM.envMap=rt.texture;KBM.needsUpdate=true;KENV=rt}catch(e){KENV=0;KBM.metalness=.6;KBM.roughness=.28;KBM.needsUpdate=true}}
const KG={on:0,t:0,dir:-1,vis:0,h:[],gm:[],gs:[]},KP=[0,0,0,0,0,0];
for(let i=0;i<5;i++){const m=new THREE.MeshBasicMaterial({color:0xd8ecff,transparent:true,opacity:0,blending:THREE.AdditiveBlending,depthWrite:false,fog:false}),e=new THREE.Mesh(KBG,m);e.visible=false;e.frustumCulled=false;cam2.add(e);KG.gm.push(m);KG.gs.push(e)}
function slashFx(){KG.on=1;KG.t=0;KG.dir=-KG.dir;KG.h.length=0}
function slashPose(dt){KP[0]=KP[1]=KP[2]=KP[3]=KP[4]=KP[5]=0;if(!KG.on)return KP;if(wd.type!=='melee'){KG.on=0;return KP}KG.t+=dt;const t=KG.t;if(t>=.32){KG.on=0;return KP}
const d=KG.dir,p1=ss(0,.09,t),p2=ss(.09,.2,t),p3=ss(.2,.32,t),a=p1*(1-p2),b=p2*(1-p3);KP[0]=.1*d*a-.22*d*b;KP[1]=.05*a-.05*b;KP[2]=.06*a-.14*b;KP[3]=.45*a-.35*b;KP[4]=-.6*d*a+.8*d*b;KP[5]=-.5*d*a+.7*d*b;return KP}
function knifeTrail(){if(!KG.on){if(KG.vis){KG.vis=0;for(const e of KG.gs)e.visible=false}return}KG.h.push([gun.position.x,gun.position.y,gun.position.z,gun.rotation.x,gun.rotation.y,gun.rotation.z]);if(KG.h.length>8)KG.h.shift();
const v=ss(.07,.11,KG.t)*(1-ss(.2,.29,KG.t));KG.vis=v>.01?1:0;for(let i=0;i<KG.gs.length;i++){const e=KG.gs[i],q=KG.h[KG.h.length-2-i];if(!q||v<=.01){e.visible=false;continue}e.visible=true;e.position.set(q[0],q[1],q[2]);e.rotation.set(q[3],q[4],q[5]);KG.gm[i].opacity=v*.34*(1-i/5.5)}}
const kH=S(0x0a0a0c,.75,.08),kR=S(0x1a1b1e,.6,.1),kM=S(0x9aa0a8,.28,.9);
mkW('kn',(a,o)=>{a(KBG,KBM,0,0,0);a(Bx(.026,.034,.112),kH,0,-.004,.006);for(let i=0;i<7;i++)a(Bx(.0285,.0345,.0035),kR,0,-.004,-.036+i*.0155);a(Bx(.03,.036,.012),kM,0,-.004,.066);a(Bx(.052,.016,.012),kM,0,0,-.052);for(const s of[-1,1])a(Bx(.014,.018,.018),kM,s*.032,.002,-.054);o.ch=new THREE.Object3D();o.g.add(o.ch)});
mkW('snp',(a,o)=>{a(Bx(.054,.08,.3),gM,0,.015,0);a(Bx(.05,.03,.34),gM,0,.065,-.03);a(Bx(.058,.05,.41),gG,0,.01,-.345);a(Bx(.05,.022,.36),gG,0,.05,-.37);a(cylG(.0115,.6),gM,0,.035,-.8);a(cylG(.017,.08),gB,0,.035,-1.1);a(cylG(.012,.4),gM,0,.072,-.62);a(Bx(.022,.056,.04),gM,0,.054,-.8);
a(Bx(.03,.024,.2),gB,0,.086,-.03);a(cylG(.022,.26),gB,0,.116,-.04);a(cylG(.03,.05),gB,0,.116,-.18);a(cylG(.026,.04),gB,0,.116,.1);a(Bx(.02,.026,.02),gB,0,.14,-.04);
a(Bx(.04,.085,.43),gG,0,-.01,.355);a(Bx(.036,.12,.052),gG,0,-.085,.1).rotation.x=.3;a(Bx(.05,.063,.075),gB,0,-.0535,-.06);
MG(o,gM,[0,-.1,-.06],[[.04,.135,.07,0,.0175,0,0],[.04,.05,.07,0,-.07,-.02,.25]]);o.ch=a(Bx(.014,.016,.04),gM,.033,.05,.05);o.chb=.05;a(cylG(.0135,.34),gM,0,.035,-1.3);a(cylG(.03,.3),gB,0,.125,-.05);o.cht=.09;ejP(a,.0275,.03,-.04,.03,.09)});
const OM={m4:[.11,-.1],ak:[.092,-.05],lmg:[.092,-.05],smg:[.094,-.1],sg:[.055,-.04],pi:[.0642,-.031]},UBZ={m4:-.36,ak:-.34,lmg:-.34,dmr:-.38,snp:-.38},
ATC=[{k:'opt',n:'OPTIC',o:[['IRON',{}],['RED DOT',{oh:.04}],['HOLO',{oh:.048,spa:.9}],['ACOG 4X',{oh:.06,zm:.62,mv:.97}]],ok:id=>!!OM[id]},
{k:'mz',n:'MUZZLE',o:[['NONE',{}],['SUPPRESSOR',{al:.35,fs:.3,dmg:.94,mzl:.14}],['COMPENSATOR',{rk:.8,rh:.75,fs:1.2,al:1.1,mzl:.035}]],ok:id=>id!=='kn'},
{k:'ub',n:'UNDERBARREL',o:[['NONE',{}],['VERT GRIP',{rk:.88,rh:.8}],['ANGLED GRIP',{rh:.9,spa:.85,mv:1.02}],['LASER',{spr:.6}]],ok:id=>UBZ[id]!=null},
{k:'mg',n:'MAGAZINE',o:[['STANDARD',{}],['EXTENDED',{cap:1.5,rf:1.12,mv:.98}],['FAST MAG',{cap:.85,rf:.78}]],ok:id=>WD[id].type==='mag'}],
ATK=['cap','rk','rh','spr','spa','rf','al','fs','dmg','hd','mv','dr','zoom'],ATT0={};let ATT={};try{ATT=JSON.parse(localStorage.getItem('mo_att')||'{}')||{}}catch(e){}
for(const id in WD){const d=WD[id],b={};ATK.forEach(k=>b[k]=d[k]);b.ads=d.ads.slice();b.mz=d.mz.slice();b.dot=d.dot&&d.dot.slice();ATT0[id]=b}
const attSel=(id,k)=>{const a=ATT[id];return a&&a[k]|0},attSave=()=>{try{localStorage.setItem('mo_att',JSON.stringify(ATT))}catch(e){}};
function attBuild(){for(const id in WM){if(id==='kn')continue;const o=WM[id],d=WD[id],mz=d.mz,at={opt:[null],mz:[null],ub:[null]},a=(g,x,y,z)=>{const e=new THREE.Mesh(g,gB);e.position.set(x,y,z);e.visible=false;o.g.add(e);return e};
if(OM[id]){const r=OM[id];for(let t=1;t<4;t++){const G=new THREE.Group();G.position.set(0,r[0],r[1]);G.visible=false;o.g.add(G);
let L=[[.036,.01,.07,0,.005],[.006,.04,.05,-.017,.03],[.006,.04,.05,.017,.03]];
if(t===2)L=[[.04,.012,.085,0,.006],[.006,.05,.07,-.019,.037],[.006,.05,.07,.019,.037],[.044,.006,.07,0,.066]];
if(t===3)L=[[.04,.014,.13,0,.007],[.01,.07,.12,-.02,.045],[.01,.07,.12,.02,.045],[.05,.016,.13,0,.088]];
L.forEach(p=>{const e=new THREE.Mesh(Bx(p[0],p[1],p[2]),gB);e.position.set(p[3],p[4],0);G.add(e)});at.opt.push(G)}}
const s=id==='pi'?.6:1;at.mz.push(a(cylG(.024*s,.2),mz[0],mz[1],mz[2]-.04),a(cylG(.02*s,.07),mz[0],mz[1],mz[2]));
if(UBZ[id]!=null){const z=UBZ[id];at.ub.push(a(Bx(.024,.106,.03),0,-.062,z),a(Bx(.03,.04,.1),0,-.04,z-.02),a(Bx(.032,.036,.07),0,-.028,z))}o.at=at}}
function attApply(on){for(const id in WD){const d=WD[id],b=ATT0[id],M={},S={opt:0,mz:0,ub:0,mg:0};ATK.forEach(k=>d[k]=b[k]);d.ads=b.ads.slice();d.mz=b.mz.slice();d.dot=b.dot&&b.dot.slice();
if(on&&id!=='kn')for(const c of ATC){if(!c.ok(id))continue;const i=attSel(id,c.k);S[c.k]=i;const m=c.o[i]?c.o[i][1]:{};for(const k in m)M[k]=(k==='oh'||k==='mzl')?m[k]:(M[k]||1)*m[k]}
for(const k of['rk','rh','spr','spa','rf','al','fs','dmg','mv'])if(M[k])d[k]=b[k]*M[k];if(M.dmg)d.hd=b.hd*M.dmg;if(M.cap&&d.type==='mag')d.cap=Math.max(1,Math.round(b.cap*M.cap));if(M.zm)d.zoom=b.zoom*M.zm;
if(M.oh&&OM[id]){const r=OM[id];d.ads[1]=-(r[0]+M.oh)+.003;d.dot=[0,r[0]+M.oh,r[1]]}if(M.mzl)d.mz[2]=b.mz[2]-M.mzl;
const o=WM[id];if(o&&o.at){for(const k in o.at)o.at[k].forEach((m,i)=>{if(m)m.visible=i===S[k]});const e=S.mg===1&&d.type==='mag'?1.4:1;o.mag.scale.y=e;o.nm.scale.y=e}
skinApply(id,on?Math.min(attSel(id,'skin'),skinTier(id)):0);if(d.type==='mag')relBuild(id)}}
const SKN=[['STOCK',0,null],['DESERT',8,0xb5975a],['ARCTIC',20,0xdce4ec],['GOLD',45,0xd4af37],['CRIMSON',90,0xa01c1c]],SKM={},
WK=(()=>{try{return JSON.parse(localStorage.getItem('mo_wk')||'{}')||{}}catch(e){return{}}})();
function wkSave(){try{localStorage.setItem('mo_wk',JSON.stringify(WK))}catch(e){}}
function skinTier(id){const k=WK[id]|0;let t=0;SKN.forEach((q,i)=>{if(k>=q[1])t=i});return t}
function skinMat(i,orig){const dk=orig===gB||orig===pG,key=i+(dk?'b':'m');return SKM[key]||(SKM[key]=new THREE.MeshStandardMaterial({color:new THREE.Color(SKN[i][2]).convertSRGBToLinear().multiplyScalar(dk?.45:1),roughness:i===3?.22:.4,metalness:i===3?.95:.6,envMapIntensity:.6}))}
function skinApply(id,i){const o=WM[id];if(!o)return;const f=m=>m.traverse(q=>{if(!q.isMesh)return;if(q.userData.om===undefined)q.userData.om=(q.material===gM||q.material===gB||q.material===pM||q.material===pG)?q.material:null;if(q.userData.om)q.material=i?skinMat(i,q.userData.om):q.userData.om});f(o.g);f(o.nm)}
function wkAdd(id){const o=skinTier(id);WK[id]=(WK[id]|0)+1;const n=skinTier(id);if(n>o){pop('SKIN UNLOCKED \u00b7 '+SKN[n][0]+' '+WD[id].s);(ATT[id]=ATT[id]||{}).skin=n;attSave();skinApply(id,n)}wkSave()}
attBuild();
for(const id in WM){const d=WD[id],o=WM[id];if(d.type==='mag'&&o.mag)o.nm.position.set(o.mag.position.x-d.well[0],o.mag.position.y-d.well[1]+.02,o.mag.position.z-d.well[2])}
let prevOn=0,atW='m4';
function lobPrev(on){if(on){lh.visible=false;dotS.visible=false;gun.visible=true;gun.scale.setScalar(.85);for(const k in WM)WM[k].g.visible=k===atW}else if(prevOn){gun.visible=false;lh.visible=true;gun.scale.setScalar(1)}prevOn=on?1:0;rdDirty=true}
function stBar(l,v){const q=document.createElement('div');q.className='st';q.innerHTML='<span>'+l+'</span><div class="bar"><i style="width:'+clamp(v,4,100).toFixed(0)+'%"></i></div>';return q}
function lobLoad(el){attApply(1);const mw=LW[lobMi]||'smg',ids=['m4','ak','lmg','smg','sg','dmr','snp','pi'];el.innerHTML='<div class="kick">ARMORY</div><h3 class="mt">WEAPON CUSTOMIZATION</h3>';
const sw=document.createElement('div');sw.className='seg';ids.forEach(id=>{const b=document.createElement('button');b.className='sm'+(id===atW?' on':'');b.textContent=(id===mw?'\u2605 ':'')+WD[id].s;b.onclick=()=>{atW=id;lobUI()};sw.appendChild(b)});el.appendChild(sw);
const d=WD[atW],t=document.createElement('div');t.className='ob';t.style.cssText='padding:8px 0 2px;color:var(--acc);letter-spacing:.1em';t.textContent=d.n+(atW===mw?'  (MISSION WEAPON)':'');el.appendChild(t);
ATC.forEach(c=>{if(!c.ok(atW))return;const r=mkRow(c.n),g=document.createElement('div');g.className='seg';c.o.forEach((o,i)=>{const b=document.createElement('button');b.className='sm'+(attSel(atW,c.k)===i?' on':'');b.textContent=o[0];b.onclick=()=>{(ATT[atW]=ATT[atW]||{})[c.k]=i;attSave();lobUI()};g.appendChild(b)});r.appendChild(g);el.appendChild(r)});
{const r=mkRow('CAMO SKIN'),g=document.createElement('div');g.className='seg';const un=skinTier(atW);SKN.forEach((q,i)=>{const b=document.createElement('button');b.className='sm'+(Math.min(attSel(atW,'skin'),un)===i?' on':'');b.disabled=i>un;b.textContent=i>un?q[0]+' ('+q[1]+'K)':q[0];b.onclick=()=>{(ATT[atW]=ATT[atW]||{}).skin=i;attSave();lobUI()};g.appendChild(b)});r.appendChild(g);el.appendChild(r);
const t2=document.createElement('div');t2.className='ob';t2.style.cssText='opacity:.6;font-size:11px;padding:2px 0 4px';t2.textContent='KILLS WITH '+WD[atW].s+': '+(WK[atW]|0);el.appendChild(t2)};
[['DAMAGE',Math.sqrt(d.dmg*d.pel/180)*100],['RECOIL CTRL',100-d.rk*1400],['ACCURACY',100-d.spr*4500],['MAGAZINE',d.cap/75*100+10],['RELOAD',55/d.rf],['MOBILITY',(d.mv-.8)/.3*100],['STEALTH',100-d.al*1.6]].forEach(x=>el.appendChild(stBar(x[0],x[1])));
const rs=document.createElement('button');rs.className='sm';rs.textContent='RESET ATTACHMENTS';rs.onclick=()=>{delete ATT[atW];attSave();lobUI()};el.appendChild(rs)}
const LO={s0:'m4',s2:'sg'};try{const o=JSON.parse(localStorage.getItem('mo_lo')||'null');if(o){if(['m4','ak','lmg'].includes(o.s0))LO.s0=o.s0;if(['sg','dmr'].includes(o.s2))LO.s2=o.s2}}catch(e){}
let WS=null,wd=null,cw=null,cs=0,ps=1,wbSig='',rlTxt='',rlPg=-1,pkLbl='',pkTip=0,nearPk=null;const SL=[null,null,null];
const zf=()=>{if(ads<.02)return 1;const r=Math.tan(cam.fov*PI/360)/Math.tan(CFG.fov*PI/360);return Math.pow(Math.min(1,r),.75)*lerp(1,CFG.adsS,ads)},TOUCHD='ontouchstart' in window||navigator.maxTouchPoints>0;
const wTotal=w=>{const d=WD[w.id];return w.ammo+w.ch+(d.type==='mag'?w.mags.reduce((s,m)=>s+m,0):w.rsv)};
function mkWS(id){const d=WD[id];return d.type==='mag'?{id,ammo:d.cap,ch:1,mags:new Array(d.mag0).fill(d.cap),rsv:0,nomag:0}:{id,ammo:d.cap,ch:1,mags:[],rsv:d.rsv0,nomag:0}}
const wbar=$('wbar'),wbs=[];for(let i=0;i<3;i++){const b=document.createElement('button');b.className='wb';b.addEventListener('touchstart',e=>{e.preventDefault();e.stopPropagation();switchTo(i)},{passive:false});b.addEventListener('click',()=>switchTo(i));wbar.appendChild(b);wbs.push(b)}
function refreshSlots(){if(WS)$('swb').innerHTML='SWITCH<br>'+WD[WS.id].s;for(let i=0;i<3;i++){const w=SL[i],b=wbs[i];if(!w){b.textContent='';continue}b.innerHTML=(i+1)+'<br>'+WD[w.id].s;b.classList.toggle('on',i===cs);b.classList.toggle('lo',wTotal(w)===0)}}
function selectSlot(i){if(i!==cs)ps=cs;cs=i;WS=SL[i];wd=WD[WS.id];for(const k in WM){WM[k].g.visible=false;WM[k].nm.visible=false}cw=WM[WS.id];cw.g.visible=true;if(WS.id==='kn')knEnv();cw.mag.visible=!WS.nomag;
muz.position.set(wd.mz[0],wd.mz[1],wd.mz[2]);fm.position.set(wd.mz[0],wd.mz[1],wd.mz[2]-.03);fm.scale.set(wd.fs,wd.fs,1);gFlash.position.set(wd.mz[0],wd.mz[1],wd.mz[2]-.05);
if(wd.dot)dotS.position.set(wd.dot[0],wd.dot[1],wd.dot[2]);dotS.visible=!!wd.dot;bolt=0;refreshSlots()}
const LW=['smg','m4','snp','ak','snp','smg','snp','m4','smg','smg','m4','m4','smg','smg','ak'];
function giveLoadout(){attApply(1);if(cur&&cur.lo){SL[0]=mkWS(cur.lo[0]);SL[1]=mkWS(cur.lo[1]);SL[2]=mkWS(cur.lo[2]);cs=0;ps=1;selectSlot(0);resetGun();return}SL[0]=mkWS('kn');SL[1]=mkWS('pi');SL[2]=mkWS(LW[mi]||'smg');cs=2;ps=1;selectSlot(2);resetGun()}
function refillAll(){for(const w of SL){const d=WD[w.id];w.ammo=d.cap;w.ch=1;w.nomag=0;if(d.type==='mag'){while(w.mags.length<d.mag0)w.mags.push(d.cap)}else w.rsv=Math.max(w.rsv,d.rsv0)}resetGun()}
function startLoad(){nGren=Math.max(nGren,3);if(keepLoad&&SL[0]&&!(cur&&cur.lo))refillAll();else giveLoadout();keepLoad=0}
function resup(){nGren=Math.min(5,nGren+2);for(const w of SL){const d=WD[w.id];if(d.type==='mag'){for(let i=0;i<d.sup&&w.mags.length<d.mmax;i++)w.mags.push(d.cap)}else w.rsv=Math.min(d.rmax,w.rsv+d.rsup)}refreshSlots()}
function gunKick(){const a=(ads>.5?.45:1)*wd.kz;gh.zv+=.55*a;gh.pv+=1.5*a;gh.yv+=(R()-.5)*1.4*a;gh.rv+=(R()-.5)*3*a}
function resetGun(){bloom=0;arT=0;rcAcc=rcAccY=rcN=0;rcT=9;gh.draw=1;rl.on=0;rl.t=0;rl.nmag=null;swp.on=0;pmp.on=0;chq.on=0;bolt=0;act.on=0;act.lw=0;act.dip=0;if(SL[cs])selectSlot(cs)}
function finishPump(){if(pmp.on){pmp.on=0;if(WS.ch===0&&WS.ammo>0){WS.ammo--;WS.ch=1}}}
function cancelReload(){if(!rl.on)return;if(rl.nmag!=null){WS.mags.push(rl.nmag);rl.nmag=null}rl.on=0;rl.t=0;cw.nm.visible=false;cw.mag.visible=!WS.nomag}
function switchTo(i,force){if(!run||paused||!SL[i]||swp.on||act.on||(i===cs&&!force))return;cancelReload();finishPump();chq.on=0;adsOn=false;swp.on=1;swp.t=0;swp.to=i;sClick(.35,500)}
function swUpd(dt){if(swp.on){swp.t+=dt;gh.draw=ss(0,.2,swp.t);if(swp.t>=.2){selectSlot(swp.to);swp.on=0;gh.draw=1;gh.pv-=1.1;gh.zv+=.25;sClick(.4,600);nz(.04,2500,900,.12)}}else gh.draw=Math.max(0,gh.draw-dt*2.6*wd.dr)}
function canReload(){if(!WS||act.on||rl.on||swp.on||pmp.on||chq.on)return false;if(wd.type==='mag'){if(!WS.mags.length)return false;return Math.max.apply(null,WS.mags)>WS.ammo&&WS.ammo<wd.cap}return WS.rsv>0&&WS.ammo<wd.cap}
function doReload(){if(!run||!canReload())return;rl.on=1;rl.t=0;rl.ev={};rl.nmag=null;rl.done=0;rl.sh=wd.type==='shell'?1:0;adsOn=false;
if(rl.sh){rl.n=Math.min(wd.cap-WS.ammo+(WS.ch?0:1),WS.rsv);rl.tot=(.6+rl.n*.72)*wd.rf*1.2;rl.empty=0}else{rl.empty=WS.ch===0?1:0;rl.tot=rl.empty?wd.tE:wd.tT}
if(R()<.3)radio('SGT. KHAN','Reloading! Cover me!')}
function relEvent(n){
if(n==='drop'){if(!WS.nomag){if(WS.ammo>0)WS.mags.push(WS.ammo);WS.ammo=0;WS.nomag=1;cw.mag.visible=false;if(rl.empty)dropMag();else cw.nm.visible=true}sMagOut()}
else if(n==='stow'){cw.nm.visible=false;sClick(.3,350);nz(.1,1200,300,.18)}
else if(n==='grab'){let b=-1,bv=0;WS.mags.forEach((m,i)=>{if(m>bv){bv=m;b=i}});if(b>=0){rl.nmag=WS.mags.splice(b,1)[0];cw.nm.visible=true}sClick(.3,500)}
else if(n==='insert'){cw.nm.visible=false;if(rl.nmag!=null){WS.ammo=rl.nmag;rl.nmag=null;WS.nomag=0;cw.mag.visible=true}sMagIn();if(!rl.empty)setTimeout(sCock,230*wd.rf)}
else if(n==='rack'){if(WS.ammo>0&&WS.ch===0){WS.ammo--;WS.ch=1}sRack()}else if(n==='release'){sCock()}}
function shellIn(){if(WS.rsv<=0)return;WS.rsv--;if(WS.ch===0)WS.ch=1;else WS.ammo++;sClick(.45,380);nz(.05,3500,900,.25)}
function startChamber(){if(wd.type==='shell'){pmp.on=1;pmp.t=0;pmp.e1=pmp.e2=0;return}chq.on=1;chq.t=0;chq.fed=0}
function gunAnim(dt){const d=wd,H=d.hold;let lx=H[0],ly=H[1],lz=H[2],drz=0,drx=0,op=0;bolt=Math.max(0,bolt-dt*8);
if(rl.on&&!rl.sh){rl.t+=dt;const F=rl.empty?d.FE:d.FT,p=kf(F,rl.t),f=d.rf*1.2;lx=p[0];ly=p[1];lz=p[2];drz=p[3];drx=p[4];
for(const e of(rl.empty?d.EE:d.ET))if(!rl.ev[e[1]]&&rl.t>=e[0]){rl.ev[e[1]]=1;relEvent(e[1])}
if(rl.empty){const q=rl.t/f;op=q<1.98?1:q<2.12?1+.4*ss(1.98,2.12,q):1.4*(1-ss(2.12,2.2,q))}if(rl.t>=F[F.length-1][0]){rl.on=0;cw.mag.visible=!WS.nomag;cw.nm.visible=false}}
else if(rl.on&&rl.sh){rl.t+=dt;const f=d.rf*1.2,Pt=d.well,V=[-.2,-.5,0],o_=.3*f,cy=.72*f,n=rl.n,tt=rl.t,end=o_+n*cy;let p;
const SH=[[0,H[0],H[1],H[2],.4,-.1],[.24,V[0],V[1],V[2],.5,-.14],[.51,Pt[0],Pt[1],Pt[2],.5,-.18],[.73,Pt[0],Pt[1],Pt[2],.5,-.18],[.96,H[0],H[1],H[2],.4,-.1],[1,H[0],H[1],H[2],.4,-.1]];
if(tt<o_){p=kf([[0,H[0],H[1],H[2],0,0],[o_,H[0],H[1],H[2],.4,-.1]],tt);cw.nm.visible=false}
else if(tt<end){const ph=((tt-o_)%cy)/cy;p=kf(SH,ph);cw.nm.visible=ph>.2&&ph<.66;{const ins=ss(.52,.66,ph);cw.nm.position.set(0,ins*.04,-ins*.03)}while(rl.done<n&&tt>=o_+rl.done*cy+.66*cy){rl.done++;shellIn()}}
else{p=kf([[0,H[0],H[1],H[2],.4,-.1],[.3*f,H[0],H[1],H[2],0,0]],tt-end);cw.nm.visible=false;while(rl.done<n){rl.done++;shellIn()}if(tt-end>=.3*f)rl.on=0}
lx=p[0];ly=p[1];lz=p[2];drz=p[3];drx=p[4]}
else if(chq.on){chq.t+=dt;const C=d.chp,p=kf([[0,H[0],H[1],H[2],0,0],[.14,C[0],C[1],C[2],.25,.08],[.3,C[0],C[1],C[2],.25,.08],[.5,H[0],H[1],H[2],0,0]],chq.t);lx=p[0];ly=p[1];lz=p[2];drz=p[3];drx=p[4];
if(!chq.fed&&chq.t>=.2){chq.fed=1;if(WS.ammo>0&&WS.ch===0){WS.ammo--;WS.ch=1}sClick(.7,260)}op=chq.t<.2?ss(.1,.2,chq.t):1-ss(.2,.3,chq.t);if(chq.t>=.5)chq.on=0}
else if(pmp.on){pmp.t+=dt;const t=pmp.t;op=ss(.06,.2,t)-ss(.3,.42,t);if(!pmp.e1&&t>=.16){pmp.e1=1;ejectCase(1);sClick(.6,250);nz(.04,2500,600,.3)}
if(!pmp.e2&&t>=.36){pmp.e2=1;sClick(.7,200);if(WS.ammo>0&&WS.ch===0){WS.ammo--;WS.ch=1}}if(t>=.5)pmp.on=0}
else op=Math.max(bolt*d.bk,(d.type==='mag'&&WS.ch===0&&WS.ammo===0)?1:0);
{const near=Math.hypot(lx-H[0],ly-H[1],lz-H[2])<.07,pis=WS.id==='pi',mel=d.type==='melee';trigK=Math.max(0,trigK-dt*5);lh.visible=!prevOn&&!mel;HR.lC.visible=near&&!pis;HR.lP.visible=near&&pis;HR.lF.visible=!near;HR.rH.visible=!mel;HR.rK.visible=mel;HR.ix.rotation.x=-.55*Math.min(1,trigK*2.5)}
lh.position.set(lx,ly,lz+(d.type==='shell'?op*cw.cht:0));cw.ch.position.z=cw.chb+cw.cht*op;return[drz,drx]}
function fireLogic(){if(!firing)semiOK=true;if(!firing||swp.on||act.on||sprint||mant.on||fireT>0||(PV.on&&PV.frz))return;
if(rl.on){if(rl.sh&&WS.ch>0)cancelReload();else return}if(pmp.on||chq.on)return;
if(WS.ch>0){if((wd.auto&&!SEMI[WS.id])||semiOK){shoot();fireT=wd.rate;semiOK=false}return}
if(WS.ammo>0){startChamber();return}
const has=wd.type==='mag'?WS.mags.length>0:WS.rsv>0;if(has){if(semiOK||(wd.auto&&!SEMI[WS.id]))doReload();semiOK=false;return}
if(semiOK){sClick(.6,900);fireT=.3;semiOK=false;pop('NO AMMO')}}
let scSwT=0,scBr=1,scHold=false,scExh=0,scX=0,scY=0,scBtn=0,scLast=0,scAv='';const scZi={};
const SMAG={dmr:[3.5,5.5],snp:[4,8,12]},ADSK={m4:470,ak:420,lmg:260,smg:620,sg:400,dmr:210,snp:130,pi:740,kn:520};
const SWK=()=>[0,.5,1][CFG.sway==null?2:CFG.sway];
function scopeMag(){const L=wd&&wd.scope&&SMAG[WS.id];return L?L[scZi[WS.id]|0]:0}
function stepZoom(d){if(!wd||!wd.scope||ads<.5)return;const L=SMAG[WS.id];if(!L||L.length<2)return;const o=scZi[WS.id]|0,i=d===0?(o+1)%L.length:clamp(o+d,0,L.length-1);if(i!==o){scZi[WS.id]=i;sClick(.3,1400)}}
function scopeSway(dt){const sc=wd.scope?1:0,A=ads*(sc?1:.35)*SWK();
const want=sc&&SWK()>0&&(scHold||k.ShiftLeft)&&ads>.9&&scExh<=0&&scBr>0;
if(want){scBr=Math.max(0,scBr-dt/4.5);if(scBr<=0)scExh=2.4}else{if(scExh>0)scExh=Math.max(0,scExh-dt);scBr=Math.min(1,scBr+dt/(scExh>0?7:3.5))}
if(A<.001){scX=scY=0;return}
scSwT+=dt;const t=scSwT,hold=want?.1+.5*(1-scBr)*(1-scBr):1,amp=.0042*hold*(scExh>0?2.1:1)*(moving&&P.ground?2.4:1)*(P.ground?1:4);
const bx=Math.sin(t*.83)*.55+Math.sin(t*1.77+1.3)*.3+Math.sin(t*3.9+.4)*.12,by=Math.sin(t*1.45)*.75+Math.sin(t*1.1+.7)*.3+Math.sin(t*4.3+2)*.1;
const hb=Math.pow(Math.max(0,Math.sin(t*7.85)),8)*.0011*(1+(1-scBr)*2.5)*sc;
scX=bx*amp*A;scY=(by*amp+hb)*A}
function scopeUI(){const e=$('scp'),av=$('adsv');
if(wd.scope){e.style.opacity=ss(.55,.92,ads);scopeOn=ads>.93;if(scAv!=='0'){scAv='0';av.style.opacity=0}
const mg=scopeMag();if(mg!==scLast){scLast=mg;$('scpz').textContent=mg+'\u00d7'}
$('scpv').style.transform='translate('+(-gh.sx*260).toFixed(1)+'px,'+(gh.sy*260+kick*7).toFixed(1)+'px)';
$('scpv').style.setProperty('--sv',((scHold||k.ShiftLeft)&&scExh<=0&&ads>.9?(1-scBr)*16:scExh>0?10:0).toFixed(1)+'%');
const b=$('scpb').firstChild.style;b.width=(scBr*100).toFixed(0)+'%';b.background=scExh>0?'#e0604a':'#dfe6c8';
const sh=TOUCHD&&ads>.8?1:0;if(sh!==scBtn){scBtn=sh;$('brb').style.display=sh?'block':'none';$('zmb').style.display=sh&&SMAG[WS.id]&&SMAG[WS.id].length>1?'block':'none'}}
else{scopeOn=false;if(e.style.opacity!=='0')e.style.opacity=0;if(scBtn){scBtn=0;$('brb').style.display=$('zmb').style.display='none'}
const v=wd.type==='melee'?'0':(ads*.9).toFixed(2);if(v!==scAv){scAv=v;av.style.opacity=v}}}
let hapT=0,fmS='',grS='',lhT=0,lhB=-1,cvLast=0;const SEMI={};
function hitMk(head){hmT=1;sHitMk(head);hap(30,1)}
function hapDeath(){if(CFG.hap&&navigator.vibrate){try{navigator.vibrate([50,50,50])}catch(e){}}}
function hap(p,f){if(!CFG.hap||!navigator.vibrate)return;const n=performance.now();if(!f&&n-hapT<60)return;hapT=n;try{navigator.vibrate(p)}catch(e){}}
function whiz(){tn(3400,1200,.09,.16,'sawtooth');shake=Math.max(shake,.1);hap(6)}
function toggleMode(){if(!run||paused||!wd||!wd.auto)return;SEMI[WS.id]=!SEMI[WS.id];pop('FIRE MODE: '+(SEMI[WS.id]?'SEMI':'AUTO'));sClick(.4,700)}
function uiExtra(){const f=wd&&wd.auto?(SEMI[WS.id]?'SEMI':'AUTO'):'';if(f!==fmS){fmS=f;const b=$('fmb');b.style.display=f?'block':'none';b.textContent=f}
const g='GRENADE\n'+nGren;if(g!==grS){grS=g;$('grb').textContent=g}}
function lowHP(dt){const hp=P.hp,b=hp>0&&hp<35?Math.ceil(hp/10):0;if(b!==lhB){lhB=b;rd.domElement.style.filter=b?'saturate('+(.45+.15*b).toFixed(2)+') contrast(1.08)':''}
if(b){lhT-=dt;if(lhT<=0){lhT=.55+hp/70;tn(70,45,.14,.4);setTimeout(()=>tn(65,40,.12,.28),150);hap([30,90,20])}}}
function tryCover(e,tg){const u=e.userData,now=performance.now();if(now-cvLast<120)return;cvLast=now;u.cvN=5+R()*4;const ex=e.position.x,ez=e.position.z,dc=Math.hypot(ex-tg.x,ez-tg.z);let best=null,bd=1e9;
for(let i=0;i<8;i++){const a=R()*6.28,r=4+R()*5,px=ex+Math.cos(a)*r,pz=ez+Math.sin(a)*r;if(Math.abs(px)>72||Math.abs(pz)>72||hitBox(px,pz,.7))continue;if(Math.hypot(px-tg.x,pz-tg.z)>dc+4)continue;if(los(px,1.5,pz,tg.x,tg.y,tg.z))continue;if(r<bd){bd=r;best={x:px,z:pz}}}
if(best){u.cv=best;u.cvT=1.8+R()*2.2}}
function uiRl(){const e=$('rlw'),t=$('rlt'),b=$('rlbi');let txt='',pg=-1;
if(rl.on){txt=rl.sh?'LOADING SHELLS':(rl.empty?'RELOADING · EMPTY':'RELOADING');pg=clamp(rl.t/rl.tot,0,1)}else if(chq.on){txt='CHAMBERING';pg=clamp(chq.t/.5,0,1)}
else{const tot=wTotal(WS),cnt=WS.ammo+WS.ch;if(tot===0)txt='NO AMMO';else if(cnt===0)txt='RELOAD [R]';else if(cnt<=Math.max(2,wd.cap*.25|0)&&cnt<tot)txt='LOW AMMO'}
if(txt!==rlTxt){rlTxt=txt;t.textContent=txt;e.style.display=txt?'block':'none'}
if(pg>=0){b.parentNode.style.display='block';b.style.width=(pg*100)+'%'}else if(rlPg>=0)b.parentNode.style.display='none';rlPg=pg}
const aG=new THREE.Group();aG.visible=false;cam2.add(aG);
function mkArm(side){const g=new THREE.Group();const h=new THREE.Mesh(handGeo(side,'relax'),handMat(HSKIN_P));g.add(h);const fa=new THREE.Mesh(new THREE.BoxGeometry(.078,.085,.55),sl);fa.position.set(0,0,.37);g.add(fa);g.userData.h=h;return g}
const aRA=mkArm(1),aLA=mkArm(-1);aG.add(aRA);aG.add(aLA);
const aKit=new THREE.Group(),aKB=new THREE.Mesh(new THREE.BoxGeometry(.17,.07,.12),mt('white')),aLid=new THREE.Group();
{aKit.add(aKB);aLid.position.set(0,.035,-.06);const lm=new THREE.Mesh(new THREE.BoxGeometry(.17,.025,.12),mt('white'));lm.position.set(0,.0125,.06);aLid.add(lm);for(const r of[0,PI/2]){const c=new THREE.Mesh(new THREE.BoxGeometry(.07,.006,.02),mt('red'));c.position.set(0,.028,.06);c.rotation.y=r;aLid.add(c)}aKit.add(aLid);aG.add(aKit)}
const aRoll=new THREE.Mesh(new THREE.CylinderGeometry(.028,.028,.07,12),mt('white'));aRoll.rotation.x=PI/2;aRoll.visible=false;aRA.add(aRoll);aRoll.position.set(0,.05,-.07);
const aBand=new THREE.Mesh(new THREE.CylinderGeometry(.05,.05,.1,14,1,true),mt('white'));aBand.rotation.x=PI/2;aBand.position.set(0,0,.2);aBand.visible=false;aLA.add(aBand);
const aBM=aBand.material;
function startAct(type,fn){cancelReload();finishPump();chq.on=0;adsOn=false;gAim=0;act.on=1;act.t=0;act.type=type;act.fn=fn;act.d=0;act.s=0;act.dur=type==='med'?1.9:.8;aG.visible=true;aRoll.visible=false;aBand.visible=false;aKit.visible=type==='med';aRA.visible=true;aLA.visible=type==='med'}
function actUpd(dt){if(!act.on){act.lw=0;act.dip=0;if(aG.visible)aG.visible=false;return}
if(!run||P.hp<=0){act.on=0;return}
act.t+=dt;const t=act.t,T=act.dur;
if(act.type==='pick'){
 act.lw=ss(0,.18,t)-ss(.5,.76,t);
 const rc=ss(.06,.3,t)-ss(.42,.7,t),gp=ss(.26,.34,t)-ss(.36,.5,t);
 aRA.position.set(lerp(.3,.1,rc),lerp(-.55,-.2,rc),lerp(-.3,-.44,rc));aRA.rotation.set(lerp(.5,-.25,rc),lerp(-.3,.1,rc),lerp(.2,0,rc));aRA.userData.h.scale.set(1,1-gp*.35,1-gp*.2);
 if(!act.d&&t>=.3){act.d=1;if(act.fn)act.fn();hap(25)}
 if(!act.s&&t>=.5){act.s=1;gh.pv-=1.0;sClick(.4,520)}
}else{
 act.lw=ss(0,.22,t)-ss(1.55,1.88,t);
 const ku=ss(.14,.46,t)-ss(1.4,1.7,t),lo=ss(.46,.72,t)-ss(1.28,1.42,t);
 aKit.position.set(lerp(0,.02,ku),lerp(-.45,-.13,ku),lerp(-.3,-.42,ku));aKit.rotation.set(lerp(1.0,.45,ku),0,0);aLid.rotation.x=-1.9*lo;
 const hl=ss(.18,.46,t)-ss(1.45,1.78,t),wr=ss(.82,1.26,t),rl_=ss(.62,.82,t)-ss(1.3,1.38,t);
 aLA.position.set(lerp(-.32,-.12,hl),lerp(-.55,-.21,hl),lerp(-.3,-.4,hl));aLA.rotation.set(lerp(.5,-.12,hl),lerp(.3,-.15,hl),lerp(-.2,0,hl));
 const wob=Math.sin(t*17)*.025*wr*(1-ss(1.2,1.3,t));
 aRA.position.set(lerp(.32,lerp(.03,-.1,wr),hl)+wob,lerp(-.55,lerp(-.17,-.2,wr),hl),lerp(-.3,-.42,hl));aRA.rotation.set(lerp(.5,-.2,hl),lerp(-.3,.25,hl),lerp(.2,0,hl));
 aRoll.visible=rl_>.02;aRoll.rotation.z+=dt*22*wr;aRoll.scale.setScalar(1-wr*.45);
 aBand.visible=wr>.03;aBand.scale.set(1,wr,1);aBand.position.z=.12+wr*.1;
 if(!act.s&&t>=.46){act.s=1;sClick(.5,700)}
 if(act.s===1&&t>=.9){act.s=2;nz(.25,3200,1200,.18)}
 if(!act.d&&t>=1.26){act.d=1;if(act.fn)act.fn()}
}
act.dip=-.05*Math.sin(PI*clamp(t/T,0,1));
if(t>=T){act.on=0;act.lw=0;act.dip=0;aG.visible=false}}
let mkN=2,mkLT='';
function placeKits(){if(!cur||cur.uav||cur.nokits)return;const sp=[],near=(x,z)=>sp.some(q=>Math.hypot(q[0]-x,q[1]-z)<22)||Math.hypot(x-cur.start[0],z-cur.start[1])<18;
for(const q of CRT.slice().sort(()=>R()-.5)){if(sp.length>=5)break;if(Math.abs(q.x)>70||Math.abs(q.z)>70||near(q.x,q.z))continue;sp.push([q.x,q.z,q.y])}
if(sp.length<3)for(let i=1;i<wpts.length&&sp.length<5;i++){const w=wpts[i],x=w[0]+5,z=w[1]+4;if(near(x,z)||!freeAt(x,z,false))continue;box(x,z,1.3,1.3,1.3,mt('crate'),1.3);sp.push([x,z,1.3])}
kitTip=1;for(const q of sp){addKit(q[0],q[1],q[2]);const k=kits[kits.length-1];k.life=1e9;k.fx=1}}
function useKit(){if(!run||paused||cin||PV.on||UA.on||FL.on||act.on||swp.on||mant.on)return;if(mkN<=0){pop('NO MEDKITS LEFT');return}if(P.hp>=100||P.hp<=0){pop('HEALTH IS FULL');return}mkN--;
startAct('med',()=>{if(P.hp<=0)return;const h=Math.min(35,100-P.hp);if(h<=0)return;P.hp+=h;hitFlash=0;pop('+'+Math.round(h)+' HP · MEDKIT · '+mkN+' LEFT');tn(520,880,.18,.3);setTimeout(()=>tn(880,1100,.14,.25),120);hap([20,40,20])})}
function mkLbl(){const t='MEDKIT\n'+mkN,e=$('mkb'),h=$('mkh');if(t===mkLT)return;mkLT=t;if(e)e.textContent=t;if(h)h.textContent='MEDKIT x'+mkN+' [H]'}
{const h=document.createElement('div');h.id='mkh';$('hud').appendChild(h);const b=$('mkb');b.addEventListener('touchstart',e=>{e.preventDefault();e.stopPropagation();useKit()},{passive:false});b.addEventListener('touchend',e=>e.preventDefault(),{passive:false});b.addEventListener('mousedown',e=>e.stopPropagation());b.addEventListener('click',useKit);addEventListener('keydown',e=>{if(e.code==='KeyH'&&!e.repeat)useKit()})}
const kits=[],kitG=new THREE.BoxGeometry(.5,.3,.36),kitCG=new THREE.BoxGeometry(.28,.04,.08);let kitTip=0;
function addKit(x,z,y){const g=new THREE.Group();g.add(new THREE.Mesh(kitG,mt('white')));for(const r of[0,PI/2]){const c=new THREE.Mesh(kitCG,mt('red'));c.position.y=.16;c.rotation.y=r;g.add(c)}g.position.set(x,y+.35,z);sc.add(g);
const spr=mkSpr(tSpr,0x55ff88,1,1.1);spr.position.set(x,y+.45,z);sc.add(spr);kits.push({g,spr,x,z,y0:y,t:R()*6,life:45});if(kits.length>5)rmKit(kits[0]);
if(!kitTip){kitTip=1;pop('MEDKIT DROPPED - walk over it to heal')}}
function rmKit(k){sc.remove(k.g);sc.remove(k.spr);const i=kits.indexOf(k);if(i>=0)kits.splice(i,1)}
function dropKit(e){return;const u=e.userData,ch=u.kind==='boss'?1:u.kind==='heavy'?.5:.14+(P.hp<60?.15:0);if(R()>ch)return;let x=e.position.x+(R()-.5),z=e.position.z+(R()-.5);if(hitBox(x,z,.3)){x=e.position.x;z=e.position.z}addKit(x,z,groundAt(x,z,.6))}
function kitUI(dt){mkLbl();for(let i=kits.length-1;i>=0;i--){const k=kits[i];k.t+=dt;k.life-=dt;if(k.life<=0){rmKit(k);continue}k.g.position.y=k.y0+.35+Math.sin(k.t*2.4)*.06;k.g.rotation.y+=dt*1.4;k.spr.position.y=k.g.position.y+.1;k.spr.material.opacity=k.life<8?(Math.sin(k.t*14)>0?.8:.1):.5+.3*Math.sin(k.t*3);
if(P.hp<100&&P.hp>0&&!act.on&&!swp.on&&!mant.on&&Math.hypot(k.x-P.x,k.z-P.z)<(k.fx?2.4:1.7)&&Math.abs(k.y0-(P.y-1.7))<(k.fx?4.2:1.5)){rmKit(k);startAct('med',()=>{if(P.hp<=0)return;const h=Math.min(35,100-P.hp);if(h<=0)return;P.hp+=h;hitFlash=0;pop('+'+Math.round(h)+' HP · MEDKIT');tn(520,880,.18,.3);setTimeout(()=>tn(880,1100,.14,.25),120);hap([20,40,20])})}}}
const pks=[],pkRG=new THREE.RingGeometry(.5,.62,32),pkRM=new THREE.MeshBasicMaterial({color:0xffd060,transparent:true,opacity:.75,blending:THREE.AdditiveBlending,depthWrite:false,side:THREE.DoubleSide,fog:false});pkRG.rotateX(-PI/2);
function addPk(id,x,z,y,st){const m=WM[id].g.clone(true);m.traverse(o=>{o.castShadow=false;if(o.isSprite)o.visible=false});m.visible=true;m.rotation.z=PI/2;m.position.y=.09;m.scale.setScalar(1);const g=new THREE.Group();g.add(m);g.position.set(x,y,z);g.rotation.y=R()*6.28;sc.add(g);
const ring=new THREE.Mesh(pkRG,pkRM);ring.position.set(x,y+.05,z);sc.add(ring);const spr=mkSpr(tSpr,0xffd060,1,.9);spr.position.set(x,y+.55,z);sc.add(spr);
const p={id,ammo:st.ammo,ch:st.ch,mags:st.mags.slice(),rsv:st.rsv,g,ring,spr,x,z,y0:y,t:R()*6,cd:.6,life:80};pks.push(p);if(pks.length>10)rmPk(pks[0]);return p}
function rmPk(p){sc.remove(p.g);sc.remove(p.ring);sc.remove(p.spr);const i=pks.indexOf(p);if(i>=0)pks.splice(i,1);if(nearPk===p)nearPk=null}
function clearPks(){while(kits.length)rmKit(kits[0]);while(pks.length)rmPk(pks[0]);nearPk=null;$('pk').style.display='none'}
function dropFromE(e){const u=e.userData,id=u.wid,d=WD[id];if(!d)return;let x=e.position.x-Math.sin(e.rotation.y)*.7,z=e.position.z-Math.cos(e.rotation.y)*.7;if(hitBox(x,z,.25)){x=e.position.x;z=e.position.z;if(hitBox(x,z,.25))return}
const st=d.type==='mag'?{ammo:Math.max(3,Math.round(d.cap*(.35+R()*.65))),ch:1,mags:[],rsv:0}:{ammo:Math.max(1,Math.round(d.cap*(.4+R()*.6))),ch:1,mags:[],rsv:2+(R()*6|0)};
if(d.type==='mag'){const n=(R()<.6?1:0)+(R()<.25?1:0);for(let i=0;i<n;i++)st.mags.push(d.cap)}addPk(id,x,z,groundAt(x,z,.6),st);if(u.rg)u.rg.visible=false;if(!pkTip){pkTip=1;pop('ENEMY GUN DROPPED — go close & PICK UP')}}
function doPickup(){if(!run||paused||swp.on||act.on||!nearPk)return;const p=nearPk;startAct('pick',()=>pickCore(p))}
function pickCore(p){if(pks.indexOf(p)<0)return;const d=WD[p.id],cur=SL[d.cl];
if(cur&&cur.id===p.id){let got=0;if(d.type==='mag'){const add=[];if(p.ammo+p.ch>0)add.push(p.ammo+p.ch);p.mags.forEach(m=>add.push(m));for(const m of add)if(cur.mags.length<d.mmax){cur.mags.push(m);got+=m}}else{got=Math.min(p.ammo+p.ch+p.rsv,d.rmax-cur.rsv);cur.rsv+=got}
if(!got){pop('AMMO FULL');return}rmPk(p);pop('+'+got+' '+d.n+' AMMO');sClick(.5,500);refreshSlots();return}
if(d.cl===cs){cancelReload();finishPump();chq.on=0}
if(cur){let ox=P.x-Math.sin(P.yaw)*1.5,oz=P.z-Math.cos(P.yaw)*1.5;if(hitBox(ox,oz,.25)){ox=P.x;oz=P.z}addPk(cur.id,ox,oz,groundAt(ox,oz,P.y-1.7),cur)}
SL[d.cl]={id:p.id,ammo:p.ammo,ch:p.ch,mags:p.mags.slice(),rsv:p.rsv,nomag:0};rmPk(p);pop('PICKED UP '+d.n);sClick(.5,420);refreshSlots();selectSlot(d.cl);gh.draw=0}
function pkUI(dt){for(let i=pks.length-1;i>=0;i--){pks[i].life-=dt;if(pks[i].life<=0)rmPk(pks[i])}for(const p of pks){p.t+=dt;p.cd-=dt;p.g.position.y=p.y0+Math.sin(p.t*2.2)*.02;p.ring.rotation.y+=dt;p.spr.material.opacity=.45+.35*Math.sin(p.t*3)}
let b=null,bd=2.4;for(const p of pks){if(p.cd>0)continue;const q=Math.hypot(p.x-P.x,p.z-P.z);if(q<bd&&Math.abs(p.y0-(P.y-1.7))<1.4){bd=q;b=p}}nearPk=b;
const e=$('pk');if(b&&!swp.on){const d=WD[b.id],cur=SL[d.cl],l=(TOUCHD?'':'[F] ')+(cur&&cur.id===b.id?'TAKE AMMO':'PICK UP')+'\n'+d.n;if(l!==pkLbl){pkLbl=l;e.textContent=l}e.style.display='block'}else{e.style.display='none';pkLbl=''}}
giveLoadout();
const SKY={day:{top:[58,110,190],hor:[196,210,222],cl:.52,cc:[255,255,255],sunc:'rgba(255,245,220,1)',sunc2:'rgba(255,220,150,.5)',sr:46},
dusk:{top:[50,60,120],hor:[236,150,90],cl:.45,cc:[255,170,120],sunc:'rgba(255,200,120,1)',sunc2:'rgba(255,120,60,.55)',sr:60},
des:{top:[70,130,210],hor:[230,214,180],cl:.62,cc:[255,255,250],sunc:'rgba(255,250,225,1)',sunc2:'rgba(255,225,160,.5)',sr:50},
night:{top:[4,8,20],hor:[18,26,44],cl:.7,cc:[40,50,70],stars:1,sunc:'rgba(200,215,255,1)',sunc2:'rgba(120,150,220,.4)',sr:22},
storm:{top:[10,14,22],hor:[34,42,54],cl:.2,cc:[60,66,78],sunc:'rgba(0,0,0,0)',sunc2:'rgba(0,0,0,0)',sr:10}};
Object.assign(SKY,{snow:{top:[150,170,195],hor:[214,222,232],cl:.25,cc:[240,244,250],sunc:'rgba(255,255,255,.6)',sunc2:'rgba(255,255,255,.2)',sr:60},sea:{top:[50,105,180],hor:[178,205,228],cl:.5,cc:[255,255,255],sunc:'rgba(255,248,225,1)',sunc2:'rgba(255,225,170,.5)',sr:48},jung:{top:[70,135,190],hor:[196,218,200],cl:.5,cc:[255,255,252],sunc:'rgba(255,245,215,1)',sunc2:'rgba(255,225,160,.5)',sr:46}});
Object.assign(TG,{ciws:{w:3,d:3,h:3.6,hp:300,cy:2,x:7,build:g=>{mesh(new THREE.CylinderGeometry(1.1,1.3,1.2,12),mt('hull'),0,.6,0,{p:g});mesh(new THREE.CylinderGeometry(.9,.9,.9,12),mt('white'),0,1.7,0,{p:g});const d=new THREE.Mesh(new THREE.SphereGeometry(.95,14,8,0,2*PI,0,PI/2),mt('white'));d.position.y=2.15;g.add(d);const b=mesh(new THREE.CylinderGeometry(.16,.16,2.2,8),mt('dark'),.6,1.7,-1.3,{p:g});b.rotation.x=PI/2}},
missile:{w:3.4,d:6.4,h:3.2,hp:280,cy:2,x:8,build:g=>{mesh(Bx(3,.8,5.6),mt('stl'),0,.5,0,{p:g});mesh(Bx(2.6,1,5.8),mt('hull'),0,1.4,0,{p:g});for(const a of[-.65,.65]){const m=mesh(new THREE.CylinderGeometry(.42,.42,5.6,10),mt('olive'),a,2.3,0,{p:g});m.rotation.x=PI/2+.3}}}});
Object.assign(SKY,{dawn:{top:[72,96,150],hor:[246,176,120],cl:.5,cc:[255,190,150],sunc:'rgba(255,214,150,1)',sunc2:'rgba(255,150,80,.55)',sr:58}});
const MS=[
{n:'OPERATION IRON GATE',ent:'heli',loc:'MILITARY BASE · 0540 HRS',b:'day',sky:SKY.day,sd:[.5,.62,.35],fog:[30,150],hemi:[0xdbe8f5,0x5a4c38,1],sunC:0xfff2d6,sunI:2.3,exp:1.15,torch:0,start:[0,100],vis:55,spot:26,
intro:[['CPT. RAWAT','Alpha team, listen up. This is the enemy\'s largest military base. Every attack they launch is planned from here.'],['SGT. KHAN','Sir, the base has a fuel depot, a hangar and a radar station. We have to blow up all three.'],['CPT. RAWAT','First, get in through the main gate. There will be guards everywhere. Move out!']],
st:[{t:'reach',x:0,z:54,o:'Reach the MAIN GATE',s:'The gate is ahead. Keep an eye on the tower.'},
{t:'kill',n:6,at:[0,36,16],o:'Neutralize the gate guards',s:'Contact! Gate guards, open fire!'},
{t:'reach',x:0,z:12,o:'Advance to the central junction',s:'Area clear. Move to the junction.'},
{t:'destroy',tg:[{k:'fuel',x:-52,z:-8},{k:'fuel',x:-52,z:-16},{k:'fuel',x:-52,z:-24}],guards:4,at:[-40,-14,16],o:'Destroy the fuel depot',s:'Fuel tanks in sight. Shoot them, it will be a huge blast!'},
{t:'kill',n:10,heavy:1,at:[30,0,22],o:'Clear the hangar area',s:'Reinforcements are coming from the hangar! Take cover!'},
{t:'reach',x:0,z:-40,o:'Move to the radar compound',s:'The radar compound is ahead. Careful.'},
{t:'hold',x:0,z:-44,time:30,at:[0,-30,34],o:'Plant charges — defend the position',s:'Planting the charges! Hold for thirty seconds!',after:'radar'},
{t:'reach',x:0,z:70,r:4,hz:6,o:'Extract — reinforcements closing in',s:'Radar destroyed! Run back to the gate!'}],
out:[['CPT. RAWAT','Well done, Alpha. The heart of their base is broken.'],['SGT. KHAN','Sir, it will be evening soon. The next area is in the city.']]},
{n:'OPERATION DUSK FIRE',ent:'heli',loc:'CITY WARFARE · 1810 HRS',b:'city',sky:SKY.dusk,sd:[-.6,.18,.5],fog:[25,120],hemi:[0x8a7aa0,0x40302a,.6],sunC:0xff9a50,sunI:2,exp:1.2,torch:0,start:[15,98],vis:50,spot:24,
intro:[['CPT. RAWAT','The enemy has taken over the city. Their troops are in every street.'],['SGT. KHAN','Sir, their tanks are parked at the intersection. Be careful.'],['CPT. RAWAT','Clear every street, destroy the tanks, and get to the evacuation point.']],
st:[{t:'reach',x:15,z:44,o:'Move up the street',s:'The street is dangerous. Move from cover to cover.'},
{t:'kill',n:8,at:[15,26,18],o:'Clear the street',s:'Enemies in the windows! Fire!'},
{t:'reach',x:15,z:2,o:'Push to the central plaza',s:'Make your way to the plaza.'},
{t:'destroy',tg:[{k:'tank',x:45,z:-8,rot:0},{k:'tank',x:45,z:-30,rot:0}],guards:4,at:[45,-18,16],o:'Destroy the enemy tanks',s:'Tanks ahead! Grenades or bullets, whatever it takes, destroy them!'},
{t:'kill',n:10,heavy:1,at:[-15,-20,22],o:'Eliminate the counter-attack',s:'They launched a counter-attack! There are a lot of them!'},
{t:'hold',x:-15,z:-15,time:30,at:[-15,-20,34],o:'Hold the intersection — air support en route',s:'Air support is on the way. Hold for thirty seconds!'},
{t:'reach',x:-45,z:-45,r:4,hz:7,o:'Reach the evacuation chopper',s:'The chopper is landing! Run!'}],
out:[['CPT. RAWAT','The city is ours again. Next is their supply convoy in the desert.']]},
{n:'OPERATION SANDSTORM',ent:'heli',loc:'DESERT OUTPOST · 1230 HRS',b:'desert',sky:SKY.des,sd:[.2,.8,-.4],fog:[40,170],hemi:[0xf0e8d0,0x8a7048,1],sunC:0xfff4d8,sunI:2.6,exp:1.25,torch:0,start:[0,100],vis:60,spot:28,
intro:[['CPT. RAWAT','The enemy convoy is moving supplies through the desert. We have to destroy this outpost.'],['SGT. KHAN','Sir, it is open ground. There is very little cover.'],['CPT. RAWAT','Destroy the trucks, clear the outpost, and reach the beacon.']],
st:[{t:'reach',x:0,z:46,o:'Advance to the outpost',s:'The outpost is in sight.'},
{t:'kill',n:8,at:[0,30,24],o:'Eliminate the forward guards',s:'Sentries! Fire!'},
{t:'destroy',tg:[{k:'truck',x:-40,z:-10,rot:1.5708},{k:'truck',x:-10,z:-10,rot:1.5708},{k:'truck',x:22,z:-10,rot:1.5708}],guards:5,at:[0,-14,24],o:'Destroy the supply trucks',s:'Convoy trucks! Blow them all up!'},
{t:'kill',n:12,heavy:2,at:[0,-26,34],o:'Defeat the outpost garrison',s:'The entire garrison is awake!'},
{t:'hold',x:0,z:-46,time:30,at:[0,-30,36],o:'Defend the extraction beacon',s:'Beacon active. Hold for thirty seconds!'},
{t:'reach',x:48,z:-58,r:4,hz:7,o:'Reach the extraction point',s:'The extraction point is to the east. Run!'}],
out:[['CPT. RAWAT','Convoy destroyed. Now the night operation, the toughest one yet.']]},
{n:'OPERATION BLACKOUT',ent:'para',loc:'NIGHT RAID · 0230 HRS',b:'night',night:1,nv:1,sky:SKY.night,sd:[.4,.45,.6],fog:[15,95],hemi:[0x2a3a5c,0x0c0f14,.4],sunC:0x6f8cc8,sunI:.6,exp:1.5,torch:2.6,start:[0,100],vis:42,spot:17,
intro:[['CPT. RAWAT','A night operation. We have to take down the enemy radio towers, quietly.'],['SGT. KHAN','Sir, we will have to move by torchlight only. Keep the noise down.'],['CPT. RAWAT','If a shot is fired, everyone will wake up. Go in stealthily!']],
st:[{t:'reach',x:0,z:48,o:'Infiltrate the compound quietly',s:'Get inside quietly.'},
{t:'kill',n:8,idle:1,at:[0,26,26],o:'Take out the sentries',s:'The guards are not asleep. Take them down one by one.'},
{t:'destroy',tg:[{k:'tower',x:-66,z:-10},{k:'tower',x:64,z:18}],guards:4,idle:1,at:[0,-5,30],o:'Destroy the radio towers',s:'Bring down the radio towers!'},
{t:'kill',n:10,heavy:1,at:[30,-8,24],o:'Clear the hangar',s:'There are troops in the hangar!'},
{t:'reach',x:0,z:-40,o:'Reach the command building',s:'The command building is ahead.'},
{t:'hold',x:0,z:-44,time:25,at:[0,-30,34],o:'Upload the data — defend',s:'Data upload in progress. Twenty-five seconds!'},
{t:'reach',x:0,z:70,r:4,hz:6,o:'Extract',s:'Got the data! Get out!'}],
out:[['CPT. RAWAT','The enemy network is finished. But they still have more hideouts. Next, we head to the snow base.']]},
{n:'OPERATION WHITEOUT',ent:'heli',loc:'ARCTIC BASE · 0700 HRS',b:'snow',snow:1,wind:3,sky:SKY.snow,sd:[.3,.45,.3],fog:[10,85],hemi:[0xdde8f8,0x8a98ad,1.15],sunC:0xe6efff,sunI:1.6,exp:1.2,torch:0,start:[0,100],vis:40,spot:20,
intro:[['CPT. RAWAT','Alpha team, our target is now in the Arctic. The biggest enemy snow base, and the missile launch codes are here.'],['SGT. KHAN','Sir, a blizzard is raging. Visibility is very low, you will only see the enemy when they are close.'],['CPT. RAWAT','Gunshots carry far in the snow. Stay alert. Move out!']],
st:[{t:'reach',x:0,z:54,o:'Approach the arctic base',s:'The base is ahead. Careful in the blizzard.'},
{t:'kill',n:8,at:[0,34,18],o:'Eliminate the perimeter patrol',s:'Patrol! They are hiding in the snow, fire!'},
{t:'reach',x:0,z:12,o:'Push to the supply yard',s:'Area clear. Move to the supply yard.'},
{t:'destroy',tg:[{k:'fuel',x:-52,z:-8},{k:'fuel',x:-52,z:-16},{k:'tank',x:62,z:-2,rot:0}],guards:5,at:[-30,-14,16],o:'Destroy the fuel tanks and the armored tank',s:'Fuel tanks and a tank in sight. Destroy them!'},
{t:'kill',n:12,heavy:2,at:[30,-8,22],o:'Hold off the hangar reinforcements',s:'Heavy troopers are coming from the hangar!'},
{t:'reach',x:0,z:-40,o:'Move to the command bunker',s:'The command bunker is ahead.'},
{t:'hold',x:0,z:-44,time:30,at:[0,-30,34],o:'Hack the launch codes - defend the position',s:'Codes are downloading. Hold for thirty seconds!'},
{t:'reach',x:0,z:70,r:4,hz:6,o:'Extract - the storm is closing in',s:'Got the codes! Run to the extraction point!'}],
out:[['CPT. RAWAT','We have the launch codes. Well done, Alpha.'],['SGT. KHAN','Sir, now the enemy missile warship is out at sea. We have to go there.']]},
{n:'OPERATION DEEP BLUE',ent:'heli',loc:'NAVAL WARSHIP · NORTH SEA · 1100 HRS',b:'ship',sky:SKY.sea,sd:[.5,.7,.3],fog:[40,200],hemi:[0xd8e8f8,0x2a4a6a,1.1],sunC:0xfff2d6,sunI:2.2,exp:1.15,torch:0,start:[0,70],vis:60,spot:28,deck:[-16,16,-64,79],
intro:[['CPT. RAWAT','The enemy missile warship is in the North Sea. It is targeting our ships.'],['SGT. KHAN','Sir, we will land at the rear of the ship by helicopter. The sea below is deep, do not fall.'],['CPT. RAWAT','First destroy the CIWS guns and missile launchers, then plant charges on the bow gun. Go go go!']],
st:[{t:'reach',x:0,z:52,o:'Secure the helicopter pad',s:'Clear the helipad. Watch the deck.'},
{t:'kill',n:8,at:[0,28,14],o:'Clear the aft deck',s:'Sailors and marines! Fire!'},
{t:'reach',x:0,z:22,o:'Advance along the main deck',s:'Advance along the middle of the deck.'},
{t:'destroy',tg:[{k:'ciws',x:-12,z:8},{k:'ciws',x:12,z:-4}],guards:4,at:[0,2,12],o:'Destroy the CIWS defense guns',s:'CIWS guns in sight. Destroy them first!'},
{t:'kill',n:10,heavy:1,at:[0,-2,16],o:'Repel the boarding defenders',s:'Enemies are coming from the superstructure! Take cover!'},
{t:'reach',x:0,z:-34,o:'Move to the forward deck',s:'Slip past the side of the bridge.'},
{t:'destroy',tg:[{k:'missile',x:-9,z:-42,rot:0},{k:'missile',x:9,z:-42,rot:0}],guards:5,at:[0,-40,12],o:'Destroy the anti-ship missile launchers',s:'Missile launchers! Destroy them quickly!'},
{t:'kill',n:9,heavy:2,at:[0,-52,12],o:'Take the bow of the ship',s:'Heavy troopers at the bow!'},
{t:'hold',x:0,z:-58,time:30,at:[0,-45,14],o:'Plant charges on the main gun - defend',s:'Planting the charges! Hold for thirty seconds!'},
{t:'reach',x:0,z:70,r:4,hz:7,o:'Return to the helipad for extraction',s:'The ship is sinking! Run to the helipad!'}],
out:[['CPT. RAWAT','The warship is now sinking into the sea. Well done.'],['SGT. KHAN','Sir, the next target is a camp hidden in the jungle.']]},
{n:'OPERATION VIPER',ent:'convoy',loc:'JUNGLE CAMP · 0900 HRS',b:'jungle',sky:SKY.jung,sd:[.3,.7,.2],fog:[18,110],hemi:[0xcfe8c0,0x2a3a22,1],sunC:0xfff0c8,sunI:2,exp:1.15,torch:0,start:[0,100],vis:40,spot:20,
intro:[['CPT. RAWAT','The enemy guerrilla camps are deep in the dense jungle. They are attacking our supply routes.'],['SGT. KHAN','Sir, the trees are very thick. We could be attacked from behind too.'],['CPT. RAWAT','Clear the camp, destroy the trucks and radio tower, and grab the intel. Move!']],
st:[{t:'reach',x:0,z:50,o:'Enter the jungle camp',s:'Move carefully through the jungle.'},
{t:'kill',n:8,at:[0,34,22],o:'Eliminate the camp sentries',s:'Enemies behind the trees! Fire!'},
{t:'reach',x:0,z:14,o:'Push to the camp center',s:'Move to the center of the camp.'},
{t:'destroy',tg:[{k:'truck',x:-30,z:-6,rot:1.5708},{k:'truck',x:-18,z:-6,rot:1.5708},{k:'tower',x:42,z:-10}],guards:5,at:[0,-8,20],o:'Destroy the trucks and the radio tower',s:'Trucks and a radio tower! Blow them all up!'},
{t:'kill',n:10,heavy:1,at:[20,-24,24],o:'Clear the guerrilla camp',s:'The entire camp is awake!'},
{t:'reach',x:0,z:-40,o:'Move to the intel tent',s:'The intel tent is ahead.'},
{t:'hold',x:0,z:-44,time:30,at:[0,-30,34],o:'Secure the intel - defend the position',s:'Copying the intel. Hold for thirty seconds!'},
{t:'reach',x:0,z:70,r:4,hz:6,o:'Extract - they are pursuing you',s:'Got the intel! Run to extraction!'}],
out:[['CPT. RAWAT','Camp destroyed. Now an oil rig in the middle of the sea, where their last weapons depot is.']]},
{n:'OPERATION OIL STORM',ent:'boat',loc:'OFFSHORE RIG · 0100 HRS',b:'rig',night:1,nv:1,sky:SKY.storm,sd:[.4,.45,.6],fog:[12,85],hemi:[0x2a3a5c,0x0c0f14,.45],sunC:0x7a90b8,sunI:.55,exp:1.5,torch:2.6,start:[0,26],vis:42,spot:18,deck:[-30,30,-30,30],
intro:[['CPT. RAWAT','This oil rig in the middle of the sea is the enemy weapons and fuel depot. It is night and a storm is coming.'],['SGT. KHAN','Sir, the platform is small, so the enemy will be in every corner. The sea below is deep.'],['CPT. RAWAT','Destroy the fuel tanks and comms masts, and plant charges on the derrick. Go!']],
st:[{t:'reach',x:0,z:10,o:'Secure the cargo deck',s:'Move to the cargo deck. Careful in the storm.'},
{t:'kill',n:8,at:[0,-4,16],o:'Eliminate the platform guards',s:'Platform guards! Fire!'},
{t:'reach',x:0,z:-6,o:'Advance to the derrick',s:'Advance toward the derrick.'},
{t:'destroy',tg:[{k:'fuel',x:-22,z:-6},{k:'fuel',x:-22,z:-14},{k:'fuel',x:-22,z:-22}],guards:4,at:[-5,-14,12],o:'Destroy the fuel storage tanks',s:'Fuel tanks! Shoot them, it will be a huge blast!'},
{t:'kill',n:10,heavy:1,at:[8,-14,16],o:'Repel the reinforcements',s:'Reinforcements have arrived! Take cover!'},
{t:'destroy',tg:[{k:'tower',x:22,z:-6},{k:'tower',x:10,z:-2}],guards:4,at:[0,0,14],o:'Destroy the comms masts',s:'Bring down the comms masts!'},
{t:'hold',x:0,z:-24,time:25,at:[0,-8,18],o:'Plant explosives on the derrick - defend',s:'Charges are going in. Twenty-five seconds!'},
{t:'reach',x:20,z:22,r:4,hz:6,o:'Reach the helipad for extraction',s:'The rig is about to blow! Run to the helipad!'}],
out:[['CPT. RAWAT','Rig destroyed. Now only their commander is left.'],['SGT. KHAN','Sir, he is in his keep. We have to get there before the storm.']]},
{n:'OPERATION SHADOW',ent:'para',loc:'FINAL STRIKE · 0400 HRS',b:'final',night:1,nv:1,sky:SKY.storm,sd:[.4,.45,.6],fog:[15,90],hemi:[0x2a3448,0x0c0f14,.45],sunC:0x7a90b8,sunI:.5,exp:1.5,torch:2.6,start:[0,100],vis:42,spot:20,
intro:[['CPT. RAWAT','This is the final mission. The enemy commander is in that keep.'],['SGT. KHAN','A storm is coming, sir. There will be heavy troopers too.'],['CPT. RAWAT','Alpha, this is the biggest mission of our lives. Move!']],
st:[{t:'reach',x:0,z:50,o:'Approach the stronghold',s:'The stronghold is ahead.'},
{t:'kill',n:10,heavy:3,at:[0,28,26],o:'Break through the defenses',s:'Heavy troopers! Fire is coming from all sides!'},
{t:'reach',x:0,z:6,o:'Advance to the courtyard',s:'Move to the courtyard.'},
{t:'kill',n:9,boss:1,heavy:2,at:[0,-14,16],o:'Eliminate the Commander and his guards',s:'The Commander is ahead! Take him down!'},
{t:'reach',x:0,z:70,r:4,hz:6,o:'Extract!',s:'The Commander is down! Run for extraction!'}],
out:[['CPT. RAWAT','Mission complete. Alpha team, the country is proud of you.'],['SGT. KHAN','Let us go home, sir.']]},
{n:'OPERATION BORDER CROSSING',loc:'MILITARY BASE · BORDER · 0300 HRS',b:'border',night:1,nv:1,sky:SKY.night,sd:[.4,.45,.6],fog:[18,100],hemi:[0x3a4560,0x161616,.55],sunC:0x8aa0d0,sunI:.7,exp:1.4,torch:2.2,start:[0,94],vis:46,spot:22,
crash:[['PILOT','Mayday, mayday! Missile lock, both engines are gone! We are going down!',5],['SGT. KHAN','Sir, hold on tight! Impact in five, four, three!',5],['CPT. RAWAT','Alpha, get up! Is everyone alive? Where did we land?',5]],
intro:[['CPT. RAWAT','As soon as we crossed the border, radar picked up our plane. We have crashed inside a military base.'],['SGT. KHAN','Sir, the whole base will go on alert. There are snipers on the towers and a checkpost at the gate.'],['CPT. RAWAT','There are fighter jets on the runway. Take a jet and fly across the border. Move out!']],
st:[{t:'reach',x:0,z:54,o:'Escape the crash site and reach the border gate',s:'There is a fire, get out fast! There is a checkpost at the gate.'},
{t:'kill',n:8,at:[0,34,18],o:'Take out the checkpost garrison',s:'The garrison is awake! Watch out for snipers on the towers!'},
{t:'reach',x:0,z:6,o:'Fight through to the barracks road',s:'Advance to the barracks road.'},
{t:'kill',n:10,heavy:1,at:[-20,-30,24],o:'Secure the airstrip',s:'Reinforcements at the airstrip! Take cover!',cs:[['SGT. KHAN','Sir, the runway is ahead. Look at those jets parked outside the hangar!'],['CPT. RAWAT','Clear the airstrip first. It is the only way to reach the jet.']]},
{t:'reach',x:-30,z:-45,r:4,hz:6,o:'Reach the fighter jet',s:'The jet is ahead! Run!'},
{t:'fly',o:'Fly out - dodge the missiles and cross the border!',s:'',cs:[['CPT. RAWAT','We made it to the jet! Alpha-1, the cockpit is yours. We will sit behind you.'],['SGT. KHAN','Sir, the SAM batteries are active. The border is only a little way off!'],['CPT. RAWAT','Engines starting. Hold tight, Alpha. We are going home!']]}],
out:[['CPT. RAWAT','Border crossed! We are safe. Well done, Alpha, the jet did an amazing job.'],['SGT. KHAN','Sir, we survived today. I will never forget this night.']]},
{n:'OPERATION EAGLE EYE',loc:'UAV STRIKE · DESERT OUTPOST · 1400 HRS',b:'desert',uav:1,sky:SKY.des,sd:[.2,.8,-.4],fog:[40,170],hemi:[0xf0e8d0,0x8a7048,1],sunC:0xfff4d8,sunI:2.6,exp:1.25,torch:0,start:[0,72],vis:60,spot:26,
intro:[['CPT. RAWAT','Alpha-1, this time you are not on the ground, you are in the sky. You have control of the Eagle-7 UAV.'],['SGT. KHAN','Sir, we will advance across open ground. You find the enemy from above and fire Hellfire missiles.'],['CPT. RAWAT','Be careful, the missile will not fire if our people are in the blast zone. Move the UAV with WASD or the stick, and strike with FIRE!']],
st:[{t:'uav',route:[[0,54],[0,38],[0,22]],amb:[{at:[0,42,12],n:4},{at:[-18,26,12],n:4},{at:[18,26,12],n:3,heavy:1}],o:'UAV overwatch - clear the path for the squad',s:'Eagle-7 is live. The squad is moving ahead, strike any enemy you see!'},
{t:'uav',route:[[0,6],[0,-10],[7,-22],[0,-36]],tg:[{k:'truck',x:-30,z:-10,rot:1.5708},{k:'truck',x:30,z:-10,rot:1.5708},{k:'tank',x:36,z:-48,rot:0}],guards:5,at:[0,-14,26],amb:[{at:[0,-4,14],n:4,heavy:1}],o:'UAV strike - destroy the supply trucks and the tank',s:'Trucks and a tank in sight. Take them out with missiles and cover the squad!'},
{t:'uav',route:[[0,-44]],hold:30,amb:[{at:[0,-52,12],n:5,heavy:1}],o:'UAV overwatch - protect the squad while they plant charges',s:'The squad is planting charges. Do not let anyone get close for thirty seconds!'},
{t:'reach',x:48,z:-58,r:4,hz:7,o:'UAV link lost - run to the extraction beacon',s:'The UAV battery is dead! Now run to the beacon yourself!'}],
out:[['CPT. RAWAT','Well done, Alpha-1. The Eagle-7 strikes cleared the squad path.']]},
{n:'OPERATION NIGHTFALL',ent:'para',loc:'NIGHT ASSAULT · ENEMY AIR BASE · 0200 HRS',b:'nbase',night:1,nv:1,sky:SKY.night,sd:[.4,.45,.6],fog:[8,60],hemi:[0x1b2740,0x05070b,.22],sunC:0x4a5f90,sunI:.2,exp:1.25,torch:0,start:[0,100],vis:44,spot:18,
intro:[['CPT. RAWAT','Alpha, tonight we hit the enemy military base head on. The whole base is sunk in darkness.'],['SGT. KHAN','Sir, we have Night Vision Goggles. Press N or tap the NVG button to turn them on. The battery is limited, so be careful!'],['CPT. RAWAT','Explosions will flare in your goggles and sting your eyes. Take out the sentries quietly, then destroy the trucks and tank, and plant charges on the command building. Move out!']],
st:[{t:'reach',x:0,z:54,o:'Infiltrate the base - switch ON your night vision (N)',s:'Turn on your NVG and move quietly to the gate.'},
{t:'kill',n:7,idle:1,at:[0,34,24],o:'Silently eliminate the sentries',s:'Sentries are standing in the dark. Use your NVG and take them down one by one.'},
{t:'reach',x:0,z:10,o:'Advance to the vehicle yard',s:'Advance to the vehicle yard.'},
{t:'destroy',tg:[{k:'truck',x:-24,z:-8,rot:1.5708},{k:'truck',x:14,z:-10,rot:1.5708},{k:'tank',x:-10,z:-28,rot:0}],guards:5,idle:1,at:[0,-14,28],o:'Destroy the trucks and the tank',s:'Destroy the trucks and the tank. The blast will flash your NVG, protect your eyes!'},
{t:'kill',n:10,heavy:1,at:[28,-10,24],o:'Repel the base garrison',s:'The alarm has gone off! The garrison is coming, take cover!'},
{t:'reach',x:0,z:-40,o:'Reach the command building',s:'The command building is ahead.'},
{t:'hold',x:0,z:-44,time:25,at:[0,-30,34],o:'Plant the charges - defend the position',s:'Charges are going in. Hold for twenty-five seconds!'},
{t:'reach',x:0,z:70,r:4,hz:6,o:'Extract - the whole base is awake',s:'Base blown up! Run back to the gate!'}],
out:[['CPT. RAWAT','The night base is ours. Alpha team, the country is proud of you.']]},
{n:'OPERATION SAND FANG',ent:'heli',loc:'TERRORIST BASE · DESERT · 1100 HRS',b:'tbase',sky:SKY.des,sd:[.2,.8,-.4],fog:[40,170],hemi:[0xf0e8d0,0x8a7048,1],sunC:0xfff4d8,sunI:2.6,exp:1.25,torch:0,start:[0,100],vis:60,spot:28,
intro:[['CPT. RAWAT','Alpha, intel says a small terrorist cell is hiding in the desert. It is a small base, but they are well armed.'],['SGT. KHAN','Sir, the base is surrounded by a wall with one main gate. They have snipers on the watchtowers and a fuel store and supply trucks inside.'],['CPT. RAWAT','Take out the patrol, breach the gate, destroy their supplies, and finish their leader in the command hut. Move out!']],
st:[{t:'reach',x:0,z:44,o:'Approach the terrorist base',s:'The base is ahead. Stay low and watch the towers.'},
{t:'kill',n:6,at:[0,28,14],o:'Eliminate the outer patrol',s:'Patrol outside the wall! Fire!'},
{t:'reach',x:0,z:12,o:'Breach the main gate',s:'Patrol down. Push through the gate.'},
{t:'destroy',tg:[{k:'fuel',x:-26,z:6},{k:'truck',x:22,z:4,rot:1.5708},{k:'truck',x:22,z:-9,rot:1.5708}],guards:4,at:[0,-4,16],o:'Destroy the fuel store and the supply trucks',s:'Their supplies are here. Blow them up!'},
{t:'kill',n:9,heavy:1,at:[0,-18,20],o:'Clear the compound',s:'The whole cell is out! Take cover!'},
{t:'reach',x:0,z:-29,o:'Storm the command hut',s:'The command hut is ahead. Their leader is inside.'},
{t:'hold',x:0,z:-29,time:25,at:[0,-20,30],o:'Plant charges - defend the position',s:'Planting the charges! Hold for twenty-five seconds!'},
{t:'reach',x:0,z:70,r:4,hz:7,o:'Extract - the base is about to blow',s:'Charges are set! Run back to the extraction point!'}],
out:[['CPT. RAWAT','The terrorist base is destroyed. Well done, Alpha.']]},
{n:'OPERATION IRON TIDE',ent:'boat',loc:'OFFSHORE RIG \u00b7 HOSTAGE RESCUE \u00b7 0300 HRS',b:'rig',night:1,nv:1,sky:SKY.storm,sd:[.4,.45,.6],fog:[12,85],hemi:[0x2a3a5c,0x0c0f14,.45],sunC:0x7a90b8,sunI:.55,exp:1.5,torch:2.6,start:[0,26],vis:42,spot:18,deck:[-30,30,-30,30],
intro:[['CPT. RAWAT','Alpha, terrorists have seized the oil rig in the North Sea. They have taken the rig workers hostage.'],['SGT. KHAN','Sir, three workers are tied up near the derrick. If the terrorists see us coming, they will kill them.'],['CPT. RAWAT','Storm, night, and a deep sea under our boots. Clear the deck, free every hostage and bring them to the helipad. Go!']],
st:[{t:'reach',x:0,z:10,o:'Secure the cargo deck',s:'Boat is away. Move to the cargo deck, keep low in the storm.'},
{t:'kill',n:8,at:[0,-4,16],o:'Eliminate the terrorists on the lower deck',s:'Terrorists on the deck! Fire!'},
{t:'reach',x:0,z:-2,o:'Advance toward the derrick',s:'The hostages are near the derrick. Move up.'},
{t:'rescue',hs:[[-5,-9],[0,-11],[5,-9]],ex:[20,22],guards:5,at:[0,-8,12],o:'Rescue the hostage workers',s:'There are the hostages! Get close to each one and cut them loose. Do not let the guards reach them!'},
{t:'kill',n:10,heavy:1,at:[8,-14,16],o:'Repel the terrorist counter-attack',s:'The terrorists are charging! Protect the workers!'},
{t:'destroy',tg:[{k:'tower',x:22,z:-6},{k:'tower',x:10,z:-2}],guards:4,at:[0,0,14],o:'Destroy the comms masts - stop the reinforcements',s:'They are calling for backup. Bring down the comms masts!'},
{t:'reach',x:20,z:22,r:4,hz:6,o:'Escort the hostages to the helipad',s:'Chopper is inbound! Get the workers to the helipad, run!'}],
out:[['CPT. RAWAT','All hostages are safe. Excellent work, Alpha.'],['SGT. KHAN','Sir, the workers say they owe us their lives.']]},
{n:'OPERATION VILLAGE SHIELD',ent:'heli',loc:'BORDER VILLAGE \u00b7 TERRORIST ATTACK \u00b7 0615 HRS',b:'village',sky:SKY.dawn,sd:[.62,.3,.5],fog:[40,170],hemi:[0xffe2c4,0x4d3f30,.95],sunC:0xffc890,sunI:2,exp:1.1,torch:0,start:[0,100],vis:52,spot:24,
intro:[['CPT. RAWAT','Alpha, terrorists have attacked a border village at dawn. Houses are burning and the villagers are hiding in their cellars.'],['SGT. KHAN','Sir, we can hear gunfire from the market square. They have trucks and snipers on the outskirts.'],['CPT. RAWAT','No civilian dies on our watch. Move in with the squad, clear the village street by street and kill every terrorist. Go!']],
st:[{t:'reach',x:0,z:52,o:'Enter the village',s:'Smoke ahead. Stay close to the squad and move up the main street.'},
{t:'kill',n:7,at:[0,30,18],o:'Eliminate the terrorists on the main street',s:'Contact! Terrorists at the houses, open fire!'},
{t:'reach',x:-15,z:10,o:'Secure the market square',s:'Street is clear. Push to the market square.'},
{t:'kill',n:10,heavy:1,at:[-15,0,20],o:'Clear the market square',s:'They are hiding behind the stalls and ruined houses. Watch the rooftops!'},
{t:'hold',x:-15,z:10,time:30,at:[-15,-6,26],o:'Hold the square - defend the villagers',s:'Reinforcements are coming! Hold the square for thirty seconds!'},
{t:'destroy',tg:[{k:'truck',x:5.5,z:-22},{k:'truck',x:-5.5,z:-44}],guards:4,at:[0,-32,16],o:'Destroy the terrorist trucks',s:'Their supply trucks are on the road. Blow them up!'},
{t:'kill',n:8,boss:1,at:[-28,-56,10],o:'Kill the terrorist leader at the mosque',s:'Their leader is at the mosque. End this, Alpha!'}],
out:[['CPT. RAWAT','The village is safe. Well done, Alpha.']]},
{n:'OPERATION INFARCTION',loc:'RIDGE NINE \u00b7 AA SUPPRESSION \u00b7 0630 HRS',b:'mount',open:1,solo:1,nokits:1,lo:['snp','m4','pi'],far:420,sy:70,sky:SKY.dawn,sd:[.62,.3,.5],fog:[200,520],hemi:[0xffe2c4,0x4d3f30,.95],sunC:0xffc890,sunI:2,exp:1.1,torch:0,start:[0,6],vis:60,spot:20,
intro:[['CPT. RAWAT','Alpha-1, this mission is different. You are going in alone. No squad, no backup.'],['SGT. KHAN','Sir, the enemy air defence is shooting down every jet we send. Three anti-aircraft batteries cover the valley.'],['CPT. RAWAT','You will be on top of Ridge Nine with an AWM sniper rifle, an M4 and an AA lock device. Paint each battery and our jet Wildcat-1 will destroy it.'],['SGT. KHAN','The device needs a steady lock. Keep the battery in your sights for a few seconds. Lock range is four hundred and fifty metres. Good hunting.']],
st:[{t:'lock',tg:[{k:'aa',x:120,z:-150,rot:.6}],guards:4,lim:420,o:'Lock the AA battery to the north-east',s:'First battery is to the north-east. Scope in and hold the lock device on it.'},
{t:'lock',tg:[{k:'aa',x:-200,z:-120,rot:-.5}],guards:5,lim:420,o:'Lock the AA battery to the west',s:'Second battery, west valley. Same drill. Hold the lock until the jet commits.'},
{t:'lock',tg:[{k:'aa',x:30,z:-290,rot:0},{k:'aa',x:62,z:-282,rot:0}],guards:6,lim:480,who:'CPT. RAWAT',o:'Lock both AA guns at the main battery',s:'This is the main battery, two guns. Lock them one at a time. You can use the sniper on the guards.'}],
out:[['CPT. RAWAT','All batteries are down. Wildcat-1 has a clear corridor. Excellent work, Alpha-1.'],['SGT. KHAN','Sir, the valley is open for our air force. Extraction is on its way.']]}];
const LOPT={s0:['m4','ak','lmg'],s2:['sg','dmr']},LENV={sd:[.4,.45,.6],sky:SKY.night,fog:[12,75],hemi:[0x3a4a66,0x0c0f14,.6],sunC:0x7f9ad0,sunI:.9,exp:1.35,torch:0,night:1},
RANKS=['RECRUIT','PRIVATE','CORPORAL','SERGEANT','STAFF SGT','LIEUTENANT','CAPTAIN','MAJOR','COLONEL','GENERAL'],
TABS=[['play','OPERATIONS'],['squad','OPERATORS'],['cz','CUSTOMIZE'],['car','CAREER']],ROLES={KHAN:'POINTMAN',BILAL:'RIFLEMAN',ALI:'SUPPORT'},FM=[[2.1,-1.8],[3.5,-2.3],[4.9,-1.8]];
let inLobby=false,lobMi=0,lobTab='play',xpBank=0;const lobNP=[];
const xpGet=()=>{try{return+localStorage.getItem('mo_xp')||0}catch(e){return 0}};
function rankOf(){const xp=xpGet(),L=1+Math.floor(Math.sqrt(xp/250)),a=250*(L-1)*(L-1),b=250*L*L;return{xp,L,name:RANKS[Math.min(9,L-1)],p:clamp((xp-a)/(b-a),0,1),next:b}}
function missionXP(){if(score<xpBank)xpBank=0;const n=score-xpBank;xpBank=score;try{if(n>0)localStorage.setItem('mo_xp',xpGet()+n);localStorage.setItem('mo_best',Math.max(+localStorage.getItem('mo_best')||0,score))}catch(e){}}
function saveGame(nextIdx){try{const r=rankOf(),sk={};for(const id in WD){if(id==='kn')continue;const t=skinTier(id);if(t)sk[id]=t}
localStorage.setItem('mo_save',JSON.stringify({v:1,mission:Math.min(MS.length,nextIdx+1),xp:r.xp,rank:r.name,best:+localStorage.getItem('mo_best')||0,weapons:{loadout:{s0:LO.s0,s2:LO.s2},kills:WK,skins:sk},t:Date.now()}))}catch(e){}}
function restoreSave(){try{const sv=JSON.parse(localStorage.getItem('mo_save')||'null');if(!sv||typeof sv.mission!=='number')return;const m=clamp(sv.mission-1,0,MS.length-1);
if(m>(+localStorage.getItem('mo_p')||0))localStorage.setItem('mo_p',m);if((sv.xp|0)>xpGet())localStorage.setItem('mo_xp',sv.xp|0);if((sv.best|0)>(+localStorage.getItem('mo_best')||0))localStorage.setItem('mo_best',sv.best|0)}catch(e){}}
function saveLO(){try{localStorage.setItem('mo_lo',JSON.stringify(LO))}catch(e){}}
function lobTex(txt,w,h,bg,fg,fs){const c=document.createElement('canvas');c.width=w;c.height=h;const g=c.getContext('2d');g.fillStyle=bg;g.fillRect(0,0,w,h);g.strokeStyle=fg;g.lineWidth=6;g.strokeRect(6,6,w-12,h-12);
if(h<200){g.globalAlpha=.25;for(let i=0;i<w;i+=32){g.beginPath();g.moveTo(i,0);g.lineTo(i,h);g.stroke()}for(let j=0;j<h;j+=32){g.beginPath();g.moveTo(0,j);g.lineTo(w,j);g.stroke()}g.globalAlpha=1}
g.fillStyle=fg;g.font=fs+'px Impact,Arial';g.textAlign='center';g.textBaseline='middle';g.fillText(txt,w/2,h/2);const t=new THREE.CanvasTexture(c);t.encoding=THREE.sRGBEncoding;return t}
function buildLobby(){clearWorld();env(LENV);setGround('conc',30);const W=mt('conc');
box(0,-14,42,9,1,W,6);box(-21,-2,1,9,26,W,6);box(21,-2,1,9,26,W,6);
prop('crate',-12,-10);prop('crate',12,-11);prop('barrier',-9,-3);prop('barrier',-9,1);prop('cont',15,-6);fireProp(-5.5,-7.5,true);
const bn=new THREE.Mesh(new THREE.PlaneGeometry(11,2.6),new THREE.MeshBasicMaterial({map:lobTex('SQUAD ALPHA',1024,240,'#14170f','#c8a64a',140)}));bn.position.set(0,5.2,-13.45);world.add(bn);
const k=new THREE.SpotLight(0xffe2b8,4,45,.55,.6,1.2);k.position.set(-2,7,8);k.target.position.set(4.2,1,-2);world.add(k);world.add(k.target);
const r=new THREE.PointLight(0x5a8cff,2.4,20,2);r.position.set(4.5,3.2,-6.5);world.add(r);
lobTable()}
const lobOrb={y:0,yt:0,p:0,pt:0,vy:0,vp:0,dn:false};let lobPg=0,LAP=null;const lobCam={p:[0,1.4,8.6],l:[3.6,1.45,-2],f:48},TCN={day:6,night:6,final:6,snow:6,city:2,desert:4,jungle:4,border:6,rig:2,ship:0,nbase:6,tbase:4,village:2},
TER={day:'Military base',night:'Military base (night)',final:'Fortress',city:'Urban warfare',desert:'Desert outpost',snow:'Arctic base',ship:'Naval warship',jungle:'Jungle camp',rig:'Offshore oil rig',border:'Border base & airstrip',nbase:'Enemy air base (night)',tbase:'Terrorist base (desert)',village:'Border village'},
STT={reach:'MOVE',kill:'KILL',destroy:'DESTROY',hold:'HOLD',fly:'FLY',uav:'UAV'},TGN={fuel:'Fuel tanks',radar:'Radar',tower:'Radio towers',tank:'Tanks',truck:'Trucks',ciws:'CIWS guns',missile:'Missiles'};
function defInfo(m){const ni=MS.indexOf(m),t=TCN[m.b]||0;return{t:t,s:m.uav?0:Math.min(t,5,2+(ni>>1)),c:m.b==='border'?(ni>5?3:2):0}}
function lobTable(){const D=mt('dark'),Cr=mt('crate'),lx=-.3,lz=.55;
box(1.5,.4,5.8,.12,1.5,Cr,2,{y0:.73,nc:true});for(const a of[-1,1])for(const b of[-1,1])box(1.5+a*2.7,.4+b*.6,.12,.73,.12,D,1,{nc:true});
box(lx,lz,2.3,.06,1.5,D,1,{y0:.85,nc:true});
const kc=document.createElement('canvas');kc.width=256;kc.height=128;const kg=kc.getContext('2d');kg.fillStyle='#17191c';kg.fillRect(0,0,256,128);kg.fillStyle='#34383e';for(let r=0;r<5;r++)for(let c=0;c<14;c++)kg.fillRect(6+c*17.5,8+r*16,15,12);kg.fillRect(70,100,116,14);
const kp=new THREE.Mesh(new THREE.PlaneGeometry(2.1,1.05),new THREE.MeshBasicMaterial({map:new THREE.CanvasTexture(kc)}));kp.rotation.x=-PI/2;kp.position.set(lx,.885,lz+.08);world.add(kp);
const cv=document.createElement('canvas');const LK=TEXMAX<=512?.5:1;cv.width=1024*LK;cv.height=640*LK;const tex=new THREE.CanvasTexture(cv);tex.encoding=THREE.sRGBEncoding;tex.anisotropy=LITE?1:Math.min(4,rd.capabilities.getMaxAnisotropy());tex.minFilter=THREE.LinearMipmapLinearFilter;tex.magFilter=THREE.LinearFilter;LAP={cv:cv,g:cv.getContext('2d'),tex:tex,k:LK};
const sg=new THREE.Group();sg.position.set(lx,.91,lz-.72);sg.rotation.x=-.22;world.add(sg);
mesh(Bx(2.3,1.45,.05),D,0,.725,0,{p:sg});
const sp=new THREE.Mesh(new THREE.PlaneGeometry(2.14,1.34),new THREE.MeshBasicMaterial({map:tex,toneMapped:false}));sp.position.set(0,.725,.03);sg.add(sp);
const gl=new THREE.PointLight(0x7dffb0,1.3,6,2);gl.position.set(lx,1.4,lz+.9);world.add(gl);
mesh(new THREE.CylinderGeometry(.07,.07,.14,10),mt('red'),2.4,.92,.7,{});mesh(Bx(.9,.02,.65),mt('sand'),1.5,.86,.5,{cs:false});mesh(Bx(.5,.02,.4),mt('white'),3.2,.86,.3,{cs:false});
mesh(Bx(.02,2,.02),D,1.5,4.5,.4,{cs:false});mesh(new THREE.CylinderGeometry(.15,.5,.3,12),D,1.5,3.45,.4,{cs:false});
}
function lapTxt(g,t,x,y,w,lh,n){const ws=t.split(' ');let l='',c=0;for(const q of ws){const tt=l?l+' '+q:q;if(g.measureText(tt).width>w&&l){g.fillText(l,x,y);y+=lh;l=q;if(++c>=n)return y}else l=tt}g.fillText(l,x,y);return y+lh}
function lapClip(g,t,w){while(t.length>3&&g.measureText(t).width>w)t=t.slice(0,-2);return t}
function lapDraw(){if(!LAP)return;const m=MS[lobMi],pr=prog(),g=LAP.g,W=1024,H=640,di=defInfo(m);g.setTransform(LAP.k,0,0,LAP.k,0,0);
g.fillStyle='#06100a';g.fillRect(0,0,W,H);g.fillStyle='#0e2c1a';g.fillRect(0,0,W,72);g.textBaseline='middle';g.fillStyle='#7dff9c';g.font='38px Impact,Arial';g.textAlign='left';
g.fillText('ALPHA-NET // MISSION '+(lobMi+1)+'/'+MS.length,24,38);g.textAlign='right';g.fillText(['BRIEFING','OBJECTIVES','INTEL'][lobPg]+'  '+(lobPg+1)+'/3',W-24,38);g.textAlign='left';g.textBaseline='alphabetic';
if(lobPg===0){g.fillStyle='#fff';g.font='62px Impact,Arial';g.fillText(lapClip(g,m.n,W-48),24,150);g.fillStyle='#c8a64a';g.font='34px Arial';g.fillText(lapClip(g,m.loc,W-48),24,198);
const th=1+Math.round(lobMi*4/Math.max(1,MS.length-1)),rows=[['STATUS',lobMi<pr?'CLEARED':'NEW'],['THREAT','\u25A0'.repeat(th)+'\u25A1'.repeat(5-th)],['TERRAIN',TER[m.b]||'-'],['CONDITIONS',m.snow?'BLIZZARD':m.night?'NIGHT':'DAYLIGHT'],['PHASES',m.st.length+' OBJECTIVES']];
g.font='34px Arial';rows.forEach((r,i)=>{g.fillStyle='#8fb89a';g.fillText(r[0],24,262+i*48);g.fillStyle='#fff';g.fillText(r[1],330,262+i*48)});
g.fillStyle='#7dff9c';g.font='26px Impact,Arial';g.fillText("COMMANDER'S NOTE",24,510);g.fillStyle='#cfe9d6';g.font='italic 28px Arial';lapTxt(g,m.intro[0][1],24,548,W-48,36,3)}
else if(lobPg===1){let n=0;m.st.forEach(s=>{if(!s.o)return;const y=118+n*62,tg=STT[s.t]+(s.t==='kill'?' '+s.n:s.t==='hold'?' '+s.time+'s':'');n++;
g.fillStyle='#c8a64a';g.font='30px Impact,Arial';g.fillText(n+'. '+tg,24,y+32);g.fillStyle='#fff';g.font='31px Arial';g.fillText(lapClip(g,s.o,W-310),270,y+32);g.fillStyle='#ffffff22';g.fillRect(24,y+44,W-48,1)})}
else{let tot=0,hv=0,bs=0,tgs=[],fly=0;m.st.forEach(s=>{if(s.t==='kill'){tot+=s.n;hv+=s.heavy||0;bs+=s.boss?1:0}else if(s.t==='destroy'){tot+=s.guards||0;(s.tg||[]).forEach(q=>{const k=TGN[q.k]||q.k;if(!tgs.includes(k))tgs.push(k)})}else if(s.t==='hold')tot+=6;else if(s.t==='uav'){(s.amb||[]).forEach(g=>{tot+=g.n;hv+=g.heavy||0});tot+=s.guards||0;(s.tg||[]).forEach(q=>{const k=TGN[q.k]||q.k;if(!tgs.includes(k))tgs.push(k)})}else if(s.t==='fly')fly=1});
const rows=[['HOSTILES (EST.)','~'+tot+' + reinforcements'],['HEAVY TROOPERS',hv?hv+'+':'NONE'],['COMMANDER',bs?'PRESENT':'-'],['WATCH TOWERS',di.t||'NONE'],['TOWER SNIPERS',di.s||'NONE'],['CHECKPOST',di.c?di.c+' GUARDS':'NONE'],['TARGETS',tgs.length?tgs.join(', '):'-'],['SPECIAL',fly?'JET ESCAPE + SAM MISSILES':m.uav?'UAV HELLFIRE STRIKES':m.nv?'NIGHT VISION GOGGLES':m.night?'LOW VISIBILITY':'-']];
g.font='34px Arial';rows.forEach((r,i)=>{g.fillStyle='#8fb89a';g.fillText(r[0],24,160+i*60);g.fillStyle='#fff';g.fillText(lapClip(g,String(r[1]),520),450,160+i*60)})}
LAP.tex.needsUpdate=true}
function lobSoldiers(){rd.shadowMap.needsUpdate=true;allies.forEach(a=>sc.remove(a));allies.length=0;const np=$('lnp');np.innerHTML='';lobNP.length=0;
ANAMES.forEach((n,i)=>{const f=FM[i],a=soldier('rifle',1,f[0],f[1]);a.userData.name=n;a.userData.alert=false;a.rotation.y=PI;allies.push(a);
const e=document.createElement('div');e.className='np';e.innerHTML='<div class="nn">'+(i===0?'★ ':'')+n+'</div><div class="nr">● READY</div>';np.appendChild(e);lobNP.push(e)});czSpawn()}
function lobbyTick(dt){if(prevOn){gun.position.set(.52,.02,-1.7);gun.rotation.set(.12,PI/2+Math.sin(time*.6)*.55,0);rdDirty=true}const t=time,zm=lobTab==='play',cm=lobTab==='cz',tp=cm?[6.4,1.4,3.0]:zm?[-.55,1.5,2.8]:[Math.sin(t*.12)*.8,1.4+Math.sin(t*.3)*.04,8.6-Math.sin(t*.05)*.4],tl=cm?[5.35,1.12,-1.8]:zm?[-.85,1.55,.1]:[3.6,1.45,-2],tf=cm?36:zm?38:48,kk=1-Math.exp(-Math.min(dt,.05)*3.2);
for(let i=0;i<3;i++){lobCam.p[i]+=(tp[i]-lobCam.p[i])*kk;lobCam.l[i]+=(tl[i]-lobCam.l[i])*kk}lobCam.f+=(tf-lobCam.f)*kk;
{const o=lobOrb;if(!o.dn){const dk=Math.exp(-Math.min(dt,.05)*4);o.vy*=dk;o.vp*=dk;o.yt+=o.vy*Math.min(dt,.05);o.pt=clamp(o.pt+o.vp*Math.min(dt,.05),-.5,.9)}const ke=1-Math.exp(-Math.min(dt,.05)*(o.dn?32:12));o.y+=(o.yt-o.y)*ke;o.p+=(o.pt-o.p)*ke;
const vx=lobCam.p[0]-lobCam.l[0],vy=lobCam.p[1]-lobCam.l[1],vz=lobCam.p[2]-lobCam.l[2],r=Math.hypot(vx,vy,vz)||1,az=Math.atan2(vx,vz)+o.y,el=clamp(Math.asin(clamp(vy/r,-1,1))+o.p,-.02,.9);
cam.position.set(lobCam.l[0]+r*Math.cos(el)*Math.sin(az),lobCam.l[1]+r*Math.sin(el),lobCam.l[2]+r*Math.cos(el)*Math.cos(az))}cam.lookAt(lobCam.l[0],lobCam.l[1],lobCam.l[2]);if(Math.abs(cam.fov-lobCam.f)>.05){cam.fov=lobCam.f;cam.updateProjectionMatrix()}cam.updateMatrixWorld();
const w=VW(),h=VH();if(LOBP&&lobTab!=='load'){LOBP.rotation.y=PI+Math.sin(t*.4+5)*.12-.1;LOBP.userData.ap=0;poseGun(LOBP.userData,0,dt)}if(lobTab!=='load')allies.forEach((a,i)=>{a.rotation.y=PI+Math.sin(t*.4+i*1.7)*.2-.15;a.userData.ap=0;poseGun(a.userData,0,dt);
const e=lobNP[i];if(!e)return;v3.set(a.position.x,2.2,a.position.z).project(cam);if(v3.z>1){if(e._d!==0){e._d=0;e.style.display='none'}return}if(e._d!==1){e._d=1;e.style.display='block'}const s='translate('+Math.round((v3.x*.5+.5)*w)+'px,'+Math.round((-v3.y*.5+.5)*h)+'px) translate(-50%,-100%)';if(e._t!==s){e._t=s;e.style.transform=s}})}
function lobSeg(label,key){const r=mkRow(label),g=document.createElement('div');g.className='seg';LOPT[key].forEach(id=>{const b=document.createElement('button');b.className='sm'+(LO[key]===id?' on':'');b.textContent=WD[id].s;b.onclick=()=>{LO[key]=id;lobUI()};g.appendChild(b)});r.appendChild(g);return r}
function lobSt(id){const d=WD[id],w=document.createElement('div'),v=[['DAMAGE',Math.min(100,Math.sqrt(d.dmg*d.pel/120)*100)],['FIRE RATE',Math.min(100,60/d.rate/8)],['MAGAZINE',Math.min(100,d.cap/75*100+10)],['MOBILITY',clamp((d.mv-.8)/.3*100,10,100)]];
const t=document.createElement('div');t.className='ob';t.style.cssText='padding:4px 0 2px;color:var(--acc);letter-spacing:.1em';t.textContent=d.n;w.appendChild(t);
v.forEach(x=>{const q=document.createElement('div');q.className='st';q.innerHTML='<span>'+x[0]+'</span><div class="bar"><i style="width:'+x[1].toFixed(0)+'%"></i></div>';w.appendChild(q)});return w}
function lobPlay(el){const pr=prog();el.innerHTML='<div class="lsh">SELECT OPERATION<span>'+(lobMi+1)+' / '+MS.length+'</span></div>';
const L=document.createElement('div');MS.forEach((m,i)=>{const b=document.createElement('button');b.className='mc2'+(i===lobMi?' on':'');b.disabled=i>pr;b.innerHTML='<i>'+(i+1)+'</i><span><b>'+m.n+'</b><small>'+(i>pr?'LOCKED':m.loc)+'</small></span><em>'+(i<pr?'CLEARED':i===pr?'NEW':'')+'</em>';b.onclick=()=>{lobMi=i;lobUI()};L.appendChild(b)});el.appendChild(L);
const h=document.createElement('div');h.className='lhint';h.textContent='\u25B6 LAPTOP BRIEFING';el.appendChild(h);
const pg=document.createElement('div');pg.className='pgs';['BRIEF','OBJECTIVES','INTEL'].forEach((n,i)=>{const b=document.createElement('button');b.className='sm'+(lobPg===i?' on':'');b.textContent=n;b.onclick=()=>{lobPg=i;lobUI()};pg.appendChild(b)});el.appendChild(pg)}
function lobSquad(el){el.innerHTML='<div class="kick">PARTY</div><h3 class="mt">SQUAD ALPHA</h3><div class="loc">AI SQUAD FIGHTS BESIDE YOU</div>'+
'<div class="row"><span>ALPHA-1 (YOU)</span><b>PLAYER</b></div>'+ANAMES.map(n=>'<div class="row"><span>'+n+'</span><b style="color:#7dff9c;min-width:140px">'+ROLES[n]+' · READY</b></div>').join('')}
function lobCz(el){el.innerHTML='<div class="kick">OPERATOR</div><h3 class="mt">CHARACTER CUSTOMIZATION</h3><div class="loc">DRAG TO ROTATE 360\u00b0 \u00b7 AUTO-SAVED \u00b7 SHOWS IN HANDS &amp; CUTSCENES</div>';
const css=o=>{const c=o[2];return typeof c==='number'?'#'+c.toString(16).padStart(6,'0'):'rgb('+c.join(',')+')'};
const pr=mkRow('LOOK PRESETS'),pg=document.createElement('div');pg.className='seg';
CZP.forEach(p=>{const b=document.createElement('button');b.className='sm';b.textContent=p[0];b.onclick=()=>{Object.assign(CZ,CZ0,p[1]);czCommit()};pg.appendChild(b)});
{const b=document.createElement('button');b.className='sm';b.textContent='\u2684 RANDOM';b.onclick=()=>{for(const k in CZ0){const l=CZL[k];CZ[k]=l[(Math.random()*l.length)|0][0]}czCommit()};pg.appendChild(b)}
{const b=document.createElement('button');b.className='sm';b.textContent='RESET';b.onclick=()=>{Object.assign(CZ,CZ0);czCommit()};pg.appendChild(b)}
pr.appendChild(pg);el.appendChild(pr);
CZG.forEach(g=>{const r=mkRow(g[1]),sg=document.createElement('div');sg.className='seg';CZL[g[0]].forEach(o=>{const b=document.createElement('button'),on=CZ[g[0]]===o[0];if(g[2]==='c'){b.className='sw'+(on?' on':'');b.style.background=css(o);b.title=o[1]}else{b.className='sm'+(on?' on':'');b.textContent=o[1]}b.onclick=()=>{CZ[g[0]]=o[0];czCommit()};sg.appendChild(b)});r.appendChild(sg);el.appendChild(r)})}
function lobCar(el){const r=rankOf();let best=0;try{best=+localStorage.getItem('mo_best')||0}catch(e){}
el.innerHTML='<div class="kick">SERVICE RECORD</div><h3 class="mt">'+r.name+'</h3><div class="loc">LEVEL '+r.L+'</div>'+
[['TOTAL XP',r.xp],['NEXT RANK AT',r.next+' XP'],['MISSIONS CLEARED',Math.min(prog(),MS.length)+' / '+MS.length],['BEST SCORE',best]].map(x=>'<div class="row"><span>'+x[0]+'</span><b style="min-width:100px">'+x[1]+'</b></div>').join('')}
function lobUI(){const el=$('lbody'),st=el.scrollTop,rk=rankOf();
$('ltabs').querySelectorAll('button').forEach(b=>b.classList.toggle('on',b.dataset.t===lobTab));
$('lcard').innerHTML='<div><b>ALPHA-1'+(window.MO_BADGE?window.MO_BADGE():'')+'</b>'+rk.name+' · LV '+rk.L+'<div class="xpb"><i style="width:'+(rk.p*100).toFixed(0)+'%"></i></div></div><div class="rk">'+rk.L+'</div>';
$('lparty').innerHTML='<div class="pc me"><i>'+rk.L+'</i><b>ALPHA-1'+(window.MO_BADGE?window.MO_BADGE():'')+'</b><small>'+rk.name+' \u00b7 LEADER</small><em>READY</em></div>'+ANAMES.map(n=>'<div class="pc"><i>AI</i><b>'+n+'</b><small>'+ROLES[n]+'</small><em>READY</em></div>').join('');$('ldsub').textContent=(lobMi+1)+' \u00b7 '+MS[lobMi].n;
if(lobTab==='play')lobPlay(el);else if(lobTab==='load')lobLoad(el);else if(lobTab==='squad')lobSquad(el);else if(lobTab==='cz')lobCz(el);else lobCar(el);lobPrev(lobTab==='load');lwcSync();lapDraw();el.scrollTop=st}
TABS.forEach(t=>{const b=document.createElement('button');b.textContent=t[1];b.dataset.t=t[0];b.onclick=()=>{lobTab=t[0];lobUI()};$('ltabs').appendChild(b)});
function openLobby(i){MO_ASSETS.load();lobPg=0;lobCam.p=[0,1.4,8.6];lobCam.l=[3.6,1.45,-2];lobCam.f=48;Object.assign(lobOrb,{y:0,yt:0,p:0,pt:0,vy:0,vp:0,dn:false});lgT=lgN=0;lgLock=0;lgW=2;lgUp=0;lobMi=clamp(i,0,prog());mi=lobMi;inLobby=true;run=false;lobTab='play';Object.assign(P,{x:0,z:0,y:1.7});['menu','over','pause','set','mis','how'].forEach(closeOv);buildLobby();lobSoldiers();cam.fov=48;cam.updateProjectionMatrix();lobUI();applyS();openOv('lobby')}
function lwcReset(){czKill();gunLit(false);sky.visible=true;world.visible=true;allies.forEach(a=>a.visible=true);$('lnp').style.display='';$('lwcbg').style.display='none'}
function exitLobby(){lwcReset();inLobby=false;lobPrev(0);saveLO();allies.forEach(a=>sc.remove(a));allies.length=0;lobNP.length=0;closeOv('lobby');menuWorld();applyS();openOv('menu');refreshMenu()}
function lwcSync(){const c=lobTab==='load';rd.shadowMap.needsUpdate=true;gunLit(c);if(prevOn)gun.scale.setScalar(c?1.15:.85);world.visible=!c;sky.visible=!c;const zc=lobTab==='cz';allies.forEach(a=>a.visible=!c&&!zc);if(LOBP)LOBP.visible=!c;$('lnp').style.display=c||zc?'none':'';$('lwcbg').style.display=c?'block':'none';rdDirty=true;const b=$('lwc');b.textContent=lobTab==='load'?'\u25C0 CLOSE CUSTOMIZATION':'WEAPONS CUSTOMIZATION';b.classList.toggle('on',lobTab==='load')}
$('lwc').onclick=()=>{lobTab=lobTab==='load'?'play':'load';lobUI()};
$('lback').onclick=()=>{if(lobTab==='load'){lobTab='play';lobUI()}else exitLobby()};$('lset').onclick=()=>{buildSet();openOv('set')};
$('ldep').onclick=()=>{lwcReset();AC();full();inLobby=false;lobPrev(0);applyS();saveLO();xpBank=0;closeOv('lobby');mi=lobMi;score=0;NET.gs=0;startMission()};
{const L=$('lobby'),o=lobOrb;let pid=null,lx=0,ly=0,lt=0;
L.addEventListener('pointerdown',e=>{if(!inLobby||pid!==null||(e.pointerType==='mouse'&&e.button!==0)||e.target.closest('button,input,textarea,select,.scr,#lbody,.pgs'))return;pid=e.pointerId;lx=e.clientX;ly=e.clientY;lt=performance.now();o.dn=true;o.vy=o.vp=0;try{L.setPointerCapture(pid)}catch(_){}const h=$('lrot');if(h)h.style.opacity=0});
L.addEventListener('pointermove',e=>{if(e.pointerId!==pid)return;const n=performance.now(),dts=Math.max(.008,(n-lt)/1e3),dx=e.clientX-lx,dy=e.clientY-ly,a=-dx*.006,b=dy*.004;lx=e.clientX;ly=e.clientY;lt=n;o.yt+=a;o.pt=clamp(o.pt+b,-.5,.9);o.vy=o.vy*.6+clamp(a/dts,-8,8)*.4;o.vp=o.vp*.6+clamp(b/dts,-4,4)*.4;e.preventDefault()});
const up=e=>{if(e.pointerId!==pid)return;pid=null;o.dn=false;if(performance.now()-lt>90)o.vy=o.vp=0;try{L.releasePointerCapture(e.pointerId)}catch(_){}};
L.addEventListener('pointerup',up);L.addEventListener('pointercancel',up)}
addEventListener('keydown',e=>{if(!inLobby||$('set').style.display==='flex')return;if(e.code==='Enter')$('ldep').click();else if(e.code==='Escape')$('lback').click();
else if(e.code==='ArrowLeft'&&lobTab==='play'&&lobMi>0){lobMi--;lobUI()}else if(e.code==='ArrowRight'&&lobTab==='play'&&lobMi<prog()){lobMi++;lobUI()}else{const d=/^Digit([1-3])$/.exec(e.code);if(d){lobTab=TABS[+d[1]-1][0];lobUI()}}});
function ui(){}
let lastHud='';
function hud(){$('hpb').style.width=clamp(P.hp,0,100)+'%';$('hpb').style.background=P.hp>60?'#7fb04a':P.hp>30?'#e0b030':'#d04030';let a='';if(WS){const d=wd,sp=d.type==='mag'?WS.mags.reduce((x,m)=>x+m,0):WS.rsv,cnt=WS.ammo+WS.ch,low=cnt<=Math.max(2,d.cap*.25|0);a=d.type==='melee'?d.n:d.n+' · '+(d.type==='shell'?'PUMP':d.auto?'AUTO':'SEMI')+'<br><span style="font-size:1.35em;color:'+(cnt===0?'#ff5a4a':low?'#ffb35a':'inherit')+'">'+cnt+'</span> / '+sp+(d.type==='mag'?' ▮'+WS.mags.length:'')}
const s2='MISSION '+(mi+1)+'|SCORE '+score+'|'+a;if(s2!==lastHud){lastHud=s2;$('wv').textContent='MISSION '+(mi+1);$('sc').textContent='SCORE '+score;$('am').innerHTML=a}
const sg=SL.map(w=>w?w.id+(wTotal(w)?1:0):'').join()+cs;if(sg!==wbSig){wbSig=sg;refreshSlots()}if(PV.on){$('wv').textContent=PV.l1;$('sc').textContent=PV.l2}else if(NET.on){$('sc').textContent='SCORE '+score+' \u00b7 PARTNER '+(NET.h?(NET.gs||0):(NET.hs||0))}}
function ctl(v){if(!v){CR.on=0;if(typeof CTL!=='undefined')CTL.reset()}nvUI(v);$('hud').style.display=v?'block':'none';['fire','ads','jump','rel','crb','stick','swb','grb','mkb'].forEach(i=>$(i).style.display=v?'block':'none');$('wbar').style.display=v?'flex':'none';$('pgb').style.display=$('cmb').style.display=v&&NET.on&&!PV.on?'block':'none';if(!v)cmToggle(0);if(!v){$('pk').style.display='none';$('scp').style.opacity=0;$('adsv').style.opacity=0;scAv='';$('fmb').style.display='none';fmS='';try{gren.forEach(g=>sc.remove(g.m));gren.length=0}catch(e){}$('zmb').style.display=$('brb').style.display='none';scBtn=0;scHold=false;scopeOn=false}gun.visible=!!v}
const CS={t:0,k:0,k2:0,dur:1,sp:''};let CH=null,PCH=null,PLN=null,BT=null,CV=null;
function mkPCH(){PCH=new THREE.Group();PCH.userData.o=[[0,0],[-5,2.5],[5,3.2],[-2.5,-5.5]];const D=mt('dark'),O=mt('olive'),cols=['olive','red','white','olive'];
PCH.userData.o.forEach((o,i)=>{const g=new THREE.Group(),a=(geo,m,x,y,z)=>mesh(geo,m,x,y,z,{p:g,cs:false});a(Bx(.5,1.1,.45),O,0,0,0);a(Bx(.36,.36,.36),D,0,.78,0);const ar=a(Bx(1.7,.14,.3),O,0,.3,0);
const cm=mt(cols[i]).clone();cm.side=THREE.DoubleSide;const c=new THREE.Mesh(new THREE.SphereGeometry(2.6,14,8,0,Math.PI*2,0,Math.PI/2),cm);c.position.y=4.2;g.add(c);
const ln=[];for(const sd of[-1,1]){const l=a(Bx(.04,4,.04),D,sd*.9,2.2,0);l.rotation.z=-sd*.2;ln.push(l)}g.userData={c:c,ar:ar,ln:ln};PCH.add(g)});
PLN=new THREE.Group();const b=(geo,m,x,y,z)=>mesh(geo,m,x,y,z,{p:PLN,cs:false});b(Bx(3.4,3.2,16),mt('white'),0,0,0);b(Bx(22,.4,3.6),mt('stl'),0,-.2,0);b(Bx(.4,4.2,2.6),mt('stl'),0,2.8,-6.5);b(Bx(7,.3,2.2),mt('stl'),0,.6,-6.8);
sc.add(PCH);sc.add(PLN)}
function mkCV(){CV=new THREE.Group();const O=mt('olive'),D=mt('dark');
const mk=(parts,wh)=>{const g=new THREE.Group(),a=(geo,m,x,y,z)=>mesh(geo,m,x,y,z,{p:g,cs:false});parts.forEach(q=>a(Bx(q[0],q[1],q[2]),q[3]?D:O,q[4],q[5],q[6]));
wh.forEach(w=>{const e=a(new THREE.CylinderGeometry(w[3],w[3],.45,12),D,w[0],w[3],w[1]);e.rotation.z=PI/2;(g.userData.w=g.userData.w||[]).push(e)});CV.add(g);return g};
mk([[1.9,.7,3.6,0,0,.85,0],[1.7,.4,1.3,0,0,1.25,-1.5],[1.7,.7,.1,1,0,1.5,-.55],[.12,.9,.12,1,-.8,1.5,.6],[.12,.9,.12,1,.8,1.5,.6],[1.9,.12,.12,1,0,1.95,.6],[2,.25,.2,1,0,.55,-1.9],[.5,.5,1.3,1,0,1.4,1.4]],[[-1,-1.2,.45],[1,-1.2,.45],[-1,1.2,.45],[1,1.2,.45]]);
mk([[2.3,.6,6.6,0,0,.8,0],[2.2,1.5,1.9,0,0,1.8,-2.3],[1.9,.6,.1,1,0,2.05,-3.27],[2.4,1.8,3.9,0,0,2.1,1.5],[2.5,.2,4,1,0,1.1,1.5],[2.4,.3,.25,1,0,.6,-3.45]],[[-1.15,-2.3,.55],[1.15,-2.3,.55],[-1.15,1.2,.55],[1.15,1.2,.55],[-1.15,2.6,.55],[1.15,2.6,.55]]);
sc.add(CV)}
function mkBT(){BT=new THREE.Group();const O=mt('olive'),D=mt('dark'),a=(geo,m,x,y,z)=>mesh(geo,m,x,y,z,{p:BT,cs:false});a(Bx(2.2,.5,7),D,0,.25,0);const bw=a(Bx(1.4,.5,2),D,0,.34,4.2);bw.rotation.x=-.25;
a(Bx(.75,.7,7.6),O,-1.25,.65,0);a(Bx(.75,.7,7.6),O,1.25,.65,0);a(Bx(.5,.9,.5),D,0,.9,-3.7);a(Bx(.08,.08,1.6),D,0,1.4,-3.7);
for(const q of[[-.5,1.2],[.5,1.2],[-.5,-.6],[.5,-.6]]){a(Bx(.55,1,.45),O,q[0],1.15,q[1]);a(Bx(.38,.38,.38),D,q[0],1.85,q[1])}sc.add(BT)}
const ENT={heli:[['EAGLE-1','Alpha team, this is Eagle-1. We are over the landing zone now. Doors open, hit the ground running and move out!',6],['SGT. KHAN','Chopper is gone, sir. Stay low and follow me.',1]],
para:[['EAGLE-1','Alpha team, we are over the drop zone. Green light, go go go! Open your chutes and steer for the landing zone!',8],['SGT. KHAN','Touchdown. Cut your chutes and regroup, Alpha. Move out!',1]],
convoy:[['SGT. KHAN','Alpha team, the convoy drops us at the edge of the jungle. The camp is a short walk ahead. Dismount, spread out and keep your eyes open!',10],['CPT. RAWAT','Trucks are heading back, so no turning around now. Stay quiet, Alpha.',1]],
boat:[['EAGLE-1','Alpha team, the boat is closing in on the rig. The storm is heavy, so keep your heads down and your weapons dry!',9],['SGT. KHAN','We are at the platform, sir. Climb up to the deck and stay quiet.',1]]};
TF.heliBody=()=>mkT(512,(u,v)=>{
const q=fbm(u,v,4,4)*.62+fbm(u+.31,v+.17,8,3)*.38,j=q+R()*.05;
let c=j<.38?[52,60,42]:j<.5?[82,88,60]:j<.62?[108,98,68]:[44,50,36];
const e=Math.min(u,1-u),bb=ss(.12,.06,e);
if(bb>0)c=[c[0]+(124-c[0])*bb,c[1]+(130-c[1])*bb,c[2]+(124-c[2])*bb];
const st=vn(u*64,v*3,64),dirt=1-.28*Math.max(0,st-.52)*2.2,k=(.82+.3*fbm(u+.6,v+.4,16,3))*dirt;
return[c[0]*k,c[1]*k,c[2]*k,.5+.25*fbm(u,v,16,3)+.1*R()]},(g,gb,s)=>{
const L=(x0,y0,x1,y1,a)=>{g.strokeStyle='rgba(12,14,9,'+a+')';g.lineWidth=1.3;g.beginPath();g.moveTo(x0,y0);g.lineTo(x1,y1);g.stroke();gb.strokeStyle='#000';gb.lineWidth=1.6;gb.beginPath();gb.moveTo(x0,y0);gb.lineTo(x1,y1);gb.stroke()};
for(const f of[.1,.17,.24,.3,.36,.43,.5,.56,.62,.68,.75,.82,.88]){const y=f*s;L(0,y,s,y,.55);g.fillStyle='rgba(18,20,14,.6)';for(let x=3;x<s;x+=8)g.fillRect(x,y+3,1.5,1.5);g.fillStyle='rgba(200,200,170,.25)';for(let x=3;x<s;x+=8)g.fillRect(x-.5,y+2.5,1,1)}
for(const cx of[.25,.75])for(const d of[[.43,.56],[.3,.42]]){const x0=(cx-.09)*s,x1=(cx+.09)*s,y0=d[0]*s,y1=d[1]*s;g.strokeStyle='rgba(8,10,6,.8)';g.lineWidth=1.8;g.strokeRect(x0,y0,x1-x0,y1-y0);gb.strokeStyle='#000';gb.lineWidth=2.2;gb.strokeRect(x0,y0,x1-x0,y1-y0);g.fillStyle='rgba(170,170,150,.6)';g.fillRect(x0+4,(y0+y1)/2,3,8)}
const tx=(t,cx,cy,rot,sz,sx)=>{g.save();g.translate(cx*s,cy*s);g.rotate(rot);g.scale(sx,1);g.font='bold '+sz+'px Arial';g.fillStyle='rgba(226,220,196,.88)';g.textAlign='center';g.textBaseline='middle';g.fillText(t,0,0);g.restore()};
tx('EAGLE-1',.25,.77,PI/2,80,.1);tx('EAGLE-1',.75,.77,-PI/2,80,.1);tx('ALPHA',.25,.6,PI/2,21,.43);tx('ALPHA',.75,.6,-PI/2,21,.43);
for(let i=0;i<260;i++){g.fillStyle='rgba(20,16,10,'+(.04+R()*.1)+')';g.fillRect(R()*s,R()*s,1+R()*5,2+R()*18)}
for(let i=0;i<16;i++){g.fillStyle='rgba(30,22,10,'+(.1+R()*.14)+')';g.beginPath();g.arc(R()*s,R()*s,1+R()*3,0,7);g.fill()}});
Object.assign(MF,{heliBody:()=>M(tx('heliBody'),{roughness:.52,metalness:.28,bumpScale:1.6,envMapIntensity:.7}),
heliGlass:()=>new THREE.MeshStandardMaterial({color:0x1d3040,roughness:.06,metalness:.55,transparent:true,opacity:.92,emissive:0x04080c,envMapIntensity:1.4,polygonOffset:true,polygonOffsetFactor:-2,polygonOffsetUnits:-2}),
heliDark:()=>S(0x15171a,.55,.5),heliBlade:()=>S(0x1a1b19,.5,.35),heliYel:()=>S(0xd8b020,.55,.1),
heliRed:()=>new THREE.MeshBasicMaterial({color:0xff2a2a}),heliGrn:()=>new THREE.MeshBasicMaterial({color:0x2aff5a}),heliWht:()=>new THREE.MeshBasicMaterial({color:0xffffff}),
heliDisc:()=>new THREE.MeshBasicMaterial({color:0x8a8e90,transparent:true,opacity:.1,depthWrite:false,side:THREE.DoubleSide})});
function uvr(g,u0,v0,k){const a=g.attributes.uv;for(let i=0;i<a.count;i++)a.setXY(i,u0+a.getX(i)*k,v0+a.getY(i)*k);return g}
function mkCH(){CH=new THREE.Group();CH.rotation.order='YXZ';
const V2=THREE.Vector2,V3=THREE.Vector3,B=mt('heliBody'),GL=mt('heliGlass'),DK=mt('heliDark'),BL=mt('heliBlade'),YL=mt('heliYel'),OL=mt('olive');
const add=(geo,m,x,y,z,o)=>mesh(geo,m,x,y,z,Object.assign({p:CH},o||{}));
const lim=(a,b,r,m)=>{const d=new V3().subVectors(b,a),Ln=d.length(),g=new THREE.CylinderGeometry(r,r,Ln,8);g.translate(0,Ln/2,0);g.rotateX(PI/2);const e=new THREE.Mesh(g,m);e.position.copy(a);e.lookAt(b);e.castShadow=true;CH.add(e);return e};
const cp=[[.10,-9.4],[.16,-9.0],[.26,-7],[.36,-5],[.62,-3.6],[.95,-2.6],[1.12,-1.6],[1.18,0],[1.16,1.6],[1.05,2.6],[.82,3.4],[.52,4.0],[.22,4.4],[.02,4.6]].map(a=>new V2(a[0],a[1]));
const pts=new THREE.SplineCurve(cp).getPoints(LITE?40:72).map(p=>new V2(Math.max(.001,p.x),p.y));
const lz=(P,seg,p0,p1)=>{const g=new THREE.LatheGeometry(P,seg,p0,p1-p0);g.rotateX(PI/2);g.scale(1,1.12,1);return g};
const patch=(z0,z1,off)=>pts.filter(p=>p.y>=z0&&p.y<=z1).map(p=>new V2(p.x+off,p.y));
const NG={cs:false};
add(lz(pts,LITE?16:30,0,2*PI),B,0,0,0);
const win=(z0,z1,p0,p1)=>{add(lz(patch(z0-.12,z1+.12,.011),8,p0-.07,p1+.07),DK,0,0,0,NG);add(lz(patch(z0,z1,.02),8,p0,p1),GL,0,0,0,NG)};
win(2.15,3.9,PI-1.05,PI+1.05);add(lz(patch(2.15,3.9,.03),2,PI-.03,PI+.03),DK,0,0,0,NG);
for(const q of[[.9,2.3],[-1.6,.3]]){win(q[0],q[1],PI/2-.2,PI/2+.55);win(q[0],q[1],3*PI/2-.55,3*PI/2+.2)}
const fs=new THREE.Shape();fs.moveTo(0,0);fs.lineTo(2.9,0);fs.lineTo(2.55,2.5);fs.lineTo(1.5,2.5);fs.lineTo(0,0);
const fg=uvr(new THREE.ExtrudeGeometry(fs,{depth:.14,bevelEnabled:false}),.38,.45,.05),fin=add(fg,B,-.07,.12,-6.45);fin.rotation.y=PI/2;
add(uvr(new THREE.BoxGeometry(3.4,.07,.75),.4,.5,.06),B,0,.2,-8.2);for(const s of[-1,1])add(uvr(new THREE.BoxGeometry(.06,.5,.7),.4,.5,.06),B,s*1.7,.3,-8.2);
const tr=new THREE.Group();tr.position.set(.17,2.1,-9.15);CH.add(tr);
{const h=new THREE.CylinderGeometry(.09,.09,.12,10);h.rotateZ(PI/2);tr.add(new THREE.Mesh(h,DK));tr.add(new THREE.Mesh(new THREE.BoxGeometry(.025,1.5,.13),BL));tr.add(new THREE.Mesh(new THREE.BoxGeometry(.025,.13,1.5),BL));
const d=new THREE.CircleGeometry(.78,20);d.rotateY(PI/2);tr.add(new THREE.Mesh(d,mt('heliDisc')))}
for(const s of[-1,1]){const g=new THREE.CylinderGeometry(.3,.3,2.5,16);g.rotateX(PI/2);uvr(g,.42,.52,.08);add(g,B,s*.5,1.4,-.95);
const ex=new THREE.ConeGeometry(.24,.7,12);ex.rotateX(-PI/2);add(ex,DK,s*.5,1.4,-2.55);
const it=new THREE.CylinderGeometry(.25,.25,.1,14);it.rotateX(PI/2);add(it,DK,s*.5,1.4,.34)}
add(uvr(new THREE.CylinderGeometry(.5,.62,.4,20),.42,.52,.08),B,0,1.58,.3);add(new THREE.CylinderGeometry(.14,.14,.5,12),DK,0,1.9,.3);
const r=new THREE.Group();r.position.set(0,2.15,.3);CH.add(r);
r.add(new THREE.Mesh(new THREE.CylinderGeometry(.32,.32,.2,16),DK));
for(let i=0;i<4;i++){const bg=new THREE.Group();bg.rotation.y=i*PI/2;r.add(bg);
const bm=new THREE.Mesh(new THREE.BoxGeometry(7.2,.045,.52),BL);bm.position.x=4.1;bm.rotation.x=.06;bg.add(bm);
const tp=new THREE.Mesh(new THREE.BoxGeometry(.6,.05,.52),YL);tp.position.x=7.4;tp.rotation.x=.06;bg.add(tp);
const gr=new THREE.Mesh(new THREE.BoxGeometry(.5,.12,.3),DK);gr.position.x=.55;bg.add(gr)}
{const d=new THREE.CircleGeometry(7.5,LITE?24:48);d.rotateX(-PI/2);r.add(new THREE.Mesh(d,mt('heliDisc')))}
for(const s of[-1,1]){add(uvr(new THREE.BoxGeometry(1.5,.07,.55),.4,.5,.06),B,s*1.85,-.28,.15);add(Bx(.08,.3,.3),DK,s*2.15,-.42,.2);
const pd=new THREE.CylinderGeometry(.16,.16,1.3,12);pd.rotateX(PI/2);add(pd,OL,s*2.15,-.62,.3);
const pc=new THREE.ConeGeometry(.16,.3,12);pc.rotateX(PI/2);add(pc,DK,s*2.15,-.62,1.1)}
{const t=add(new THREE.SphereGeometry(.26,16,12),DK,0,-.88,3.05);t.scale.y=.9;add(new THREE.SphereGeometry(.1,10,8),GL,0,-.9,3.28,NG)}
lim(new V3(0,.05,4.55),new V3(0,.05,5.1),.015,DK);lim(new V3(.3,1.3,-3.2),new V3(.45,1.9,-3.7),.012,DK);
for(const s of[-1,1]){const sx=s*1.28;lim(new V3(sx,-1.9,-2.4),new V3(sx,-1.9,2.5),.06,DK);lim(new V3(sx,-1.9,2.5),new V3(sx,-1.55,3.1),.06,DK);
lim(new V3(s*.75,-1.15,1.2),new V3(sx,-1.9,1.2),.05,DK);lim(new V3(s*.8,-1.15,-1.2),new V3(sx,-1.9,-1.2),.05,DK)}
lim(new V3(-1.28,-1.9,1.2),new V3(1.28,-1.9,1.2),.04,DK);lim(new V3(-1.28,-1.9,-1.2),new V3(1.28,-1.9,-1.2),.04,DK);
const bulb=(m,x,y,z)=>{const e=new THREE.Mesh(new THREE.SphereGeometry(.07,8,6),m);e.position.set(x,y,z);CH.add(e);return e};
bulb(mt('heliRed'),2.45,-.22,.1);bulb(mt('heliGrn'),-2.45,-.22,.1);
CH.userData.r=r;CH.userData.tr=tr;CH.userData.lt=[bulb(mt('heliWht'),0,2.66,-8.8),bulb(mt('heliRed'),0,-1.38,-1)];sc.add(CH)}
function camCut(){const t=CS.t,u=Math.min(1,t/CS.dur),e=u*u*(3-2*u),cx=P.x,cz=P.z+4;let px,py,pz,lx=cx,ly=1.3,lz=cz,fv=45;
switch(CS.k){
case 0:px=cx-10+u*6;py=15-e*12;pz=cz-24+e*10;fv=52-u*8;break;
case 1:px=cx-9+u*9;py=1.1+u*.3;pz=cz-6;lx=cx+u*2;fv=40;break;
case 2:{const a=allies.find(a=>CS.sp.indexOf(a.userData.name)>=0)||allies[0];if(a){lx=a.position.x;lz=a.position.z;ly=1.55;px=lx+1.6-u*.5;pz=lz-1.8+u*.5;py=1.5}else{px=cx;py=2;pz=cz-6}fv=30-u*5;break}
case 3:{const an=CS.t*.22+CS.k2,r=8-u*2.5;px=cx+Math.cos(an)*r;pz=cz+Math.sin(an)*r;py=1.7+u*.6;fv=42;break}
case 5:{const pl=CRASH.g,uu=Math.min(1,cutT/8);if(pl&&!CRASH.done){pl.visible=true;const e2=Math.pow(uu,1.6);pl.position.set(lerp(-14,-9,uu),lerp(70,2.4,e2),lerp(-30,72,uu));pl.rotation.set(.35+uu*.25,0,uu*uu*3.2);
puff({x:pl.position.x,y:pl.position.y,z:pl.position.z-4,sz:3,life:1.6,col:0x2a2a2a,grow:4,op:.7});puff({x:pl.position.x,y:pl.position.y,z:pl.position.z-3,sz:2,life:.3,col:0xff8a2a,add:1,grow:2,op:.9});if(uu>=1)crashHit()}
px=14;py=4.5;pz=60;if(CRASH.done){lx=-9;ly=3;lz=74;$('dmg').style.opacity=Math.max(0,1.2-(cutT-8)*.9)}else if(pl){lx=pl.position.x;ly=pl.position.y;lz=pl.position.z}fv=CRASH.done?50:42;break}
case 6:{if(!CH)mkCH();CH.visible=true;const q=Math.min(1,CS.t/Math.max(CS.dur,3)),k1=1-Math.pow(1-q,2),hx=cx+lerp(-46,6,k1),hy=lerp(26,7,q),hz=cz-lerp(34,10,q);CH.position.set(hx,hy,hz);CH.rotation.set(-.1*(1-q)+Math.sin(time*1.3)*.012,Math.atan2(cx-hx,cz-hz),Math.sin(time*2)*.03-(1-q)*.05);const hu=CH.userData;hu.r.rotation.y=time*35;hu.tr.rotation.x=time*55;hu.lt[0].visible=Math.sin(time*8)>.7;hu.lt[1].visible=Math.sin(time*5+1)>.5;if(hy<12&&R()<.6)puff({x:hx+(R()-.5)*4,y:.3,z:hz+(R()-.5)*4,vx:(R()-.5)*7,vy:.5,vz:(R()-.5)*7,sz:1.4,life:1.2,col:0xb8a98a,grow:3,op:.35});px=cx-5;py=1.5;pz=cz+5;lx=hx;ly=hy;lz=hz;fv=40;break}
case 7:px=cx+Math.sin(u*.6)*2;py=1.15+u*.25;pz=cz+11-u*6;lx=cx;ly=1.7;lz=cz-14;fv=34;break;
case 8:{if(!PCH)mkPCH();PCH.visible=PLN.visible=true;if(!CS.fg&&sc.fog){CS.fg=[sc.fog.near,sc.fog.far];sc.fog.near=Math.max(sc.fog.near,120);sc.fog.far=Math.max(sc.fog.far,520)}
const op=ss(.42,.5,u),ll=ss(.93,1,u),ty=u<.45?lerp(165,70,u/.45):lerp(70,1.9,Math.pow((u-.45)/.55,.8)),tx=cx+(1-u)*18,tz=cz-3-(1-u)*26;PCH.position.set(tx,ty,tz);
PCH.children.forEach((g,i)=>{const o=PCH.userData.o[i],d=g.userData;g.position.set(o[0]+Math.sin(time*1.3+i)*.3,Math.sin(time*1.7+i*2)*.25,o[1]);g.rotation.z=Math.sin(time*.9+i)*.08*op;d.c.visible=op>.02;d.c.scale.set(op,.55*op*(1-ll*.85),op);d.c.position.y=4.2-ll*3.2;d.ar.visible=op<.3;d.ln.forEach(l=>l.visible=op>.5&&ll<.6)});
allies.forEach(a=>a.visible=u>=.97);PLN.visible=u<.35;PLN.rotation.y=PI;PLN.position.set(tx+9,170,tz+8-u*260);
if(u>.94&&R()<.6)puff({x:tx+(R()-.5)*10,y:.3,z:tz+(R()-.5)*8,vx:(R()-.5)*3,vy:.6,vz:(R()-.5)*3,sz:1.2,life:1.1,col:0xb8a98a,grow:2.6,op:.35});
px=tx-3+Math.sin(time*.5)*1.5;py=ty+4-ll*2.6;pz=tz+14;lx=tx;ly=ty-.5;lz=tz;fv=u<.45?62:48;break}
case 10:{if(!CV)mkCV();CV.visible=true;const q=Math.min(1,t/Math.max(CS.dur*.8,3.5)),k1=1-Math.pow(1-q,2.2),sp=Math.pow(1-q,1.2),vx=cx+7;
CV.children.forEach((g,i)=>{const z0=i?cz+84:cz+70,z1=i?cz+19:cz+8,vz=lerp(z0,z1,k1);g.position.set(vx+(i?.3:0),Math.sin(time*15+i*2)*.035*sp,vz);g.rotation.set(Math.sin(time*9+i)*.012*sp-sp*.0,PI*0,Math.sin(time*7+i)*.02*sp);
(g.userData.w||[]).forEach(w=>w.rotation.x-=sp*.5);
if(sp>.12&&R()<.8)puff({x:vx+(R()-.5)*2.4,y:.35,z:vz+3.4,vx:(R()-.5)*2.5,vy:.9,vz:2.4,sz:1.7,life:1.3,col:0xb8a98a,grow:3.2,op:.42})});
allies.forEach(a=>a.visible=q>=.92);
const jz=CV.children[0].position.z;px=cx+15;py=1.7+q*.3;pz=cz+30-q*18;lx=vx;ly=1.4;lz=jz;fv=48;break}
case 9:{if(!BT)mkBT();BT.visible=true;const bz=lerp(105,40,Math.pow(u,.8)),bx=cx+Math.sin(u*2)*3,by=-8.55+Math.sin(time*2.2)*.22;BT.position.set(bx,by,bz);BT.rotation.set(Math.sin(time*1.9)*.06+.02,PI,Math.sin(time*1.4)*.07);
if(R()<.8)puff({x:bx+(R()-.5),y:by+.2,z:bz+3.8,vx:(R()-.5)*2,vy:1.5,vz:3,sz:.9,life:.7,col:0xffffff,grow:1.4,op:.5});
px=bx+5.5;py=by+3.2;pz=bz+11;lx=bx;ly=by+1.5;lz=bz-14;fv=55;break}
default:px=cx+Math.sin(u*.8)*4;py=42-e*8;pz=cz+7;fv=38}
const sx=Math.sin(time*7.3)*.012+Math.sin(time*13.1)*.006,sy=Math.sin(time*9.7)*.01+Math.sin(time*17.3)*.005;
cam.position.set(px+sx,py+sy,pz);cam.lookAt(lx,ly,lz);cam.rotation.z+=Math.sin(time*5.1)*.003;
if(Math.abs(cam.fov-fv)>.05){cam.fov=fv;cam.updateProjectionMatrix()}
$('cfade').style.opacity=Math.max(0,1-t/.4);const uv=CS.k===4;document.body.classList.toggle('uav',uv);
if(uv){const sec=Math.floor(time*1)%60;$('uavt').textContent='UAV-7 · LIVE FEED · ALT '+Math.round(py)+'M';$('uavm').textContent=(cur?cur.loc:'')+' · '+(sec<10?'0':'')+sec+'s · '+(sec%2?'● REC':'○ REC')}}
async function cutscene(lines,objs,sC,eC){cin=true;skipF=false;cutT=0;ctl(0);document.body.classList.add('cin');$('skip').style.display='block';$('obc').style.opacity=0;let rn=0,cn=0;
if(sC){CS.k=0;CS.k2=mi;CS.t=0;CS.dur=9;const cc=$('ccard');cc.innerHTML=sC;cc.style.opacity=1;let a=0;while(a<3000&&!skipF){await sleep(100);a+=100}cc.style.opacity=0}else $('ccard').style.opacity=0;
for(let i=0;i<lines.length;i++){if(skipF)break;const l=lines[i],r=l[0].indexOf('RAWAT')>=0;const nL=lines.length;CS.k=l[2]!==undefined?l[2]:eC&&i===nL-1?6:eC&&i===0?3:sC&&objs&&i===nL-1&&i>0?7:i===0?0:r?[4,3,0][rn++%3]:[2,1][cn++%2];CS.sp=l[0];CS.k2=i;CS.t=0;if(CS.k===6)nz(3.5,700,150,.22,'lowpass');if(CS.k===8)nz(7,1800,350,.2,'lowpass');if(CS.k===9)nz(6,900,300,.2,'lowpass');if(CS.k===10)nz(6,500,200,.22,'lowpass');const ms=Math.max(2800,l[1].length*70);CS.dur=ms/1000;say(l[0],l[1]);let a=0;
while(a<ms&&!skipF){const n=Math.min(l[1].length,Math.floor(a/(ms*.6)*l[1].length)+1);sub(l[0],l[1].slice(0,n));await sleep(60);a+=60}}
if(objs&&objs.length&&!skipF){sub('','');CS.k=3;CS.k2=mi;CS.t=0;CS.dur=5;$('obc').innerHTML='<b>MISSION OBJECTIVES</b>'+objs.slice(0,6).map((o,i)=>(i+1)+'. '+o).join('<br>');$('obc').style.opacity=1;let a=0;while(a<4500&&!skipF){await sleep(100);a+=100}}
if(eC){sub('','');CS.k=3;CS.t=0;CS.dur=6;const cc=$('ccard');cc.innerHTML=eC;cc.style.opacity=1;let a=0;while(a<6200&&!skipF){await sleep(100);a+=100}}
try{speechSynthesis.cancel()}catch(e){}sub('','');$('obc').style.opacity=0;document.body.classList.remove('cin','uav');$('skip').style.display='none';if(CH)CH.visible=false;if(BT)BT.visible=false;if(CV)CV.visible=false;if(PCH)PCH.visible=false;if(PLN)PLN.visible=false;allies.forEach(a=>a.visible=true);if(CS.fg){sc.fog.near=CS.fg[0];sc.fog.far=CS.fg[1];CS.fg=null}cin=false}
$('skip').onclick=()=>skipF=true;
const OUTX=[[['SGT. KHAN','Sir, the radar and fuel depot are both ashes. The enemy base has gone blind.'],['EAGLE-1','Alpha team, Eagle-1 is above you. The LZ is clear, get on the chopper!']],
[['SGT. KHAN','Sir, the people of the city are waving from their windows. The hard work paid off.'],['EAGLE-1','Eagle-1 to Alpha, I am at the extraction point. Hurry, the sun is setting!']],
[['SGT. KHAN','The smoke from the convoy is visible from far away, sir. The enemy supply line is cut.'],['EAGLE-1','Alpha, we have to leave before the storm. The chopper is here, move move!']],
[['SGT. KHAN','Sir, all the towers are down. The whole area is in darkness.'],['EAGLE-1','Eagle-1 is in low-light mode. I saw your signal flare, I am landing!']],
[['SGT. KHAN','Sir, we did not stop even in the snow. The launch codes are now in our hands.'],['EAGLE-1','Alpha, visibility is zero but I can see your beacon. Get on!']],
[['SGT. KHAN','The smoke from the ship is rising to the sky, sir. There will be no more attacks.'],['EAGLE-1','Eagle-1 is above the deck. The ship is sinking, get on the chopper quickly!']],
[['SGT. KHAN','Sir, the jungle is quiet now. Not a trace of the guerrilla camp is left.'],['EAGLE-1','Alpha, I am dropping a rope through the canopy. Grab it and climb!']],
[['SGT. KHAN','The rig is burning, sir. I have never seen a fire like this.'],['EAGLE-1','The storm is very strong but the landing pad is clear. Alpha, get out now!']],
[['SGT. KHAN','The Commander is finished, sir. The enemy has been broken.'],['EAGLE-1','Alpha, Eagle-1 is here to take you home. The last flight, well done!']],
[['SGT. KHAN','Sir, our flag is flying on the other side of the border.'],['EAGLE-1','Alpha, the border patrol chopper has arrived to escort us. Welcome back!']],
[['SGT. KHAN','Sir, Eagle-7 did an amazing job. Not a trace of the trucks and tank is left.'],['EAGLE-1','Alpha, I can see the beacon. The chopper is landing, get on quickly!']],
[['SGT. KHAN','Sir, the whole base was finished in the dark. The enemy never knew who came.'],['EAGLE-1','Alpha, Eagle-1 is above you. Switch off your night vision and get on the chopper, we are going home!']],
[['SGT. KHAN','Sir, the terrorist base is rubble. The desert is quiet again.'],['EAGLE-1','Alpha, I can see the smoke from here. The chopper is landing, get on!']],
[['SGT. KHAN','Sir, every worker is alive. They are crying and hugging each other.'],['EAGLE-1','Alpha, Eagle-1 on the pad. Load the hostages first, then yourselves. Wheels up in ten!']],
[['SGT. KHAN','Sir, the village is quiet again. The families are coming out of the cellars.'],['CPT. RAWAT','Good work, Alpha. Houses can be rebuilt. People cannot. Eagle-1 is on its way.']]];
const ladders=[];let ladH=-99;
function ladderTower(x,z){const D=mt('dark'),N={nc:1,cs:false};for(const sx of[-1.4,1.4])for(const sz of[-1.4,1.4])box(x+sx,z+sz,.28,7,.28,D);
box(x,z,3.7,.25,3.7,mt('crate'),2,{y0:7});boxes[boxes.length-1].pl=1;
for(const r of[[x,z-1.8,3.7,.07],[x-1.8,z,.07,3.7],[x+1.8,z,.07,3.7]])for(const y of[7.7,8.2])box(r[0],r[1],r[2],.07,r[3],D,2,Object.assign({y0:y},N));
for(const sx of[-1.75,1.75])for(const sz of[-1.75,1.75])box(x+sx,z+sz,.08,2.8,.08,D,2,Object.assign({y0:7.25},N));
box(x,z,4.2,.18,4.2,D,2,Object.assign({y0:10.05},N));box(x,z-1.4,2.8,.1,.1,D,2,Object.assign({y0:3.5},N));box(x,z+1.4,2.8,.1,.1,D,2,Object.assign({y0:3.5},N));
box(x-.3,z+1.95,.06,7.3,.06,D,2,N);box(x+.3,z+1.95,.06,7.3,.06,D,2,N);for(let i=0;i<15;i++)box(x,z+1.95,.6,.04,.04,D,2,Object.assign({y0:.4+i*.48},N));
ladders.push({x,z:z+1.95,top:7.25})}
function addTowers(){ladders.length=0;if(cur.b==='ship'||cur.b==='rig'||cur.b==='mount')return;const got=[];for(let r=18;r<=42&&got.length<2;r+=12)for(let a=0;a<8&&got.length<2;a++){const g=a*PI/4+r*.3,x=cur.start[0]+Math.cos(g)*r,z=cur.start[1]+Math.sin(g)*r;if(Math.abs(x)>66||z>105||z<-64||hitBox(x,z+1,3.4)||cur.st.some(q=>Math.hypot(q.x-x,q.z-z)<12)||got.some(q=>Math.hypot(q[0]-x,q[1]-z)<24))continue;ladderTower(x,z);got.push([x,z])}}
async function startMission(){run=false;paused=false;clearTimeout(NET.rtm);NET.dn=0;NET.pdn=0;closeOv('pause');cur=MS[mi];const sCard='<small>MISSION '+(mi+1)+' / '+MS.length+'</small><b>'+cur.n+'</b><small>'+cur.loc+'</small>';flyEnd();cur.st.forEach(x=>{x.seen=0;x._b=0});lkHide();$('menu').style.display=$('over').style.display='none';$('over').style.display='none';$('title').style.display='none';
$('obj').textContent='LOADING...';await MO_ASSETS.load();await sleep(60);buildWorld(cur);addTowers();ST.sh=ST.h=ST.hs=ST.k=0;ksN=0;Object.assign(P,{x:cur.start[0],z:cur.start[1],hp:100,yaw:0,pitch:0,vy:0,y:1.7+(cur.sy||0),rec:0,recY:0});mkN=2;
enemies.forEach(e=>sc.remove(e));enemies.length=0;corpses.forEach(e=>sc.remove(e));corpses.length=0;mkAllies();if(NET.h&&NET.on){nAddRm();nSend({k:'mis',mi:mi,gs:NET.gs||0})}spawnFixed();clearPks();placeKits();startLoad();adsOn=false;ads=0;cp={x:P.x,z:P.z,yaw:0};
$('obj').textContent=cur.n;const T=$('title');T.innerHTML=cur.n+'<br><span style="font-size:.4em;letter-spacing:.3em">'+cur.loc+'</span>';
if(cur.crash){CRASH.done=0;if(!CRASH.g)CRASH.g=mkCrashPlane();wreckFire(0);const w=world.userData.wreck;if(w)w.visible=false;await cutscene(cur.crash,null,sCard);CRASH.g.visible=false;if(w)w.visible=true;wreckFire(1)}
await cutscene(cur.ent&&ENT[cur.ent]?ENT[cur.ent].concat(cur.intro):cur.intro,cur.st.map(x=>x.o).filter(Boolean),cur.crash?null:sCard);si=0;ST.t0=time;run=true;ctl(1);beginStage();if(!cur.uav)pop('MEDKITS LIE ON CRATES - WALK NEXT TO THEM')}
function beginStage(){let s=cur.st[si];if(NET.on&&s.t==='uav')s=uavCoop(s);else if(NET.on&&NET.h&&!s.cs&&(s.t==='kill'||s.t==='destroy'))s=Object.assign({},s,s.t==='kill'?{n:Math.ceil(s.n*1.4),cap:Math.max(s.cap||8,10)}:{guards:Math.ceil((s.guards||4)*1.4)});stg.s=s;stg.done=false;stg.killed=0;stg.sp=0;stg.spawned=0;stg.t=0;stg.hold=0;stg.wv=3;stg.hz=4;stg.tgl=[];stg.boss=null;cp={x:P.x,z:P.z,yaw:P.yaw};
if(si>0){resup();P.hp=100;reviveAllies();pop('AMMO RESUPPLIED');if(NET.on&&NET.h)nSend({k:'rsp'})}
{const ri=cur.st.findIndex(q=>q.t==='rescue');if(ri>=0&&si>ri&&!hosts.length)mkHosts(cur.st[ri],true)}
$('obj').textContent=s.o;if(!s.cs)radio(s.who||'SGT. KHAN',s.s);
if(s.cs&&!s.seen){s.seen=1;run=false;ctl(0);cutscene(s.cs).then(()=>{run=true;ctl(1);stInit(s)});return}stInit(s)}
function stInit(s){if(s.t==='uav')return uavStart(s);if(UA.on){uavEnd();ctl(1)}if(s.t==='fly')return flyStart();if(s.t==='lock')return lockInit(s);
if(s.t==='kill'){const k=s.idle?s.n:Math.min(s.n,5);for(let i=0;i<k;i++)spawnStage(s,i)}
if(s.t==='destroy'){s.tg.forEach(t=>stg.tgl.push(mkTg(t.k,t.x,t.z,t.rot||0)));for(let i=0;i<s.guards;i++)spawnE('rifle',s.at,s.idle)}
if(s.t==='hold')for(let i=0;i<3;i++)spawnE('rifle',s.at,false);
if(s.t==='rescue'){mkHosts(s,false);stg.wv=6;for(let i=0;i<s.guards;i++)spawnE('rifle',s.at,false)}}
function spawnStage(s,i){let kind='rifle';if(s.boss&&i===0)kind='boss';else if(s.heavy&&i<=s.heavy)kind='heavy';const e=spawnE(kind,kind==='boss'?[s.at[0],s.at[1],3]:s.at,s.idle);if(e){stg.spawned++;if(kind==='boss'){stg.boss=e;$('obj').textContent=s.o}}}
function objPos(){if(NET.g)return GWP;const s=stg.s;if(!s||stg.done)return null;if(s.t==='uav'){let b=null,bd=1e9;for(const o of stg.tgl)if(!o.dead){const d=Math.hypot(o.x-P.x,o.z-P.z);if(d<bd){bd=d;b=[o.x,o.z,o.y+1]}}if(b)return b;const w=s.route[Math.min(stg.ri,s.route.length-1)];return[w[0],w[1],1.5]}if(s.t==='reach'||s.t==='hold')return[s.x,s.z,1.5];if(s.t==='rescue'){let b=null,bd=1e9;for(const h of hosts)if(!h.free){const d=Math.hypot(h.x-P.x,h.z-P.z);if(d<bd){bd=d;b=[h.x,h.z,2.2]}}return b}if(s.t==='destroy'||s.t==='lock'){let b=null,bd=1e9;for(const o of stg.tgl)if(!o.dead){const d=Math.hypot(o.x-P.x,o.z-P.z);if(d<bd){bd=d;b=[o.x,o.z,o.y+1]}}return b}if(s.t==='kill'&&stg.boss&&!stg.boss.userData.dead)return[stg.boss.position.x,stg.boss.position.z,2.4];return null}
function adv(){stg.done=true;score+=200;if(NET.on&&NET.h){NET.gs=(NET.gs||0)+200;nSend({k:'gsc',s:NET.gs})}pop('OBJECTIVE COMPLETE +200');nSend({k:'pop',x:'OBJECTIVE COMPLETE'});const s=stg.s;if(s.after==='radar'&&world.userData.radar)dmgT(world.userData.radar,9999,true);si++;if(si>=cur.st.length)endMission();else setTimeout(()=>{if(run||NET.dn)beginStage()},1800)}
async function endMission(){sWin();run=false;lkHide();nvSet(0);uavEnd();nSend({k:'end'});missionXP();try{const nx=Math.min(mi+1,MS.length-1);localStorage.setItem('mo_p',Math.max(nx,+localStorage.getItem('mo_p')||0));saveGame(nx)}catch(e){}$('obj').textContent='MISSION COMPLETE';await cutscene(cur.out.concat(OUTX[mi]||[]),null,null,'<small>MISSION '+(mi+1)+' COMPLETE</small><b>'+cur.n+'</b><small>SCORE '+score+(mi<MS.length-1?' · NEXT: '+MS[mi+1].n:' · CAMPAIGN COMPLETE')+'</small>'+stSum());if(mi<MS.length-1){mi++;keepLoad=1;try{localStorage.setItem('mo_p',Math.max(mi,+localStorage.getItem('mo_p')||0))}catch(e){}startMission()}else{ctl(0);$('ot').textContent='CAMPAIGN COMPLETE';$('fs').textContent='Final score '+score;$('again').textContent='PLAY AGAIN';mi=0;$('over').style.display='flex'}}
function stSum(){const acc=ST.sh?Math.min(100,Math.round(ST.h/ST.sh*100)):0,hr=ST.k?ST.hs/ST.k*100:0,t=Math.max(0,time-ST.t0),q=acc*.6+hr*.4,rk=q>=48?'S':q>=36?'A':q>=24?'B':'C';
return'<small style="margin-top:10px;letter-spacing:.15em">KILLS '+ST.k+' \u00b7 HEADSHOTS '+ST.hs+' \u00b7 ACCURACY '+acc+'% \u00b7 TIME '+Math.floor(t/60)+':'+('0'+Math.floor(t%60)).slice(-2)+'</small><b style="font-size:min(14vw,72px)">RANK '+rk+'</b>'}
function die(){if(!PV.on&&!NET.on)sOver();hapDeath();ksN=0;lkHide();if(PV.on)return pvDie();if(NET.g)return gDie();if(NET.on&&NET.h&&!FL.on)return hDie();const wasU=UA.on;uavEnd();run=false;LZ.forEach(l=>l.visible=false);ctl(0);firing=false;resetGun();$('ot').textContent=wasU?'SQUAD LOST - UAV LINK CUT':'KILLED IN ACTION';$('fs').textContent=cur.n+' · Score '+score;$('again').textContent='RETRY CHECKPOINT';$('over').style.display='flex'}
const hosts=[];
function clearHosts(){hosts.forEach(h=>sc.remove(h.g));hosts.length=0}
function mkHost(x,z,free,tx,tz,i){const g=new THREE.Group(),O=S(0xff6a12,.85,0),Sk=S(0xc99a74,.9,0),Y=S(0xf2c21a,.6,0),R2=S(0x8a6a3a,.9,0);
const P2=(geo,m,px,py,pz,par)=>{const q=new THREE.Mesh(geo,m);q.position.set(px,py,pz);q.castShadow=true;(par||g).add(q);return q};
const legs=P2(Bx(.3,1,.22),O,0,.5,0);const up=new THREE.Group();g.add(up);
P2(Bx(.46,.52,.27),O,0,.26,0,up);P2(Bx(.2,.22,.2),Sk,0,.66,0,up);P2(Bx(.27,.1,.29),Y,0,.8,0,up);P2(Bx(.3,.03,.34),Y,0,.76,0,up);
P2(Bx(.4,.08,.08),R2,0,.2,.14,up);P2(Bx(.12,.34,.1),O,-.28,.28,0,up);P2(Bx(.12,.34,.1),O,.28,.28,0,up);
const mk=new THREE.Mesh(new THREE.SphereGeometry(.13,10,8),new THREE.MeshBasicMaterial({color:0xffa030,transparent:true,opacity:.9,fog:false}));mk.position.y=2.15;g.add(mk);
g.position.set(x,0,z);g.rotation.y=Math.atan2(P.x-x,P.z-z);sc.add(g);
const h={g:g,legs:legs,up:up,mk:mk,x:x,z:z,tx:tx,tz:tz,p:0,free:free?1:0,u:free?1:0,i:i||0,said:0};setHostPose(h);hosts.push(h);return h}
function setHostPose(h){const k=.42+.5*h.u;h.legs.scale.y=k;h.legs.position.y=.5*k;h.up.position.y=k;h.mk.visible=!h.free}
function mkHosts(s,free){clearHosts();const e=s.ex||[20,22];s.hs.forEach((q,i)=>{const tx=e[0]-3+i*2.2,tz=e[1]+2;if(free)mkHost(tx,tz,1,tx,tz,i);else mkHost(q[0],q[1],0,tx,tz,i)})}
function updHosts(dt){for(const h of hosts){h.mk.position.y=2.15+Math.sin(time*3+h.i)*.08;h.mk.scale.setScalar(1+Math.sin(time*5+h.i)*.2);
if(h.free){if(h.u<1){h.u=Math.min(1,h.u+dt*1.6);setHostPose(h)}else{const dx=h.tx-h.x,dz=h.tz-h.z,d=Math.hypot(dx,dz);if(d>.4){const v=Math.min(d,3.4*dt);h.x+=dx/d*v;h.z+=dz/d*v;h.g.position.set(h.x,Math.abs(Math.sin(time*9+h.i))*.06,h.z);h.g.rotation.y=Math.atan2(dx,dz)}}}}}
function rescueTick(s,dt,alive){const n=hosts.length;let fr=0,near=null;for(const h of hosts){if(h.free){fr++;continue}if(Math.hypot(P.x-h.x,P.z-h.z)<2.6){h.p+=dt;near=h;if(h.p>=1.8){h.free=1;fr++;near=null;score+=100;pop('HOSTAGE FREED +100');if(!h.said){h.said=1;radio('WORKER',['Thank god! Thank you, soldier!','Please, get us out of here!','They said they would kill us!'][h.i%3])}}}else h.p=Math.max(0,h.p-dt*.6)}
const txt=s.o+' ('+fr+'/'+n+')'+(near?' - CUTTING ROPE '+Math.min(100,Math.round(near.p/1.8*100))+'%':' - STAY CLOSE TO A HOSTAGE');if($('obj').textContent!==txt)$('obj').textContent=txt;
stg.wv-=dt;if(stg.wv<=0&&alive<(LITE?4:6)){stg.wv=9;for(let i=0;i<2;i++)spawnE('rifle',s.at,false)}
if(fr>=n)adv()}
function stageTick(dt){const s=stg.s;if(!s||stg.done)return;stg.t+=dt;let alive=0;for(let i=0;i<enemies.length;i++)if(!enemies[i].userData.fix)alive++;
if(s.t==='reach'){if(Math.hypot(P.x-s.x,P.z-s.z)<(s.r||3.5))return adv();if(s.hz){stg.hz-=dt;if(stg.hz<=0&&alive<5){stg.hz=s.hz;const dx=s.x-P.x,dz=s.z-P.z,d=Math.hypot(dx,dz)||1;spawnE(R()<.15?'heavy':'rifle',[P.x+dx/d*34+(R()-.5)*20,P.z+dz/d*34+(R()-.5)*20,10],false)}}}
else if(s.t==='kill'){stg.sp-=dt;if(!s.idle&&stg.sp<=0&&stg.spawned<s.n&&alive<(LITE?Math.min(5,s.cap||8):(s.cap||8))){stg.sp=.8;spawnStage(s,stg.spawned)}const txt=s.o+' ('+Math.min(stg.killed,s.n)+'/'+s.n+')';if($('obj').textContent!==txt)$('obj').textContent=txt;if(stg.killed>=s.n&&stg.spawned>=s.n)adv()}
else if(s.t==='destroy'){const left=stg.tgl.filter(o=>!o.dead).length,txt=s.o+' ('+(stg.tgl.length-left)+'/'+stg.tgl.length+')';if($('obj').textContent!==txt)$('obj').textContent=txt;if(!left)adv()}
else if(s.t==='hold'){const inz=Math.hypot(P.x-s.x,P.z-s.z)<(s.r||8);if(inz)stg.hold+=dt;const txt=inz?s.o+' ('+Math.max(0,Math.ceil(s.time-stg.hold))+'s)':'RETURN TO THE ZONE';if($('obj').textContent!==txt)$('obj').textContent=txt;stg.wv-=dt;if(stg.wv<=0&&alive<(LITE?5:8)){stg.wv=7;for(let i=0;i<2;i++)spawnE(R()<.2?'heavy':'rifle',s.at,false)}if(stg.hold>=s.time)adv()}
else if(s.t==='rescue')rescueTick(s,dt,alive);
else if(s.t==='lock')lockStage(s,dt);
else if(s.t==='uav')uavStage(s,dt,alive)}
function retry(){clearHosts();hitFlash=0;dindT=0;flyEnd();enemies.forEach(e=>sc.remove(e));enemies.length=0;corpses.forEach(e=>sc.remove(e));corpses.length=0;
stg.tgl&&stg.tgl.forEach(o=>{if(!o.dead){GRD.n=-1;world.remove(o.g);let i=boxes.indexOf(o.box);if(i>=0)boxes.splice(i,1);i=tgObjs.indexOf(o.g);if(i>=0)tgObjs.splice(i,1);i=tgs.indexOf(o);if(i>=0)tgs.splice(i,1)}});
lockReset();Object.assign(P,{x:cp.x,z:cp.z,yaw:cp.yaw,hp:100,vy:0,y:1.7+((cur&&cur.sy)||0),pitch:0});clearPks();refillAll();reviveAllies();spawnFixed();$('over').style.display='none';run=true;ctl(1);beginStage()}
const mv={x:0,y:0};const k={};
addEventListener('keydown',e=>{k[e.code]=1;if(cmOpen&&cmKey(e))return;if(e.code==='KeyR'&&!paused)doReload();if(e.code==='Space'&&run&&!paused&&!cin)jump();if(run&&!paused&&!cin){const dg=/^Digit([1-4])$/.exec(e.code);if(dg)switchTo(+dg[1]-1);else if(e.code==='KeyQ')switchTo(ps);else if(e.code==='KeyF')doPickup();else if(e.code==='KeyZ')stepZoom(0);else if(e.code==='KeyG'&&!e.repeat)gAimOn();else if(e.code==='KeyB')toggleMode();else if(e.code==='KeyV')mkPing();else if(e.code==='KeyC')cmToggle()}if((e.code==='Escape'||e.code==='KeyP')&&run&&!cin)paused?resumeG():pauseG()});addEventListener('keyup',e=>{k[e.code]=0;if(e.code==='KeyG')gAimOff()});
addEventListener('contextmenu',e=>e.preventDefault());addEventListener('wheel',e=>{if(run&&!paused&&!cin){if(wd&&wd.scope&&ads>.5)stepZoom(e.deltaY>0?-1:1);else switchTo((cs+(e.deltaY>0?1:2))%3)}},{passive:true});
addEventListener('mousedown',e=>{if(!run||paused)return;if(e.button===0){firing=true;rd.domElement.requestPointerLock&&rd.domElement.requestPointerLock()}else if(e.button===2)adsOn=CFG.adsHold?true:!adsOn});addEventListener('mouseup',e=>{firing=false;if(e.button===2&&CFG.adsHold)adsOn=false});
addEventListener('mousemove',e=>{if(document.pointerLockElement){const f=zf();addLook(-e.movementX*.0022*CFG.sens*f,-e.movementY*.0022*CFG.sens*f);lookDX+=e.movementX;lookDY+=e.movementY}});
function btn(id,dn,up){const b=$(id);b.addEventListener('touchstart',e=>{e.preventDefault();e.stopPropagation();dn()},{passive:false});b.addEventListener('touchend',e=>{e.preventDefault();up&&up()},{passive:false})}
btn('pk',doPickup,null);$('pk').addEventListener('click',doPickup);btn('grb',gAimOn,gAimOff);$('grb').addEventListener('touchcancel',()=>{gAim=0;gHide()});$('grb').addEventListener('mousedown',e=>{e.stopPropagation();gAimOn()});addEventListener('mouseup',()=>gAimOff());btn('fmb',toggleMode,null);$('fmb').addEventListener('click',toggleMode);btn('zmb',()=>stepZoom(0),null);$('zmb').addEventListener('click',()=>stepZoom(0));btn('brb',()=>{scHold=true},()=>{scHold=false});$('brb').addEventListener('touchcancel',()=>{scHold=false});btn('pgb',()=>mkPing(),null);$('pgb').addEventListener('click',()=>mkPing());
const mant={on:0,t:0,d:1,x0:0,y0:0,z0:0,x1:0,y1:0,z1:0,v:0,dip:0};
function boxAt(x,z,r){if(GRD.n!==boxes.length)gridBuild();const N=GRD.N,c=GRD.c,a0=gIx(x-r),a1=gIx(x+r),d0=gIx(z-r),d1=gIx(z+r);let b=null;for(let d=d0;d<=d1;d++)for(let a=a0;a<=a1;a++){const L=c[d*N+a];if(!L)continue;for(let j=0;j<L.length;j++){const q=L[j];if(x>q.x0-r&&x<q.x1+r&&z>q.z0-r&&z<q.z1+r&&(!b||q.h>b.h))b=q}}return b}
function tryMantle(){if(mant.on||!run||paused||cin)return false;const fx=-Math.sin(P.yaw),fz=-Math.cos(P.yaw),foot=P.y-1.7;let b=null,px=0,pz=0;
for(const dd of[.55,.85]){const x=P.x+fx*dd,z=P.z+fz*dd,q=boxAt(x,z,.05);if(q&&q.h>foot+.45&&q.h<=foot+2.3){b=q;px=x;pz=z;break}}if(!b)return false;
const rise=b.h-foot;let vault=false,x1=px+fx*.35,z1=pz+fz*.35,y1=b.h+1.7;
if(!(x1>b.x0&&x1<b.x1&&z1>b.z0&&z1<b.z1)){x1=px;z1=pz}
if(rise<=1.3){for(let d=.3;d<=2.6;d+=.2){const x=px+fx*d,z=pz+fz*d;if(!hitBox(x,z,.4,foot)){vault=true;x1=x;z1=z;y1=groundAt(x,z,foot+.5)+1.7;break}}}
if(!vault&&hitBox(x1,z1,.3,b.h))return false;
Object.assign(mant,{on:1,t:0,d:vault?.5:.45+rise*.12,x0:P.x,y0:P.y,z0:P.z,x1,y1,z1,v:vault});adsOn=false;cancelReload();nz(.18,900,200,.3);pop(vault?'VAULT':'CLIMB');return true}
function updMantle(dt){mant.t+=dt;const k=Math.min(1,mant.t/mant.d);let x,y,z;
if(mant.v){const e=k*k*(3-2*k);x=lerp(mant.x0,mant.x1,e);z=lerp(mant.z0,mant.z1,e);y=lerp(mant.y0,mant.y1,e)+Math.sin(k*PI)*.45}
else{const ky=ss(0,.65,k),kh=ss(.35,1,k);y=lerp(mant.y0,mant.y1+.12*Math.sin(k*PI),ky);x=lerp(mant.x0,mant.x1,kh);z=lerp(mant.z0,mant.z1,kh)}
P.x=x;P.y=y;P.z=z;P.vy=0;P.ground=false;mant.dip=Math.sin(k*PI)*(mant.v?.18:.12);gh.draw=Math.max(gh.draw,Math.sin(k*PI)*.6);
if(k>=1){mant.on=0;mant.dip=0;P.y=mant.y1;P.ground=true;nz(.08,600,150,.3);tn(70,40,.1,.3)}}
function jump(){if(mant.on||(PV.on&&PV.frz))return;CR.on=0;if(tryMantle())return;if(P.ground){P.vy=7;P.ground=false}}
let fsDone=0;function firstFull(){if(fsDone)return;fsDone=1;full()}addEventListener('touchstart',firstFull,{passive:true});addEventListener('mousedown',firstFull);
function full(){const e=document.documentElement;try{(e.requestFullscreen||e.webkitRequestFullscreen).call(e)}catch(x){}try{screen.orientation.lock('landscape').catch(()=>{})}catch(x){}}
$('again').onclick=()=>{AC();full();if(PV.on){if(NET.h)pvBegin(PV.mode);return}if($('again').textContent==='RETRY CHECKPOINT')retry();else{mi=0;score=0;NET.gs=0;startMission()}};
function prog(){let p=0;try{p=+localStorage.getItem('mo_p')||0}catch(e){}return clamp(p,0,MS.length-1)}
function buildMis(){const el=$('mlist');el.innerHTML='';const pr=prog();MS.forEach((m,i)=>{const b=document.createElement('button');b.className='mc';b.disabled=i>pr&&!m.open;
b.innerHTML=(i+1)+' · '+m.n+'<br><small>'+(i>pr&&!m.open?'LOCKED':(m.loc||''))+'</small>';b.onclick=()=>{AC();full();closeOv('mis');openLobby(i)};el.appendChild(b)})}
function refreshMenu(){restoreSave();const pr=prog();$('play').disabled=false;$('mis_b').disabled=false;$('cont').disabled=pr<=0;$('cont').style.display=pr>0?'':'none';$('cont').textContent=pr>0?'Continue · Mission '+(pr+1):'Continue';buildMis()}
$('play').onclick=()=>{AC();full();openLobby(0)};
$('cont').onclick=()=>{AC();full();openLobby(prog())};
$('mis_b').onclick=()=>{buildMis();openOv('mis')};
$('creb').onclick=()=>openOv('cred');$('cback').onclick=()=>closeOv('cred');
$('quitb').onclick=()=>{try{window.close()}catch(e){}try{history.length>1&&history.back()}catch(e){}$('mt').textContent='CLOSE THIS TAB / APP TO QUIT'};
{let ms=-1;const its=()=>['cont','play','mis_b','coopb','setb','quitb'].map($).filter(b=>!b.disabled),open_=()=>getComputedStyle($('menu')).display!=='none'&&['set','mis','how','coop','cred','lobby'].every(i=>getComputedStyle($(i)).display==='none');
addEventListener('keydown',e=>{if(!open_())return;const l=its();if(e.code==='ArrowDown'||e.code==='ArrowUp'){e.preventDefault();ms=(ms+(e.code==='ArrowDown'?1:-1)+l.length)%l.length;l.forEach((b,i)=>b.classList.toggle('sel',i===ms))}else if(e.code==='Enter'&&ms>=0&&l[ms]){e.preventDefault();l[ms].click()}});
document.querySelectorAll('#mbox button').forEach(b=>b.addEventListener('mouseenter',()=>{ms=-1;document.querySelectorAll('#mbox button.sel').forEach(x=>x.classList.remove('sel'))}))}$('mback').onclick=()=>closeOv('mis');
{const tg={mis:()=>$('mlist'),set:()=>$('sbody'),coop:()=>$('coop').querySelector('.scr'),lobby:()=>$('lbody')},
by=(id,d,f)=>{const s=tg[id]();if(s)s.scrollBy({top:d*Math.max(50,s.clientHeight*(f||.6)),behavior:'smooth'})},
mkb=(id,tx,d,cls)=>{const b=document.createElement('button');b.className=cls;b.textContent=tx;b.setAttribute('aria-label',d<0?'Scroll up':'Scroll down');b.onclick=()=>by(id,d);return b};
['mis','set','coop'].forEach(id=>{const pf=$(id).querySelector('.pf'),w=document.createElement('div');w.className='ud';w.append(mkb(id,'\u25B2',-1,'sm'),mkb(id,'\u25BC',1,'sm'));pf.insertBefore(w,pf.firstChild)});
const lb=document.querySelector('#lobby .lbt');if(lb){lb.insertBefore(mkb('lobby','\u25BC',1,'lud'),lb.firstChild);lb.insertBefore(mkb('lobby','\u25B2',-1,'lud'),lb.firstChild)}
addEventListener('keydown',e=>{const d={ArrowDown:1,ArrowUp:-1,PageDown:2,PageUp:-2}[e.code];if(!d||/^(INPUT|TEXTAREA|SELECT)$/.test((e.target||{}).tagName))return;
const id=['set','mis','coop','lobby'].find(i=>getComputedStyle($(i)).display!=='none');if(!id)return;e.preventDefault();by(id,d>0?1:-1,Math.abs(d)>1?.9:.25)})}
function pauseG(){if(!run||paused||cin)return;paused=true;firing=false;mv.x=mv.y=0;ctl(0);try{document.exitPointerLock()}catch(e){}try{ac&&ac.suspend()}catch(e){}$('pm').textContent=cur?cur.n:'';$('prs').style.display=PV.on?'none':'';openOv('pause')}
function resumeG(){if(!paused)return;paused=false;closeOv('pause');closeOv('set');ctl(1);if(FL.on)flyUI();if(UA.on)uavUI();try{ac&&ac.resume()}catch(e){}}
function toMenu(){pvClear();rd.domElement.style.filter='';lhB=-1;if(NET.on)nBye();if(NET.hm){sc.remove(NET.hm);NET.hm=null}NET.en.forEach(e=>sc.remove(e));NET.en.clear();NET.tg=[];NET.sg='';NET.rm=null;flyEnd();run=false;paused=false;firing=false;adsOn=false;mv.x=mv.y=0;ctl(0);try{speechSynthesis.cancel()}catch(e){}try{document.exitPointerLock()}catch(e){}try{ac&&ac.resume()}catch(e){}
inLobby=false;$('ccard').style.opacity=0;['over','pause','set','mis','how','lobby','coop'].forEach(closeOv);$('obj').textContent='';$('sub').textContent='';$('title').style.display='none';
enemies.forEach(e=>sc.remove(e));enemies.length=0;corpses.forEach(e=>sc.remove(e));corpses.length=0;allies.forEach(a=>sc.remove(a));allies.length=0;clearPks();resetGun();menuWorld();applyS();openOv('menu');refreshMenu()}
$('sndb').onclick=$('psnd').onclick=sndToggle;sndUI();$('pauseB').onclick=pauseG;$('pres').onclick=resumeG;$('pmn').onclick=toMenu;$('omenu').onclick=toMenu;
$('prs').onclick=()=>{paused=false;closeOv('pause');try{ac&&ac.resume()}catch(e){}retry()};
document.addEventListener('pointerlockchange',()=>{if(!document.pointerLockElement&&run&&!paused&&!cin)pauseG()});
document.addEventListener('visibilitychange',()=>{if(document.hidden)pauseG()});
const lkB={x:0,y:0},AS={on:0,t:null,ang:9,cone:0,ex:0,ey:0,ez:0,xs:1};
function addLook(x,y){const q=ads>.3?aimFr:1+(aimFr-1)*.6;lkB.x+=x*q;lkB.y+=y*q}
function aimScan(){AS.t=null;AS.on=0;AS.ang=9;if(!run||cin)return;
const pt=P.pitch+P.rec,yw=P.yaw+P.recY,cpt=Math.cos(pt),fx=-Math.sin(yw)*cpt,fy=Math.sin(pt),fz=-Math.cos(yw)*cpt,lv=CFG.assist,c0=Math.max(lv*1.7+.6,(TOUCHD&&lv>0&&ads>.3)?5:0)*PI/180;
for(const e of enemies){const u=e.userData;if(u.dead)continue;const s=e.scale.x,ex=e.position.x-P.x,ey=1.3*s-P.y,ez=e.position.z-P.z,d=Math.hypot(ex,ey,ez);if(d<1.5||d>80)continue;
const dot=(ex*fx+ey*fy+ez*fz)/d;if(dot<.9)continue;const ang=Math.acos(Math.min(1,dot)),hr=Math.atan(.45*s/d)+.012,cone=Math.max(hr,lv?c0+Math.atan(.5*s/d):0);
if(ang>cone||ang>=AS.ang)continue;if(!los(P.x,P.y,P.z,e.position.x,1.3*s,e.position.z))continue;
AS.t=e;AS.ang=ang;AS.cone=cone;AS.ex=ex;AS.ey=ey;AS.ez=ez;AS.on=ang<hr?1:0}}
function applyLook(dt){aimScan();const sm=CFG.smooth,a=sm>0?1-Math.exp(-dt/(.006+sm*.07)):1;let ux=lkB.x*a,uy=lkB.y*a;lkB.x-=ux;lkB.y-=uy;
const lv=CFG.assist;let gy=0,gp=0;
if(lv>0&&AS.t){const k=1-AS.ang/AS.cone,inp=dt>0?Math.hypot(ux,uy)/dt:0,fl=1-.75*ss(1.5,4.5,inp),fr=1-(1-Math.max(.45,1-.13*lv*k*(1+ads)))*fl;ux*=fr;uy*=fr;
if(!sprint&&!mant.on&&(ads>.3||firing)){const g=Math.min(1,dt*.9*lv*k*(ads>.3?1.6:.7)*fl),wy=Math.atan2(-AS.ex,-AS.ez),wp=Math.atan2(AS.ey,Math.hypot(AS.ex,AS.ez));gy=angDiff(wy,P.yaw+P.recY)*g;gp=(wp-(P.pitch+P.rec))*g}}
if(uy<0&&rcAcc>0)rcAcc=Math.max(0,rcAcc+uy);if(rcAccY*ux<0){const c=Math.min(Math.abs(rcAccY),Math.abs(ux));rcAccY-=Math.sign(rcAccY)*c}
P.yaw+=ux+gy;P.pitch=clamp(P.pitch+uy+gp,-1.4,1.4)}
function updXh(dt){const dq=Math.min(dt,.05);bloom=Math.max(0,bloom-dq*(wd&&wd.auto?1.3:2.2));
if(TOUCHD&&run&&!cin&&++afT%3===0){let f=1;if(ads>.05||firing){cam.updateMatrixWorld();for(const en of enemies){const u=en.userData;if(!u||u.dead||u.dying)continue;const dx=en.position.x-P.x,dz=en.position.z-P.z;if(dx*dx+dz*dz>4900)continue;v3.set(en.position.x,en.position.y+1.2,en.position.z).project(cam);if(v3.z<1&&Math.abs(v3.x)<.1&&Math.abs(v3.y)<.14){f=.6;break}}}aimFr=f}else if(!run)aimFr=1;
if(run&&WS&&wd&&wd.type==='mag'&&WS.ammo===0&&WS.ch===0&&!firing&&!sprint&&!swp.on&&canReload()){arT+=dq;if(arT>.4){arT=0;doReload()}}else arT=0;
const e=$('xh'),t=.75+(moving?.25:0)+(sprint?.3:0)+(P.ground?0:.25)+Math.min(.5,kick*.45)+bloom*.35;AS.xs+=(t-AS.xs)*Math.min(1,dt*16);e.style.transform='scale('+AS.xs.toFixed(2)+')';e.style.opacity=1-ads;e.classList.toggle('on',!!AS.on)}
function updRecoil(dt){rcT+=dt;const lv=CFG.rcv;if(!lv){rcAcc=rcAccY=0;return}
if(rcT>.1&&(rcAcc||rcAccY)){const f=[0,.55,.85,1][lv],k=1-Math.exp(-dt*6),a=rcAcc*k,b=rcAccY*k;P.pitch=clamp(P.pitch-a*f,-1.4,1.4);P.yaw-=b*f;rcAcc-=a;rcAccY-=b;if(Math.abs(rcAcc)<1e-4)rcAcc=0;if(Math.abs(rcAccY)<1e-4)rcAccY=0}}
function slash(){slashFx();gunKick();nz(.06,3500,900,.35);let h=0;const fx=-Math.sin(P.yaw),fz=-Math.cos(P.yaw);for(const e of enemies.slice()){const dx=e.position.x-P.x,dz=e.position.z-P.z,d=Math.hypot(dx,dz);if(d<2.3&&(dx*fx+dz*fz)/(d||1)>.55){hitDir.x=fx;hitDir.z=fz;hitDir.p=70;hitDir.ex=0;const k=e.userData.kind;dmgE(e,k==='boss'?35:k==='heavy'?60:110,1,false);h=1}}if(PV.on)pvSlash();if(h){hitMk(0);nz(.05,1800,600,.4)}alertAll(P.x,P.z,6)}
const LKD={R:450,T:2.4,el:null},JETS=[],AAP=[[120,-150],[-200,-120],[30,-290],[62,-282]];
function rockCone(rt,rb,h,seg,hs,j){const g=new THREE.CylinderGeometry(rt,rb,h,seg,hs),p=g.attributes.position;for(let i=0;i<p.count;i++){const x=p.getX(i),y=p.getY(i),z=p.getZ(i);if(y>=h/2-.01)continue;const r=Math.hypot(x,z)||1,d=(Math.sin(x*.31+y*.23)*Math.cos(z*.27-y*.19)+Math.sin((x+z)*.13)*.7)*j;p.setX(i,x+x/r*d);p.setZ(i,z+z/r*d);p.setY(i,y+Math.sin(x*.19+z*.23)*j*.18)}g.computeVertexNormals();return g}
function mount(){JETS.length=0;setGround('dirt',97);{const gp=world.children[world.children.length-1];gp.scale.set(1.8,1.8,1)}
const mm=new THREE.MeshStandardMaterial({color:0x7d776a,roughness:1,flatShading:true}),m2=new THREE.MeshStandardMaterial({color:0x6a665b,roughness:1,flatShading:true});
const main=new THREE.Mesh(rockCone(46,175,69.8,28,9,16),mm);main.position.set(0,34.9,0);main.receiveShadow=true;world.add(main);
[[-300,150,100,95],[310,120,110,105],[-340,-30,125,125],[330,-110,100,80],[10,350,130,110],[-120,330,90,70],[200,300,95,85],[-60,-340,70,60]].forEach(q=>{const m=new THREE.Mesh(rockCone(q[2]*.28,q[2],q[3],20,5,10),m2);m.position.set(q[0],q[3]/2,q[1]);m.receiveShadow=true;world.add(m)});
box(0,0,62,70,62,mt('rock'),6,{ns:true,see:true});
for(const e of[[0,-30.6,62,1.2],[0,30.6,62,1.2],[-30.6,0,1.2,62],[30.6,0,1.2,62]])box(e[0],e[1],e[2],1.3,e[3],mt('rock'),3,{y0:70,ns:true,see:true});
const bg=mt('bag'),O={y0:70,ns:true,see:true};box(0,-17,9,1.1,1.1,bg,1,O);box(-5,-15.5,1.1,1.1,4,bg,1,O);box(5,-15.5,1.1,1.1,4,bg,1,O);box(-7,3,2.2,1.2,1.4,mt('crate'),2,{y0:70,ns:true});box(8,6,1.4,1.2,1.4,mt('crate'),2,{y0:70,ns:true});
mesh(new THREE.CylinderGeometry(.08,.12,9,6),mt('dark'),14,74.5,10,{cs:false});const lp=mesh(new THREE.SphereGeometry(.3,8,8),mt('lamp'),14,79.2,10,{cs:false});anim.push(t=>{lp.visible=Math.sin(t*3)>0});
for(let i=0,n=LITE?26:50;i<n;i++){const a=R()*6.28,r=110+R()*220,x=Math.cos(a)*r,z=Math.sin(a)*r;if(AAP.some(q=>Math.hypot(x-q[0],z-q[1])<30))continue;rock(x,z,2+R()*3.5)}
anim.push((t,dt)=>{jetTick(dt);if(!(stg.s&&stg.s.t==='lock'&&!stg.done))lkHide()})}
function aaSite(x,z){const b=mt('bag');box(x,z-8,14,1.1,1,b,1);box(x,z+8,14,1.1,1,b,1);box(x-8,z,1,1.1,14,b,1);box(x+8,z,1,1.1,14,b,1);box(x+5.4,z+5.4,1.5,1.2,1.5,mt('crate'),2);box(x-5.2,z+5.6,1.5,1.2,1.5,mt('crate'),2);mkTg('truck',x+15,z+4,1.5708,true)}
function lkUI(){if(LKD.el)return LKD.el;const d=document.createElement('div');d.style.cssText='position:fixed;left:0;top:0;width:100%;height:100%;pointer-events:none;z-index:9;display:none;font-family:Impact,Arial Narrow,Arial,sans-serif;letter-spacing:.1em;color:#ffcf40;text-shadow:0 0 5px #000';
d.innerHTML='<div id="lkp" style="position:absolute;right:12px;top:64px;text-align:right;font-size:13px;background:rgba(0,0,0,.45);padding:6px 10px;border:1px solid rgba(255,207,64,.5)"></div><div id="lkb" style="position:absolute;width:64px;height:64px;margin:-32px 0 0 -32px;border:2px solid #ffcf40;display:none"><div id="lkt" style="position:absolute;left:70px;top:-4px;white-space:nowrap;font-size:13px"></div><div id="lkf" style="position:absolute;left:0;bottom:-9px;height:4px;width:0;background:#ff3b2f"></div></div>';
($('obj').parentNode||document.body).appendChild(d);return LKD.el=d}
function lkHide(){if(LKD.el)LKD.el.style.display='none'}
function lockReset(){lkHide();for(const j of JETS){world.remove(j.g);if(j.m)world.remove(j.m)}JETS.length=0}
function lockInit(s){stg.fail=0;if(!s._b){s._b=1;s.tg.forEach(t=>aaSite(t.x,t.z))}
s.tg.forEach(t=>stg.tgl.push(mkTg('aa',t.x,t.z,t.rot||0)));
const c=s.tg[0];for(let i=0,k=0;i<s.guards&&k<60;k++){const a=R()*6.28,r=2+R()*4,x=c.x+Math.cos(a)*r,z=c.z+Math.sin(a)*r;if(hitBox(x,z,.8))continue;enemies.push(mkGuard(x,z));i++}
if(si===0)pop('AA LOCK DEVICE READY - SCOPE IN ON THE BATTERY')}
function lockStage(s,dt){const el=lkUI();el.style.display='block';const pn=$('lkp'),bx=$('lkb'),tt=$('lkt'),fl=$('lkf');cam.getWorldDirection(v3);
let best=null,bs=9,left=0;for(const o of stg.tgl){if(o.dead)continue;left++;if(o.jet)continue;const dx=o.x-P.x,dy=o.y+1-P.y,dz=o.z-P.z,d=Math.hypot(dx,dy,dz),ang=Math.acos(clamp((dx*v3.x+dy*v3.y+dz*v3.z)/d,-1,1));o.d=d;o.ang=ang;if(ang<bs){bs=ang;best=o}else o.lk=Math.max(0,(o.lk||0)-dt*1.5)}
const lim=s.lim||420,rem=Math.max(0,lim-stg.t);pn.textContent='AA LOCK DEVICE \u00b7 RANGE '+LKD.R+' m \u00b7 TARGETS '+left+' \u00b7 JET FUEL '+Math.floor(rem/60)+':'+('0'+Math.floor(rem%60)).slice(-2);pn.style.color=rem<60?'#ff5a4a':'#ffcf40';
const txt=s.o+' ('+(stg.tgl.length-left)+'/'+stg.tgl.length+')';if($('obj').textContent!==txt)$('obj').textContent=txt;
if(best&&bs<.5){const o=best,v=LKD.v||(LKD.v=new THREE.Vector3());v.set(o.x,o.y+1,o.z).project(cam);const inR=o.d<=LKD.R,on=inR&&bs<.04;
if(on)o.lk=Math.min(1,(o.lk||0)+dt/LKD.T);else o.lk=Math.max(0,(o.lk||0)-dt*1.5);
if(v.z<1&&Math.abs(v.x)<1.1&&Math.abs(v.y)<1.1){bx.style.display='block';bx.style.left=(v.x*50+50)+'%';bx.style.top=(50-v.y*50)+'%';const lk=o.lk>=1;bx.style.borderColor=lk?'#4dff7a':on?'#ff5a4a':'#ffcf40';
tt.textContent=lk?'LOCKED \u00b7 JET INBOUND':!inR?'OUT OF RANGE \u00b7 '+Math.round(o.d)+' m':'AA BATTERY \u00b7 '+Math.round(o.d)+' m \u00b7 '+(on?'LOCKING '+Math.round(o.lk*100)+'%':'ALIGN SIGHTS');fl.style.width=(o.lk*100)+'%'}else bx.style.display='none';
if(o.lk>=1&&!o.jet)jetStrike(o)}else bx.style.display='none';
if(!left){lkHide();return adv()}
if(stg.t>lim&&!stg.fail){stg.fail=1;lkHide();die();$('ot').textContent='JET FUEL OUT - MISSION FAILED'}}
function jetStrike(o){const g=new THREE.Group();jetM(g,'stl');g.traverse(c=>{if(c.isMesh)c.castShadow=false});g.scale.setScalar(1.5);world.add(g);
const dx=o.x-P.x,dz=o.z-P.z,L=Math.hypot(dx,dz)||1,ux=dx/L,uz=dz/L;g.position.set(P.x-ux*140,P.y+36,P.z-uz*140);g.rotation.y=Math.atan2(-uz,ux);
JETS.push({g:g,o:o,ux:ux,uz:uz,t:0,fired:0,m:null});o.jet=1;radio('WILDCAT-1','Lock confirmed. Wildcat-1 is going in hot, stand by.');setTimeout(()=>{nz(2.2,240,1600,.3,'bandpass',0);tn(80,180,2,.1,'sawtooth',0)},650)}
function jetTick(dt){for(let i=JETS.length-1;i>=0;i--){const j=JETS[i],g=j.g;j.t+=dt;g.position.x+=j.ux*165*dt;g.position.z+=j.uz*165*dt;
const rem=(j.o.x-g.position.x)*j.ux+(j.o.z-g.position.z)*j.uz;
if(!j.fired&&rem<210){j.fired=1;j.m=mesh(Bx(.3,.3,2.4),mt('white'),g.position.x,g.position.y-1.2,g.position.z,{cs:false});nz(.6,900,3000,.25,'highpass',0)}
if(j.m&&j.fired===1){const m=j.m,tx=j.o.x,ty=3,tz=j.o.z,dx=tx-m.position.x,dy=ty-m.position.y,dz=tz-m.position.z,d=Math.hypot(dx,dy,dz),v=300*dt;
if(d<=v+3){world.remove(m);j.m=null;j.fired=2;if(!j.o.dead){j.o.hp=1;dmgT(j.o,9,true)}explode(j.o.x,3,j.o.z,16,260,true);radio('WILDCAT-1','Splash! Target destroyed.')}
else{m.position.x+=dx/d*v;m.position.y+=dy/d*v;m.position.z+=dz/d*v;m.lookAt(tx,ty,tz);if(!LITE||(j.t*60|0)%2===0)puff({x:m.position.x,y:m.position.y,z:m.position.z,vx:0,vy:0,vz:0,sz:.8,life:1.1,col:0xd8d8d8,grow:1.5,op:.5})}}
if(j.t>9||Math.hypot(g.position.x-P.x,g.position.z-P.z)>650){world.remove(g);if(j.m)world.remove(j.m);JETS.splice(i,1)}}}
const RPAT={m4:[0,.1,.2,.35,.45,.4,.25,.05,-.2,-.4,-.55,-.5,-.35,-.1,.15,.35,.5,.45,.3,.1],ak:[0,.2,.4,.55,.4,.1,-.25,-.55,-.7,-.5,-.1,.3,.65,.8,.55,.15,-.3,-.65,-.8,-.5],lmg:[0,.1,.15,.3,.35,.25,.1,-.1,-.3,-.4,-.35,-.2,0,.2,.35,.4,.3,.15,-.05,-.25],smg:[0,.15,-.1,.25,-.2,.3,-.25,.2,-.15,.25,-.3,.15,-.1,.2,-.25,.3],pi:[0,.2,-.15,.25,-.2],sg:[0,.3,-.25],dmr:[0,.3,-.25],snp:[0,.3,-.25]},
BVEL={m4:520,ak:430,lmg:450,smg:320,pi:270,dmr:600,snp:720,sg:230};
function resolveShot(hs,d,pi,rd_){let end=null;if(hs.length&&WIN&&hs[0].object===WIN.gl){end=hs[0].point;winHit(hs[0],d);hs=[]}
if(hs.length){const h=hs[0];end=h.point;let o=h.object;while(o&&!o.userData.e&&!o.userData.tg&&!o.userData.pv)o=o.parent;const fo=d.fr?1-(1-d.fr[2])*clamp((h.distance-d.fr[0])/(d.fr[1]-d.fr[0]),0,1):1;
if(o&&o.userData.pv){pvHit(o,h,d,fo)}
else if(o&&o.userData.e){const u=o.userData,head=!!h.object.userData.head;let dm=(head?d.hd:d.dmg)*fo;if(u.kind==='heavy')dm*=head?1:.55;else if(u.kind==='boss')dm*=head?.9:.4;hitDir.x=rd_.x;hitDir.z=rd_.z;hitDir.p=dm;hitDir.ex=0;dmgE(o,dm,1,head);hitMk(head);puff({x:end.x,y:end.y,z:end.z,vy:.5,sz:.35,life:.4,col:0x7a1a1a,grow:.6,op:.8})}
else if(o&&o.userData.tg){dmgT(o.userData.tg,d.dmg*fo,1);hitMk(0);for(let i=0;i<3;i++)puff({x:end.x,y:end.y,z:end.z,vx:(R()-.5)*4,vy:R()*3,vz:(R()-.5)*4,sz:.15,life:.4,col:0xffd060,add:1,grav:10})}
else if(h.face&&(d.pel<3||pi<3)){const mm=Array.isArray(h.object.material)?h.object.material[0]:h.object.material,met=!!(mm&&mm.metalness>.3),dc=mm&&mm.color&&(mm.color.r<.85||mm.color.g<.85||mm.color.b<.85)?mm.color.getHex():0x8a8070,dv=1/(1+h.distance*.03);if(met)tn(800+R()*2600,300,.06,.1*dv,'triangle');else nz(.06,1400,300,.14*dv,'lowpass');const n=h.face.normal.clone().transformDirection(h.object.matrixWorld);decal(h.point,n);if(met)for(let i=0;i<3;i++)puff({x:end.x,y:end.y,z:end.z,vx:(R()-.5)*3,vy:R()*3,vz:(R()-.5)*3,sz:.12,life:.35,col:0xffd060,add:1,grav:10});else for(let i=0;i<3;i++)puff({x:end.x,y:end.y,z:end.z,vx:(R()-.5)*2,vy:R()*2+.4,vz:(R()-.5)*2,sz:.09,life:.45,col:dc,grav:6,op:.75});puff({x:end.x,y:end.y,z:end.z,vy:.3,sz:.4,life:.7,col:dc,grow:.8,op:.5})}}
return end}
function shoot(){ST.sh++;ST.wid=WS.id;if(wd.type==='melee'){slash();return}trigK=1;const d=wd;WS.ch=0;if(d.type==='mag'){if(WS.ammo>0){WS.ammo--;WS.ch=1}}else{pmp.on=1;pmp.t=0;pmp.e1=pmp.e2=0}
bolt=1;kick=Math.min(1.2,kick+.5);gunKick();hap(10);if(d.type==='mag'&&WS.ammo===Math.max(2,d.cap*.2|0)){pop('LOW AMMO');tn(2400,1800,.05,.16)}const rc_=CFG.rcv;let rm=1,rp=1;if(rc_){rm=[1,.85,.68,.5][rc_];if(rcT>.45){rcN=0;rcDir=R()<.5?1:-1}rcN++;rp=Math.min(1,.5+rcN*.08);}bloom=Math.min(1,bloom+(d.auto?clamp(d.spr*16+d.rk*4,.06,.3):.22));rcT=0;
const rk=(ads>.5?.6:1)*d.rk*rm*rp*(rc_&&moving?1.2:1)*(rc_&&!P.ground?1.4:1),dp=rk*.45;P.pitch=Math.min(1.45,P.pitch+dp);rcAcc=Math.min(.6,rcAcc+dp);P.rec+=rk*.55;P.recY+=(R()-.5)*d.rh*rm;
if(rc_){const pt=RPAT[WS.id]||RPAT.pi,dh=(pt[(rcN-1)%pt.length]*.75+(R()-.5)*.12)*d.rh*rm*rp*.35;P.yaw+=dh;rcAccY=clamp(rcAccY+dh,-.3,.3)}flashT=.05;gFlash.intensity=3;fm.material.opacity=1;fm.rotation.z=R()*6;
muz.getWorldPosition(v4);const mx=v4.x,my=v4.y,mz=v4.z;flashW.position.set(P.x-Math.sin(P.yaw)*1.2,P.y,P.z-Math.cos(P.yaw)*1.2);flashW.intensity=WNIGHT?8:5;flashW.distance=WNIGHT?22:18;
const spr=(ads>.5?d.spa:d.spr)*(moving?1.8:(P.ground?.85:1))*(1+bloom*(1-ads*.5))*(d.scope&&ads<.9?(ads>.5?1.5:5):1),tl=solids.concat(enemies,tgObjs,PV.on?pvTargets():[],WIN?[WIN.gl]:[]),trc=(shotN++%2===0)||d.pel>1||d.rate>.3;
for(let pi=0;pi<d.pel;pi++){ray.setFromCamera({x:(R()-.5)*spr*2,y:(R()-.5)*spr*2},cam);ray.far=(cur&&cur.far)||160;
let hs=ray.intersectObjects(tl,true),end=null;
if(d.pel===1&&!PV.on){const vel=BVEL[WS.id]||500,D0=hs.length?hs[0].distance:ray.far;if(D0>50){const dr=Math.max(0,.5*9.81*((D0/vel)*(D0/vel)-(20/vel)*(20/vel)));if(dr>.02){ray.ray.direction.y-=dr/D0;ray.ray.direction.normalize();hs=ray.intersectObjects(tl,true)}
const D1=hs.length?hs[0].distance:ray.far,dly=D1/vel;if(dly>.07){const org=ray.ray.origin.clone(),dir=ray.ray.direction.clone(),dd=d;end=hs.length?hs[0].point.clone():org.clone().addScaledVector(dir,80);setTimeout(()=>{if(!run||paused)return;ray.set(org,dir);ray.far=(cur&&cur.far)||160;resolveShot(ray.intersectObjects(tl,true),dd,0,dir)},dly*1000);hs=null}}}
if(hs)end=resolveShot(hs,d,pi,ray.ray.direction);
if(trc&&pi<3){const e=end||v3.copy(ray.ray.direction).multiplyScalar(80).add(ray.ray.origin);tracer(mx,my,mz,e.x,e.y,e.z,.025)}}
puff({x:mx,y:my,z:mz,vx:0,vy:.4,vz:0,sz:.2,life:.9,col:0x888888,grow:.6,op:.3});if(d.type==='mag')ejectCase(0);sShotW(d.snd,WS.id);alertAll(P.x,P.z,d.al)}
const gren=[],GF=1.7;let nGren=3,gAim=0;
const gaP=[];for(let i=0;i<44;i++){const q=mkSpr(tSpr,0xffd060,1,.17);q.material.opacity=.85;q.visible=false;sc.add(q);gaP.push(q)}
const gaR=new THREE.Mesh(new THREE.RingGeometry(7.1,7.5,48),new THREE.MeshBasicMaterial({color:0xffd060,transparent:true,opacity:.75,depthWrite:false,side:THREE.DoubleSide,fog:false})),
gaF=new THREE.Mesh(new THREE.CircleGeometry(7.1,40),new THREE.MeshBasicMaterial({color:0xffd060,transparent:true,opacity:.1,depthWrite:false,side:THREE.DoubleSide,fog:false}));
for(const m of[gaR,gaF]){m.rotation.x=-PI/2;m.visible=false;m.raycast=function(){};sc.add(m)}
function gHide(){for(const q of gaP)q.visible=false;gaR.visible=gaF.visible=false}
function gAimOn(){if(!run||paused||cin||mant.on||act.on)return;if(nGren<=0){pop('NO GRENADES');return}gAim=1}
function gAimOff(){if(!gAim)return;gAim=0;gHide();throwGren()}
function gArc(){const d=v4;cam.getWorldDirection(d);let x=cam.position.x+d.x*.7,y=cam.position.y-.18+d.y*.7,z=cam.position.z+d.z*.7,vx=d.x*17,vy=d.y*17+3.2,vz=d.z*17,t=0,n=0,i=0;const dt=1/30;
while(t<GF){vy-=19*dt;const nx=x+vx*dt,nz2=z+vz*dt;if(hitBox(nx,z,.14,y-.1)){vx*=-.45;vz*=.8}else x=nx;if(hitBox(x,nz2,.14,y-.1)){vz*=-.45;vx*=.8}else z=nz2;y+=vy*dt;
const gy=groundAt(x,z,y)+.09;if(y<=gy){y=gy;if(vy<-2){vy=-vy*.36;vx*=.62;vz*=.62}else{vy=0;vx*=Math.pow(.05,dt);vz*=Math.pow(.05,dt)}}
t+=dt;if((++i&1)===0&&n<gaP.length){const q=gaP[n++];q.position.set(x,y,z);q.visible=true}}
for(;n<gaP.length;n++)gaP[n].visible=false;
const gy2=groundAt(x,z,y)+.06,close=Math.hypot(x-P.x,z-P.z)<9.5,col=close?0xff3a2a:0xffd060;gaR.position.set(x,gy2,z);gaF.position.set(x,gy2+.01,z);gaR.visible=gaF.visible=true;gaR.material.color.setHex(col);gaF.material.color.setHex(col);
for(const q of gaP)q.material.color.setHex(col)}
function updGun(dt){dt=Math.min(dt,.033);const hh=wd.hip,aa=wd.ads;let x=lerp(hh[0],aa[0],ads),y=lerp(hh[1],aa[1],ads),z=lerp(hh[2],aa[2],ads),rx=0,ry=0,rz=0;
const hf=1-ads*.65,T=Math.min(1,dt*7);gh.t+=dt;
sprintK=lerp(sprintK,sprint?1:0,Math.min(1,dt*8));x+=-.05*sprintK;y+=-.05*sprintK;ry+=.55*sprintK;rx+=-.25*sprintK;rz+=.2*sprintK;
gh.svx+=-lookDX*.03*hf;gh.svy+=-lookDY*.03*hf;lookDX=lookDY=0;
gh.svx+=(-gh.sx*150-gh.svx*13)*dt;gh.svy+=(-gh.sy*150-gh.svy*13)*dt;gh.sx=clamp(gh.sx+gh.svx*dt,-.07,.07);gh.sy=clamp(gh.sy+gh.svy*dt,-.07,.07);
x+=gh.sx;y-=gh.sy;ry+=gh.sx*3;rx+=gh.sy*2.5;rz+=gh.sx*2;
const br=Math.sin(gh.t*1.7),bs=Math.sin(gh.t*.85);x+=bs*.0014*hf;y+=br*.0022*(1-ads*.4);rx+=br*.004*(1-ads*.5);ry+=bs*.003*hf;
gh.mv=lerp(gh.mv,moving&&P.ground?1:0,T);const b=1-ads*.75,wkK=gh.mv*(1-sprintK),spK=gh.mv*sprintK,_ws=Math.sin(stepT),_wc=Math.cos(stepT),_ws2=Math.sin(stepT*2),_wc2=Math.cos(stepT*2);
x+=_ws*.007*wkK*b+_ws*.016*spK;y+=_wc2*.0035*wkK*b-Math.abs(_ws)*.014*spK+_wc2*.006*spK;z+=_ws2*.002*wkK*b+_ws2*.01*spK;ry+=_wc*.014*wkK*b+_wc*.035*spK;rz+=_ws*.03*wkK*b+_ws*.055*spK;rx+=_ws2*.006*wkK*b+_ws2*.05*spK;
const sI=clamp(mv.x+(k.KeyD?1:0)-(k.KeyA?1:0),-1,1);gh.st=lerp(gh.st,sI,T);x-=gh.st*.012*hf;rz-=gh.st*.045*hf;gh.cr=lerp(gh.cr,-gh.st*.012*hf,T);
if(!P.ground){gh.lvy=P.vy;y-=clamp(P.vy,-6,6)*.004}if(P.ground&&!gh.wasG)gh.lv-=Math.min(10,Math.abs(gh.lvy))*.5;gh.wasG=P.ground;
gh.lv+=(-gh.ly*180-gh.lv*14)*dt;gh.ly+=gh.lv*dt;y+=gh.ly*.03;rx-=gh.ly*.05;
gh.zv+=(-gh.zp*230-gh.zv*17)*dt;gh.zp+=gh.zv*dt;gh.pv+=(-gh.pp*190-gh.pv*15)*dt;gh.pp+=gh.pv*dt;gh.yv+=(-gh.yp*200-gh.yv*16)*dt;gh.yp+=gh.yv*dt;gh.rv+=(-gh.rp*200-gh.rv*16)*dt;gh.rp+=gh.rv*dt;
z+=clamp(gh.zp,0,.06);rx+=clamp(gh.pp,-.05,.22);y+=clamp(gh.pp,0,.22)*.03;ry+=clamp(gh.yp,-.08,.08);rz+=clamp(gh.rp,-.1,.1);
swUpd(dt);const dr=gh.draw*gh.draw;y-=dr*.3;rx+=dr*.75;x+=dr*.08;rz+=dr*.3;ry-=dr*.2;actUpd(dt);{const lw=act.lw;y-=lw*.5;rx+=lw*.9;x+=lw*.08}
const ga=gunAnim(dt);rz+=ga[0];rx+=ga[1];
if(KG.on||wd.type==='melee'){const q=slashPose(dt);x+=q[0];y+=q[1];z+=q[2];rx+=q[3];ry+=q[4];rz+=q[5]}gun.position.set(x,y,z);gun.rotation.set(rx,ry,rz);knifeTrail();
kick*=.82;flashT-=dt;gFlash.intensity*=.5;fm.material.opacity*=.5;flashW.intensity*=.5;expL.intensity*=.88;dotS.visible=!!wd.dot;updGren(dt);if(gAim)gArc()}
const GG=new THREE.SphereGeometry(.09,8,6),GM=new THREE.MeshStandardMaterial({color:0x3b4a2c,roughness:.55,metalness:.35});
let GTX=null;
function gTex(){if(GTX)return GTX;const c=document.createElement('canvas');c.width=256;c.height=128;const g=c.getContext('2d');
g.fillStyle='#4a5231';g.fillRect(0,0,256,128);
for(let i=0;i<40;i++){g.fillStyle='rgba(28,34,16,'+(.05+R()*.08)+')';g.beginPath();g.ellipse(R()*256,R()*128,6+R()*22,3+R()*9,R()*3,0,6.283);g.fill()}
for(let i=0;i<3000;i++){g.fillStyle=R()<.55?'rgba(18,22,8,'+R()*.2+')':'rgba(150,158,110,'+R()*.13+')';g.fillRect(R()*256,R()*128,1+R()*2,1+R()*2)}
g.fillStyle='#c4a022';g.fillRect(0,57,256,9);g.fillStyle='rgba(0,0,0,.22)';g.fillRect(0,57,256,1);g.fillRect(0,65,256,1);
g.fillStyle='#1d200f';g.font='bold 9px Arial';g.fillText('FRAG',30,81);g.fillText('M67',150,81);g.fillStyle='#c4a022';g.fillRect(28,86,22,2);g.fillRect(148,86,22,2);
for(let i=0;i<70;i++){g.strokeStyle='rgba(200,200,170,'+(.1+R()*.2)+')';g.lineWidth=.6+R();const x=R()*256,y=R()*128;g.beginPath();g.moveTo(x,y);g.lineTo(x+(R()-.5)*14,y+(R()-.5)*10);g.stroke()}
for(let i=0;i<26;i++){g.fillStyle='rgba(112,62,28,'+(.1+R()*.2)+')';g.beginPath();g.arc(R()*256,R()*128,.8+R()*2.4,0,6.283);g.fill()}
const t=new THREE.CanvasTexture(c);t.encoding=THREE.sRGBEncoding;t.anisotropy=LITE?1:4;return GTX=t}
const GGM={};
function mkGren(){if(!GGM.b){const tx=gTex();GGM.b=new THREE.MeshStandardMaterial({map:tx,bumpMap:LITE?null:tx,bumpScale:.4,roughness:.58,metalness:.35,envMapIntensity:.5});
GGM.s=new THREE.MeshStandardMaterial({color:0x8d9297,roughness:.32,metalness:.88});GGM.d=new THREE.MeshStandardMaterial({color:0x26282a,roughness:.5,metalness:.75});GGM.r=new THREE.MeshStandardMaterial({color:0xb08d3c,roughness:.35,metalness:.9});
GGM.bg=new THREE.SphereGeometry(.065,20,14);GGM.ng=new THREE.CylinderGeometry(.021,.025,.03,12);GGM.fg=new THREE.CylinderGeometry(.016,.018,.036,12);GGM.sp=new THREE.BoxGeometry(.017,.115,.004);GGM.rg=new THREE.TorusGeometry(.016,.0032,8,16);GGM.pg=new THREE.CylinderGeometry(.0026,.0026,.045,6)}
const g=new THREE.Group(),a=(geo,m,x,y,z)=>{const e=new THREE.Mesh(geo,m);e.position.set(x,y,z);g.add(e);return e};
a(GGM.bg,GGM.b,0,0,0);a(GGM.ng,GGM.d,0,.07,0);a(GGM.fg,GGM.s,0,.1,0);
const sp=a(GGM.sp,GGM.s,.05,.052,0);sp.rotation.z=.42;
const rg=a(GGM.rg,GGM.r,-.027,.104,0);rg.rotation.y=PI/2;const pn=a(GGM.pg,GGM.s,-.012,.1,0);pn.rotation.z=PI/2;
return g}
function throwGren(){if(!run||paused||cin||nGren<=0||mant.on||swp.on||act.on)return;nGren--;adsOn=false;cancelReload();const d=new THREE.Vector3();cam.getWorldDirection(d);const m=mkGren();m.position.copy(cam.position).addScaledVector(d,.7);m.position.y-=.18;sc.add(m);gren.push({m:m,vx:d.x*17,vy:d.y*17+3.2,vz:d.z*17,t:0,b:0});nz(.06,900,300,.3);tn(1200,700,.05,.2);pop('GRENADE OUT');tn(1900,2600,.05,.14);setTimeout(()=>tn(900,700,.04,.12),90);hap(20)}
function updGren(dt){for(let i=gren.length-1;i>=0;i--){const g=gren[i],m=g.m;g.t+=dt;g.vy-=19*dt;let x=m.position.x,y=m.position.y,z=m.position.z;const nx=x+g.vx*dt,nz2=z+g.vz*dt;
if(hitBox(nx,z,.14,y-.1)){g.vx*=-.45;g.vz*=.8;tn(500,300,.04,.12)}else x=nx;if(hitBox(x,nz2,.14,y-.1)){g.vz*=-.45;g.vx*=.8;tn(500,300,.04,.12)}else z=nz2;
y+=g.vy*dt;const gy=groundAt(x,z,y)+.09;if(y<=gy){y=gy;if(g.vy<-2){g.vy=-g.vy*.36;g.vx*=.62;g.vz*=.62;if(g.b++<4)tn(420,220,.05,.16)}else{g.vy=0;g.vx*=Math.pow(.05,dt);g.vz*=Math.pow(.05,dt)}}
m.position.set(x,y,z);m.rotation.x+=g.vz*dt*3;m.rotation.z-=g.vx*dt*3;
if(g.t>GF-.9&&g.t<GF&&((g.t*7)|0)!==(((g.t-dt)*7)|0))tn(2200,2200,.03,.08);
if(g.t>=GF){sc.remove(m);gren.splice(i,1);alertAll(x,z,35);ST.wid=null;explode(x,y,z,7.5,170,true)}}}
function updPlayer(dt){if(typeof CTL!=='undefined')CTL.tick(dt);CR.k+=((CR.on&&P.ground&&!mant.on?1:0)-CR.k)*Math.min(1,dt*9);let fx=k.KeyW?1:k.KeyS?-1:-mv.y;const st=mv.x+(k.KeyD?1:0)-(k.KeyA?1:0),mag=Math.min(1,Math.hypot(fx,st));moving=mag>.1;if(!mant.on&&moving&&fx>.3&&!P.ground)tryMantle();
sprint=((fx>.85&&Math.abs(st)<.5)||(k.ShiftLeft&&fx>0))&&ads<.2&&!rl.on&&!firing&&!CR.on;
{const ad=Math.min(dt,.033),adT=adsOn&&!sprint&&!rl.on&&!swp.on&&!mant.on&&!act.on?1:0;const AK=ADSK[WS.id]||480;adsV+=((adT-ads)*AK-adsV*2*Math.sqrt(AK))*ad;ads=clamp(ads+adsV*ad,0,1);if((ads<=0&&adsV<0)||(ads>=1&&adsV>0))adsV=0}const sp=(ads>.5?3:sprint?8.2:5.2)*(1-.42*CR.k)*(rl.on?.9:1)*wd.mv*(mant.on?0:1)*(PV.on&&PV.frz?0:1);
let lad=null;for(const L of ladders)if(Math.abs(P.x-L.x)<.8&&P.z>L.z-.4&&P.z<L.z+.9){if(P.ground&&time-ladH>8){ladH=time;pop('FACE LADDER + HOLD FORWARD TO CLIMB')}if((fx>.3&&Math.cos(P.yaw)>.3&&P.y<L.top+1.67)||(fx<-.3&&P.y>1.95)){lad=L;break}}
const s=Math.sin(P.yaw),c=Math.cos(P.yaw),dx=(-s*fx+c*st)*sp*dt,dz=(-c*fx-s*st)*sp*dt,foot=P.y-1.7;
if(!lad){if(!hitBox(P.x+dx,P.z,.4,foot)&&(Math.abs(P.x+dx)<76||Math.abs(P.x+dx)<Math.abs(P.x)))P.x+=dx;if(!hitBox(P.x,P.z+dz,.4,foot)&&(Math.abs(P.z+dz)<76||Math.abs(P.z+dz)<Math.abs(P.z)))P.z+=dz}
if(mant.on)updMantle(dt);else if(lad){P.vy=0;P.y=clamp(P.y+fx*3.2*dt,1.7,lad.top+1.7);P.ground=false}else{P.vy-=20*dt;P.y+=P.vy*dt;const fl=groundAt(P.x,P.z,P.y-1.7)+1.7;if(P.y<=fl){P.y=fl;P.vy=0;P.ground=true}else P.ground=false}
if(moving&&P.ground){stepT+=dt*sp*1.6;if(Math.floor(stepT/PI)!==Math.floor((stepT-dt*sp*1.6)/PI))sStep(sprint,surfAt(P.x,P.z,P.y-1.7))}
P.hurtT+=dt;{const dl=P.hp<30?2.5:3.5,on=P.hurtT>dl&&P.hp<100&&P.hp>0&&!PV.on;if(on){const q=Math.min(1,(P.hurtT-dl)/3);P.hp=Math.min(100,P.hp+(8+14*q)*dt)}if(on!==!!healOn){healOn=on?1:0;$('heal').style.display=on?'block':'none'}}
P.rec-=P.rec*Math.min(1,dt*7);P.recY-=P.recY*Math.min(1,dt*7);shake*=Math.pow(.9,dt*60);applyLook(dt);updRecoil(dt);
const bob=moving&&P.ground?Math.sin(stepT)*.035*(1-ads*.7):0;
scopeSway(dt);cam.position.set(P.x+(R()-.5)*shake*.15,P.y+bob-CR.k*.5+(R()-.5)*shake*.15,P.z);cam.rotation.set(P.pitch+P.rec+mant.dip+act.dip+scY,P.yaw+P.recY+scX,gh.cr,'YXZ');
const mg=scopeMag(),zt=mg?2*Math.atan(Math.tan(CFG.fov*PI/360)/mg)*180/PI/CFG.fov:wd.zoom,tf=lerp(CFG.fov,CFG.fov*zt,ads)+(sprint?5:0)-kick*(wd.rk||0)*(ads>.5?10:22);if(Math.abs(cam.fov-tf)>.05){cam.fov=lerp(cam.fov,tf,Math.min(1,dt*(mg?10:16)));cam.updateProjectionMatrix()}
fireT-=dt;fireLogic();
updXh(dt);scopeUI();uiExtra();lowHP(dt);pkUI(dt);kitUI(dt);uiRl();hitFlash*=Math.pow(.92,dt*60);
{const low=clamp((45-P.hp)/45,0,1);let lv=0;if(low>0&&P.hp>0){const pul=.5+.5*Math.sin(time*(6+8*low));lv=low*(.3+.3*pul);hbT-=dt;if(hbT<=0){hbT=1.1-.5*low;sHeart(low)}}
$('dmg').style.opacity=Math.min(1,hitFlash+lv)}
{dindT=Math.max(0,dindT-dt*1.3);const dn=$('dind');dn.style.opacity=dindT;if(dindT>0){const dx=dsx-P.x,dz=dsz-P.z,f=-dx*Math.sin(P.yaw)-dz*Math.cos(P.yaw),r=dx*Math.cos(P.yaw)-dz*Math.sin(P.yaw);dn.style.transform='rotate('+(Math.atan2(r,f)*180/PI).toFixed(1)+'deg)'}}
hmT*=.85;$('hm').style.opacity=hmT}
let ambT=3;
function updFx(dt){updShards(dt);updSnow(dt);for(const s of fxP){if(!s.visible)continue;const u=s.userData;u.life-=dt;if(u.life<=0){s.visible=false;continue}const t=1-u.life/u.max;u.vy-=u.grav*dt;const dr=Math.max(0,1-u.drag*dt);u.vx*=dr;u.vy*=dr;u.vz*=dr;s.position.x+=u.vx*dt;s.position.y+=u.vy*dt;s.position.z+=u.vz*dt;const z=u.sz+u.grow*t;s.scale.set(z,z,1);s.material.opacity=u.op*(1-t)}
for(const m of trP)if(m.visible){m.userData.l-=dt;if(m.userData.l<=0)m.visible=false}
for(const m of csP)if(m.visible){const u=m.userData;u.l-=dt;if(u.l<=0){m.visible=false;continue}m.scale.setScalar((u.s0||1)*Math.min(1,u.l/.12));u.v.y-=14*dt;m.position.addScaledVector(u.v,dt);if(m.position.y<.02){m.position.y=.02;u.v.y*=-.35;u.v.x*=.5;u.v.z*=.5}m.rotation.x+=u.s.x*dt;m.rotation.z+=u.s.z*dt}
for(const m of mgP)if(m.visible){const u=m.userData;u.l-=dt;if(u.l<=0){m.visible=false;continue}u.v.y-=14*dt;m.position.addScaledVector(u.v,dt);if(m.position.y<.1){m.position.y=.1;u.v.y*=-.3;u.v.x*=.4;u.v.z*=.4}else{m.rotation.x+=u.s.x*dt;m.rotation.z+=u.s.z*dt}}
for(const m of shwP)if(m.visible){const u=m.userData;u.t+=dt;const k=u.t/.5;if(k>=1){m.visible=false;continue}m.scale.setScalar(.4+(1-Math.pow(1-k,2.2))*u.r);m.material.opacity=.65*(1-k)*(1-k)}
for(let i=smk.length-1;i>=0;i--){const q=smk[i];if(!q.inf)q.t-=dt;if(q.t<=0){smk.splice(i,1);continue}q.a-=dt;if(q.a<=0){q.a=q.inf?.25:.1;const k=q.inf?.3:1-q.t/q.max;if(Math.hypot(q.x-P.x,q.z-P.z)<120)puff({x:q.x+(R()-.5)*1.2*q.k,y:q.y+k*3*q.k+(R()-.5)*.5,z:q.z+(R()-.5)*1.2*q.k,vx:(R()-.5)*.8+q.wx,vy:2+R()*1.5,vz:(R()-.5)*.8+q.wz,sz:1.4*q.k,life:3+R()*2,col:SMC[R()*4|0],grow:3.5*q.k,drag:.4,op:.4*(1-k*.6)})}}
for(const e of emit){e.t-=dt;if(e.t<=0)continue;e.a-=dt;if(e.a<=0){e.a=.09;if(Math.hypot(e.x-P.x,e.z-P.z)<75){puff({x:e.x+(R()-.5)*.3,y:e.y,z:e.z+(R()-.5)*.3,vx:(R()-.5)*.4,vy:1.3+R(),vz:(R()-.5)*.4,sz:.7,life:.5,col:0xff8a30,add:1,grow:.4,op:.9});if(R()<.4)puff({x:e.x,y:e.y+.8,z:e.z,vx:.6,vy:1.6,vz:.3,sz:.9,life:2.6,col:0x2a2a2a,grow:2.4,op:.35})}}}
fireL.forEach(l=>l.intensity=1.8+Math.sin(time*17+l.position.x)*.5+R()*.5);for(let i=0;i<anim.length;i++)anim[i](time,dt)}
function updAmb(dt){if(PV.on)return;ambT-=dt;if(ambT<=0){ambT=2+R()*5;const a=R()*6.28,d=60+R()*40;if(R()<.7){const n=2+(R()*4|0);for(let i=0;i<n;i++)setTimeout(()=>sFar(d,Math.cos(a),1500),i*110)}else sBoom(d+30)}}
const RDC=$('radar'),RDG=RDC.getContext('2d');
function radarDraw(){const on=CFG.radar&&run&&!cin&&!UA.on&&!FL.on&&!PV.on&&!NET.dn;if(!on){if(RDC._v){RDC._v=0;RDC.style.display='none'}return}if(!RDC._v){RDC._v=1;RDC.style.display='block'}
const W=160,C=80,K=C/42,sn=Math.sin(P.yaw),cs_=Math.cos(P.yaw),g=RDG;g.clearRect(0,0,W,W);g.strokeStyle='rgba(125,255,156,.28)';g.lineWidth=1.5;g.beginPath();g.arc(C,C,C-2,0,6.283);g.stroke();g.beginPath();g.arc(C,C,C*.5,0,6.283);g.moveTo(C,6);g.lineTo(C,W-6);g.moveTo(6,C);g.lineTo(W-6,C);g.globalAlpha=.5;g.stroke();g.globalAlpha=1;
const dot=(x,z,col,r)=>{const dx=x-P.x,dz=z-P.z;let px=(dx*cs_-dz*sn)*K,py=-(-dx*sn-dz*cs_)*K;const l=Math.hypot(px,py),m=C-9;if(l>m){px*=m/l;py*=m/l;g.globalAlpha=.55}g.fillStyle=col;g.beginPath();g.arc(C+px,C+py,r,0,6.283);g.fill();g.globalAlpha=1};
for(const a of allies)if(!a.userData.dead)dot(a.position.x,a.position.z,a.userData.rm?'#4df0ff':'#5dff7a',4);
if(NET.hm&&NET.on&&!NET.h)dot(NET.hm.position.x,NET.hm.position.z,'#4df0ff',4);
for(const e of enemies){const u=e.userData;if(u.dead)continue;dot(e.position.x,e.position.z,u.alert?'#ff3b30':'#ff9f2e',u.kind==='boss'||u.kind==='heavy'?5:3.4)}
const o=objPos();if(o)dot(o[0],o[1],'#ffd84a',5);
g.fillStyle='#fff';g.beginPath();g.moveTo(C,C-7);g.lineTo(C+5,C+5);g.lineTo(C-5,C+5);g.closePath();g.fill()}
function wpHud(){const o=objPos(),e=$('wp');if(!o||!run){e.style.display='none';return}v3.set(o[0],o[2],o[1]).project(cam);const w=VW(),h=VH();let x=(v3.x*.5+.5)*w,y=(-v3.y*.5+.5)*h;if(v3.z>1){x=w-x;y=h-y}x=clamp(x,40,w-40);y=clamp(y,70,h-70);e.style.display='block';e.style.transform='translate('+(x-20)+'px,'+(y-16)+'px)';e.innerHTML='◆<br>'+Math.round(Math.hypot(o[0]-P.x,o[1]-P.z))+'m'}
function setDyn(k){dynK=k;rd.setPixelRatio(inLobby?Math.min(window.devicePixelRatio||1,LITE?1:1.4)*lobK:Math.min(window.devicePixelRatio||1,CFG.res,PQ.pr)*dynK);resize()}
function resize(){rdDirty=true;document.documentElement.classList.toggle("pt",PO());rd.setSize(VW(),VH(),false);cam.aspect=cam2.aspect=VW()/VH();cam.updateProjectionMatrix();cam2.updateProjectionMatrix()}addEventListener('resize',resize);
const clock=new THREE.Clock();let hudT=0;
let lbS=false,tkErr=0;function tick(ts){requestAnimationFrame(tick);try{tick1(ts);tkErr=0}catch(e){window.MO_ERR=e;if(++tkErr>=30){try{pauseG()}catch(_){}window.moBox('SOMETHING WENT WRONG','The game hit a repeated error. Reload to continue; mission progress is saved.')}}}
function tick1(ts){
if(!hzDone&&ts){if(hzP){const d=ts-hzP;if(d>3&&d<45)hzS.push(d)}hzP=ts;if(hzS.length>=40){hzS.splice(0,8);hzS.sort((a,b)=>a-b);const v=1000/hzS[8],S=[30,48,50,60,72,75,90,100,120,144,165,240];hz=S.reduce((a,b)=>Math.abs(b-v)<Math.abs(a-v)?b:a);hzDone=true;skN=capN()}}
if(inLobby!==lbS){lbS=inLobby;skN=capN();skC=0}
if(++skC<skN)return;skC=0;cvB=3;
if(!ready)return;const dt0=Math.min(clock.getDelta(),.05),dt=paused?0:dt0;time+=dt;if(ksT>0&&(ksT-=dt)<=0)ksN=0;fpsN++;fpsT+=dt0;if(fpsT>=.5){if(CFG.fps){const ri=rd.info.render;$('fps').textContent=Math.round(fpsN/fpsT)+' FPS · '+ri.calls+' DC · '+(ri.triangles/1000).toFixed(0)+'k tri · '+Math.round(dynK*100)+'% res'+(LITE?' · LITE':'')+PQ.tag}fpsN=0;fpsT=0}
if(paused){}else if(run&&FL.on){flyTick(dt)}else if(run&&UA.on){uavTick(dt)}else if(run){updPlayer(dt);if(!NET.g)for(let i=enemies.length-1;i>=0&&run;i--){const q=enemies[i];if(q.userData.sn)sniperAI(q,dt);else enemyAI(q,dt)}updAllies(dt,true);stageTick(dt);updAmb(dt)}
else if(cin){cutT+=dt;CS.t+=dt;updAllies(dt,false);camCut()}
else if(PV.on)pvIdleCam(dt);else if(NET.dn){if(NET.h){for(let i=enemies.length-1;i>=0;i--){const q=enemies[i];if(q.userData.sn)sniperAI(q,dt);else enemyAI(q,dt)}updAllies(dt,true);stageTick(dt)}specCam(dt)}else if(inLobby)lobbyTick(dt);else{cam.position.set(Math.sin(time*.1)*20,6,25);cam.lookAt(0,4,0)}
if(NET.on)netBeat(dt0);else if(pnetOn){pnetOn=0;$('pnet').style.display='none'}if(NET.on&&!paused){if(PV.on)pvTick(dt);else(NET.h?nHostTick:nGuestTick)(dt)}for(let i=0;i<corpses.length;i++)corpseAnim(corpses[i],dt);updFx(dt);gfxTick(dt);if(run&&!paused)updGun(dt);if(!paused&&run)nvTick(dt);
{const SY=(!inLobby&&cur&&cur.sy)||0;sun.position.set(P.x+SD[0]*90,SY+SD[1]*90,P.z+SD[2]*90);sun.target.position.set(P.x,SY,P.z)}sky.position.copy(cam.position);
hudT-=dt;if(hudT<=0){hudT=.1;if(!inLobby){hud();wpHud()}}if(!inLobby){mkTick(dt);ptagTick();revTick(dt);if(frN%3===0)radarDraw()}if(gAim&&!(run&&!paused&&!cin)){gAim=0;gHide()}
cam2.position.copy(cam.position);cam2.quaternion.copy(cam.quaternion);
if(!paused&&(run||cin)){pgT+=dt0;pgN++;if(pgT>=1.25){const f=pgN/pgT,tg=hz/skN;pgT=0;pgN=0;pgBan--;const low=f<tg*.84;
if(low){pgUp=0;pgBan=12;shEvery=2;if(CFG.dyn&&dynK>(LITE?.81:.56))setDyn(Math.max(LITE?.8:.55,dynK-.15));else if(!CFG.cap&&hz/(skN+1)>=28&&++pgLow>=3){pgLow=0;autoCap=hz/(skN+1);skN=capN()}}
else if(pgBan<=0&&f>=tg*.95){pgLow=0;if(++pgUp>=3){pgUp=0;if(CFG.dyn&&dynK<1)setDyn(Math.min(1,dynK+.1));else shEvery=1}}else pgUp=0}}
if(inLobby&&!paused){lgT+=dt0;lgN++;if(lgT>=1){const f=lgN/lgT,tg=Math.min(hz/skN,60);lgT=0;lgN=0;if(lgW>0)lgW--;else if(f<tg*.82&&lobK>(LITE?.81:.56)){lobK=Math.max(LITE?.8:.55,lobK-.15);lgUp=0;lgLock=1;setDyn(dynK)}else if(f>=tg*.95&&lobK<1&&!lgLock){if(++lgUp>=4){lgUp=0;lobK=Math.min(1,lobK+.1);setDyn(dynK)}}else lgUp=0}}
if(CFG.shadow>0&&!PQ.noSh&&(inLobby?(lobTab!=='load'&&++shN%(lobK<.7?40:20)===0):(LITE?(++shN%(shEvery===1?2:3)===0):(shEvery===1||(++shN&1)))))rd.shadowMap.needsUpdate=true;
frN++;const idle=!run&&!cin,skip=paused?!rdDirty:(idle&&(!inLobby||(lobK<.6&&!lobOrb.dn&&Math.abs(lobOrb.vy)<.3))&&(frN&1)&&!rdDirty);
if(!skip){rdDirty=false;rd.info.reset();mdTick();rd.clear();rd.render(sc,cam);PQ.fr++;if(gun.visible&&!scopeOn){rd.clearDepth();rd.render(gs,cam2)}}}
